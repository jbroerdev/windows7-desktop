"""Isolated local lab entrypoint. Not a public HTTP/agent dispatcher."""
import argparse
import json
import os
import sys
from networkd_provider import NetworkdProvider
from networkd_system import SystemBackend, STATE_FILE


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=['execute','recover'])
    parser.add_argument('--lab',action='store_true')
    parser.add_argument('--token')
    args=parser.parse_args()
    if os.geteuid()!=0:raise PermissionError('Local root lab process required.')
    backend=SystemBackend(STATE_FILE,isolated_lab=args.lab or args.mode=='recover')
    service=NetworkdProvider(STATE_FILE,backend,allow_changes=args.lab)
    if args.mode=='recover':
        backend._lab_guard()
        result=service.recover(args.token or '')
    else:
        raw=sys.stdin.buffer.read(65537)
        if len(raw)>65536:raise ValueError('Request size limit.')
        request=json.loads(raw)
        if not isinstance(request,dict) or set(request)!={'action','data'}:raise ValueError('Strict action/data envelope required.')
        result=service.execute(request['action'],request['data'])
    print(json.dumps(result,sort_keys=True),flush=True)


if __name__=='__main__':
    try:main()
    except Exception as error:
        print(json.dumps({'errorCode':getattr(error,'code','provider-error'),'error':str(error)}),file=sys.stderr,flush=True)
        raise SystemExit(1)
