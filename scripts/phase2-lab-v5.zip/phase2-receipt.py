"""Receiver-side checks for actual phase2 serial/result evidence. No commands."""
import base64
import hashlib
import json

NAMES={'timer-baseline.json','timer-prepared.json','timer-child.json','timer-pending.json',
    'timer-observations-before-any-status.json','timer-service-after-restore.json','timer-final.json',
    'manual-baseline.json','manual-prepared.json','manual-pending.json','manual-final.json',
    'commit-baseline.json','commit-prepared.json','commit-pending.json','commit-final.json','foreign-pending-canary.json','result.json'}


def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def verify(value):
    if value.get('phase')!='phase2-static-provider' or value.get('passed') is not True or type(value.get('caseExitCode')) is not int or value['caseExitCode']!=0:
        raise ValueError('Actual phase2 did not pass.')
    for key in ('productionReady','productionAccess','autoWritesVerified','crashDuringCommitVerified','globalReloadForeignPendingCaseVerified','globalReloadIsolationVerified'):
        if value.get(key) is not False:raise ValueError('Unexpected phase2 scope claim.')
    records=value.get('evidence',{})
    if set(records)!=NAMES:raise ValueError('Exact full phase2 evidence set required.')
    decoded={};total=0
    for name,item in records.items():
        if set(item)!={'bytes','sha256','base64'} or type(item['bytes']) is not int or not 0<=item['bytes']<=512*1024:raise ValueError('Invalid phase2 file bound.')
        data=base64.b64decode(item['base64'],validate=True);total+=len(data)
        if total>3*1024*1024 or len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:raise ValueError('Phase2 evidence size/hash mismatch.')
        decoded[name]=json.loads(data)
    result=decoded['result.json']
    if result.get('phase')!='phase2-static-provider' or result.get('passed') is not True:raise ValueError('Actual case result failed.')
    for field in ('positiveCasesPassed','foreignPendingCanaryExecuted','negativeCanaryCasePassed'):
        if value.get(field) is not True or result.get(field) is not True:raise ValueError('Full positive/negative case sequence unproven.')
    verify_canary(decoded['foreign-pending-canary.json'])
    for key in ('timerRollbackAfterSigkillVerified','manualRollbackVerified','explicitStaticCommitVerified'):
        if result.get(key) is not True or value.get(key) is not True:raise ValueError('Missing actual case.')
    for name,sha in result.get('evidence',{}).items():
        if name=='result.json' or name not in records or records[name]['sha256']!=sha:raise ValueError('Inner case evidence manifest mismatch.')
    if set(result.get('evidence',{}))!=NAMES-{'result.json'}:raise ValueError('Inner case evidence manifest incomplete.')
    revisions=[]
    for label in ('timer','manual','commit'):
        baseline=decoded[label+'-baseline.json'];revisions.append(baseline['revision'])
        if digest(baseline['canonical'])!=baseline['revision']:raise ValueError('Baseline canonical revision mismatch.')
        if {a['name'] for a in baseline['adapters']}!={'lo','w3boot0','w3test0','w3canary0'}:raise ValueError('Unexpected measured guest interfaces.')
        pending=decoded[label+'-pending.json'];plan=pending['plan']
        prepared=decoded[label+'-prepared.json']
        if prepared['phase']!='prepared' or prepared['token']!=plan['token'] or plan['name']!='w3test0' or plan['phase']!='pending' or plan.get('commitDecision') is not False:
            raise ValueError('Unexpected case transaction identity/phase.')
        if pending.get('persistentAbsent') is not True or pending.get('timerState')!='active' or plan.get('timerArmed') is not True:
            raise ValueError('Pending persistence/timer condition unproven.')
        if plan.get('baseline',{}).get('revision')!=baseline['revision'] or plan.get('timer',{}).get('serviceCommandVerified') is not True:
            raise ValueError('Timer/baseline identity unproven.')
        timer=plan['timer'];unit='windows7-web-networkd-'+plan['token']
        args=['/usr/bin/python3','/opt/worker3-lab/networkd_cli.py','recover','--token',plan['token']]
        command=timer.get('actualExecStart',[])
        if timer.get('unit')!=unit or timer.get('actualTriggers')!=[unit+'.service'] or len(command)!=1 or command[0][0]!='/usr/bin/python3' or command[0][1]!=args:
            raise ValueError('Actual PID1 timer/helper command identity mismatch.')
        if timer.get('deadlineMonotonic')!=plan.get('deadlineMonotonic') or not 0<timer['deadlineMonotonic']-timer['armedMonotonic']<=123:
            raise ValueError('Actual monotonic timer deadline unproven.')
        check_connection(pending['connection'])
        check_target(pending['actual'],plan,False)
        # Foreign interface canonical state is compared separately from the changed target.
        old=[a for a in baseline['canonical']['adapters'] if a['name']!='w3test0']
        new=[a for a in pending['actual']['canonical']['adapters'] if a['name']!='w3test0']
        if old!=new:raise ValueError('Foreign interface changed during pending case.')
        if label in ('timer','manual'):
            final=decoded[label+'-final.json']
            if final['plan']['phase']!='rolled-back' or final['plan']['token']!=plan['token']:raise ValueError('Rollback final mismatch.')
            check_connection(final['connection'])
    if len(set(revisions))!=1:raise ValueError('Cases did not return to identical full baselines before next case.')
    child=decoded['timer-child.json']
    if child['exitCode']!=-9 or child.get('timedOut') is not False:raise ValueError('Actual applying process SIGKILL missing.')
    message=json.loads(child['stdout'])
    if message.get('event')!='actual-apply-before-sigkill' or message.get('pid')!=child.get('pid') or type(child.get('pid')) is not int or child['pid']<=0 or message['plan']['token']!=decoded['timer-prepared.json']['token'] or message['plan']['phase']!='pending':raise ValueError('Killed child did not report same pending process/case.')
    observations=decoded['timer-observations-before-any-status.json']
    if not observations or observations[-1]['phase']!='rolled-back' or observations[-1]['revision']!=revisions[0]:raise ValueError('No independent exact restoration sample.')
    deadline=decoded['timer-pending.json']['plan']['deadlineMonotonic']
    if observations[-1]['monotonic']<deadline or not any(o['phase']=='pending' and o['monotonic']<deadline for o in observations):raise ValueError('Protected timer interval not independently observed.')
    timer_final=decoded['timer-final.json']
    if timer_final.get('independentRestoreBeforeAnyStatus') is not True:raise ValueError('Independent restoration ordering missing.')
    service=decoded['timer-service-after-restore.json']
    if service.get('unit')!=decoded['timer-pending.json']['plan']['timer']['unit']+'.service':raise ValueError('Different helper service receipt.')
    fields=dict(line.split('=',1) for line in service['stdout'].splitlines() if '=' in line)
    if service['exitCode']!=0 or any(fields.get(k)!=v for k,v in {'ActiveState':'active','SubState':'exited','Result':'success','ExecMainStatus':'0'}.items()):raise ValueError('Helper not completed successfully.')
    final=decoded['commit-final.json'];plan=final['journal']
    if final['plan']['phase']!='confirmed' or plan['phase']!='confirmed' or plan.get('commitDecision') is not True or plan['token']!=decoded['commit-prepared.json']['token']:
        raise ValueError('Explicit durable commit identity missing.')
    check_target(final['actual'],plan,True);check_connection(final['connection'])
    if final['persistentSha256']!=plan['candidate']['sha256']:raise ValueError('Persistent byte SHA mismatch.')
    return {'phase2EvidenceFilesVerified':len(records),'timerRollbackAfterSigkillVerified':True,'manualRollbackVerified':True,
        'explicitStaticCommitVerified':True,'productionReady':False,'autoWritesVerified':False}


def verify_canary(proof):
    if proof.get('applyAttempted') is not True or proof.get('negativeCanaryCasePassed') is not True or proof.get('foreignPendingCanaryUnchangedObserved') is not True:
        raise ValueError('Foreign pending canary changed or was not tested.')
    if proof.get('globalReloadIsolationVerified') is not False:raise ValueError('Unbounded reload safety claim is not allowed.')
    before,after=proof['before'],proof['after']
    for state in (before,after):
        if digest(state['canonical'])!=state['revision']:raise ValueError('Canary canonical revision mismatch.')
    canary_before=next(a for a in before['canonical']['adapters'] if a['name']=='w3canary0')
    canary_after=next(a for a in after['canonical']['adapters'] if a['name']=='w3canary0')
    if proof['initialCanary']!=canary_before or canary_after!=canary_before or before['revision']!=after['revision']:
        raise ValueError('Canary baseline changed or was already loaded before target Apply.')
    if canary_before.get('mac')!='02:73:33:00:00:03':raise ValueError('Wrong canary identity.')
    artifact=proof['pendingArtifact'];path='/run/systemd/network/00-00-worker3-pending-canary.network'
    if artifact['path']!=path or canary_before.get('selectedConfig')==path or hashlib.sha256(artifact['text'].encode()).hexdigest()!=artifact['sha256']:
        raise ValueError('Canary pending artifact identity/hash differs.')
    for state in (before,after):
        entry=state['fileGraph'].get(path,{})
        if entry.get('sha256')!=artifact['sha256'] or entry.get('uid')!=0 or entry.get('mode')!=0o600:raise ValueError('Pending file was absent, changed or unsafe.')
    plan=proof['journal'];token=proof['prepared']['token']
    if plan.get('token')!=token or plan.get('phase')!='rolled-back' or plan.get('commitDecision') is not False:
        raise ValueError('Negative canary target was committed or not fully restored.')
    completed=[e for e in proof['reloadEvents'] if e.get('completed') is True and e.get('token')==token and e['endedMonotonic']>=e['beganMonotonic']]
    if not completed:raise ValueError('No completed real guarded reload observed in negative case.')


def check_connection(records):
    expected={('w3test0','-4','192.0.2.1'),('w3test0','-6','2001:db8:3::1'),
              ('w3canary0','-4','198.51.100.1'),('w3canary0','-6','2001:db8:4::1')}
    if len(records)!=4:raise ValueError('Complete guest peer connection checks missing.')
    seen=set()
    for item in records:
        args=item['argv']
        if len(args)!=9 or args[0]!='ping' or args[2]!='-I' or args[4:8]!=['-c','1','-W','2'] or type(item['exitCode']) is not int or item['exitCode']!=0:
            raise ValueError('Connection test failed or command differs.')
        seen.add((args[3],args[1],args[8]))
    if seen!=expected:raise ValueError('Connection checks target unexpected interfaces/peers.')


def check_target(actual,plan,persistent):
    if digest(actual['canonical'])!=actual['revision']:raise ValueError('Actual canonical revision mismatch.')
    target=next(a for a in actual['adapters'] if a['name']=='w3test0');wanted=plan['settings']
    if target['id']!=plan['adapterId'] or target['mtu']!=wanted['mtu'] or sorted(target['dnsServers'])!=sorted(wanted['dnsServers']):raise ValueError('Actual target identity/DNS/MTU differs.')
    if [(a['local'],a['prefixLength']) for a in target['addresses'] if a['family']=='inet']!=[(wanted['address'],wanted['prefixLength'])]:raise ValueError('Actual IPv4 differs.')
    before=next(a for a in plan['baseline']['adapters'] if a['name']=='w3test0')
    if [a for a in actual['canonical']['adapters'] if a['name']!='w3test0']!=[a for a in plan['baseline']['canonical']['adapters'] if a['name']!='w3test0']:
        raise ValueError('Foreign canonical interface changed.')
    for key in ('addresses','routes'):
        if [a for a in target[key] if a['family']=='inet6']!=[a for a in before[key] if a['family']=='inet6']:raise ValueError('IPv6 changed.')
    defaults=[r for r in target['routes'] if r['family']=='inet' and r.get('dst') in ('default','0.0.0.0/0')]
    if (wanted.get('gateway') is None and defaults) or (wanted.get('gateway') is not None and
            (len(defaults)!=1 or defaults[0].get('gateway')!=wanted['gateway'])):raise ValueError('Actual IPv4 default route differs.')
    path=('/etc' if persistent else '/run')+'/systemd/network/'+plan['candidate']['basename']
    if target['selectedConfig']!=path:raise ValueError('Actual selected file differs.')
    graph=dict(actual['fileGraph']);baseline=plan['baseline']['fileGraph']
    for root in ('/run','/etc') if persistent else ('/run',):
        record=graph.pop(root+'/systemd/network/'+plan['candidate']['basename'],None)
        if record is None or record['sha256']!=plan['candidate']['sha256'] or record['uid']!=0 or record['mode']!=0o600:raise ValueError('Owned artifact SHA/mode/owner mismatch.')
    if graph!=baseline:raise ValueError('Foreign file graph changed.')
