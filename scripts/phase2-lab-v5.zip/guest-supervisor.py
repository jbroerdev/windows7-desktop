"""Guest phase2 supervisor; centrally selected isolated cloud-init entrypoint only."""
import base64
import hashlib
import importlib.util
import json
import pathlib

ROOT=pathlib.Path(__file__).resolve().parent
MAX_EVIDENCE=3*1024*1024
EVIDENCE_NAMES={
    'timer-baseline.json','timer-prepared.json','timer-child.json','timer-pending.json',
    'timer-observations-before-any-status.json','timer-service-after-restore.json','timer-final.json',
    'manual-baseline.json','manual-prepared.json','manual-pending.json','manual-final.json',
    'commit-baseline.json','commit-prepared.json','commit-pending.json','commit-final.json','foreign-pending-canary.json','result.json'}


def module(name,file):
    spec=importlib.util.spec_from_file_location(name,ROOT/file)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result


def collect(folder):
    files={};total=0
    for file in sorted(pathlib.Path(folder).glob('*')):
        if file.name not in EVIDENCE_NAMES or file.is_symlink() or not file.is_file():raise ValueError('Unexpected phase2 evidence entry.')
        if file.stat().st_size>512*1024:raise ValueError('Phase2 evidence file too large.')
        data=file.read_bytes();total+=len(data)
        if total>MAX_EVIDENCE:raise ValueError('Phase2 total evidence bound exceeded.')
        files[file.name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'base64':base64.b64encode(data).decode()}
    return files


def main():
    result={'phase':'phase2-static-provider','passed':False,'productionReady':False,'productionAccess':False,
        'autoWritesVerified':False,'crashDuringCommitVerified':False,'globalReloadForeignPendingCaseVerified':False,
        'globalReloadIsolationVerified':False}
    try:
        boot=module('worker3_boot_availability','guest-probe.py')
        if boot.main()!=0:raise ValueError('Same-guest boot availability failed before fixture.')
        fixture=module('worker3_phase2_fixture','guest-fixture.py')
        result['fixture']=fixture.setup()
        cases=module('worker3_phase2_cases','guest-cases.py')
        case_exit=cases.main()
        result['caseExitCode']=case_exit
        result['evidence']=collect(cases.OUTPUT)
        case_result=json.loads(base64.b64decode(result['evidence']['result.json']['base64'],validate=True))
        for key in ('timerRollbackAfterSigkillVerified','manualRollbackVerified','explicitStaticCommitVerified',
                    'positiveCasesPassed','foreignPendingCanaryExecuted','negativeCanaryCasePassed'):
            result[key]=case_result.get(key) is True
        if case_exit!=0 or set(result['evidence'])!=EVIDENCE_NAMES:raise ValueError('Full real case evidence incomplete or failed.')
        if case_result.get('passed') is not True:raise ValueError('Actual cases did not pass.')
        result.update(passed=True,timerRollbackAfterSigkillVerified=True,manualRollbackVerified=True,explicitStaticCommitVerified=True)
    except Exception as error:
        result.update(error=str(error),errorType=type(error).__name__)
        folder=pathlib.Path('/run/worker3-phase2-evidence')
        if folder.is_dir():
            try:result['evidence']=collect(folder)
            except Exception as collect_error:result['evidenceError']=str(collect_error)
    data=json.dumps(result,sort_keys=True).encode()
    with open('/dev/ttyS0','wb',buffering=0) as console:
        console.write(b'\nWORKER3_PHASE2_RESULT '+base64.b64encode(data)+b'\n')
    return 0 if result['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
