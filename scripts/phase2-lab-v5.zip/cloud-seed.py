"""Pure cloud-init payload builder. Does not run cloud-init, managers or QEMU."""
import base64
import pathlib

CORE=('networkd_model.py','networkd_provider.py','networkd_system.py','networkd_cli.py')
GUEST=('guest-fixture.py','guest-apply-child.py','guest-cases.py','guest-supervisor.py')


def cloud_config(core_folder,guest_folder,boot_folder):
    core_folder=pathlib.Path(core_folder);guest_folder=pathlib.Path(guest_folder);boot_folder=pathlib.Path(boot_folder)
    files=[]
    for root,names in ((core_folder,CORE),(guest_folder,GUEST),(boot_folder,('guest-probe.py','read-only-manager-probe.py'))):
        for name in names:
            file=root/name
            if file.is_symlink() or not file.is_file() or file.stat().st_size>256*1024:raise ValueError('Invalid own guest source.')
            files.append({'path':'/opt/worker3-lab/'+name,'owner':'root:root','permissions':'0600','encoding':'b64',
                'content':base64.b64encode(file.read_bytes()).decode()})
    files.append({'path':'/run/worker3-networkd-lab/phase2-permit','owner':'root:root','permissions':'0600',
        'content':'worker3-phase2-qemu-guest-only-v1\n'})
    return {'users':[],'disable_root':True,'ssh_pwauth':False,'write_files':files,
        'runcmd':[['python3','/opt/worker3-lab/guest-supervisor.py'],['systemctl','poweroff']]}
