"""Isolated transaction engine. Concrete manager backend is selected separately.

No import-time I/O. Browser/Node authorization must still be revalidated externally.
No snapshot or unit test makes this a production write release.
"""
import copy
import hashlib
import json
import os
import pathlib
import time
import uuid
from contextlib import contextmanager
from networkd_model import ProviderError, UUID, MANAGER, ROLLBACK, request, settings, plan_view


class JournalStore:
    """Root-owned atomic state with a process-shared lock; Unix runtime only."""
    def __init__(self, file):self.file=pathlib.Path(file)

    @contextmanager
    def locked(self):
        import fcntl
        if os.geteuid() != 0:raise PermissionError('Root-owned provider journal required.')
        self.file.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        for item in [self.file.parent,*self.file.parent.parents]:
            if item.is_symlink():raise ValueError('No journal symlinks.')
        info=self.file.parent.stat()
        if info.st_uid != 0 or info.st_mode & 0o077:raise PermissionError('Private journal directory required.')
        lock=os.open(str(self.file)+'.lock',os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600)
        try:
            fcntl.flock(lock,fcntl.LOCK_EX)
            yield
        finally:fcntl.flock(lock,fcntl.LOCK_UN);os.close(lock)

    def load(self):
        if not self.file.exists():return {'version':1,'plans':{}}
        descriptor=os.open(self.file,os.O_RDONLY|os.O_NOFOLLOW)
        with os.fdopen(descriptor,'rb') as stream:
            info=os.fstat(stream.fileno())
            if info.st_uid != 0 or info.st_mode & 0o077 or info.st_size > 4*1024*1024:
                raise PermissionError('Invalid private journal.')
            result=json.load(stream)
        if result.get('version') != 1 or not isinstance(result.get('plans'),dict) or len(result['plans']) > 16:
            raise ValueError('Invalid provider journal shape.')
        for token,plan in result['plans'].items():
            if not UUID.fullmatch(token) or plan.get('token') != token:
                raise ValueError('Invalid persisted token.')
        return result

    def save(self, state):
        data=json.dumps(state,sort_keys=True,separators=(',',':')).encode()
        if len(data)>4*1024*1024:raise ValueError('Journal size limit.')
        temporary=self.file.with_name(self.file.name+'.'+str(uuid.uuid4())+'.tmp')
        descriptor=os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        try:
            with os.fdopen(descriptor,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
            os.replace(temporary,self.file)
            parent=os.open(self.file.parent,os.O_RDONLY|os.O_DIRECTORY)
            try:os.fsync(parent)
            finally:os.close(parent)
        finally:
            if temporary.exists():temporary.unlink()


class NetworkdProvider:
    """Backend protocol performs real capture/stage/timer/file/manager operations.

    Requires backend.capture/public_snapshot/build_candidate/check_baseline,
    check_pending/arm_timer/install_runtime/restore/persist/verify_committed/
    disarm_timer/timer_state. The concrete system backend is never replaced by a
    success DTO in a real-run entrypoint. Tests may inject explicit lab doubles.
    """
    def __init__(self,state_file,backend,allow_changes=False,store=None,rollback_seconds=60):
        if type(rollback_seconds) is not int or not 30 <= rollback_seconds <= 120:
            raise ValueError('Rollback window must be30..120seconds.')
        self.backend=backend;self.store=store or JournalStore(state_file)
        self.allow_changes=allow_changes is True;self.rollback_seconds=rollback_seconds

    def _view(self, token, plan):return plan_view(token,plan,self.backend.monotonic())

    def _owned_plan(self,state,token,owner):
        plan=state['plans'].get(token)
        if not plan or plan['owner'] != owner:
            raise ProviderError('permission-denied','Transaction belongs to a different personal actor.')
        return plan

    def _rollback(self,state,plan):
        if plan['phase'] in ('confirmed','rolled-back','expired','cancelled'):return
        if plan.get('commitDecision'):
            # A durable explicit commit decision is never silently converted to rollback.
            return self._finish_commit(state,plan)
        try:
            self.backend.restore(plan)
            plan.update(phase='rolled-back',error=None,errorCode=None)
            self.store.save(state)
            self.backend.disarm_timer(plan)
            plan.update(timerArmed=False,timerState='elapsed')
        except Exception as error:
            plan.update(phase='rollback-failed',error='Owned rollback could not be fully verified.',errorCode='rollback-failed')
            plan['diagnosticType']=type(error).__name__
        self.store.save(state)

    def _finish_commit(self,state,plan):
        if not plan.get('commitDecision'):raise ProviderError('permission-denied','No durable user commit decision.')
        try:
            self.backend.check_pending(plan,allow_persistent=True)
            self.backend.persist(plan)
            self.backend.verify_committed(plan)
            plan.update(phase='confirmed',error=None,errorCode=None)
            self.store.save(state)
            self.backend.disarm_timer(plan)
            plan.update(timerArmed=False,timerState='not-armed')
            self.store.save(state)
        except Exception as error:
            # Keep the accepted decision and timer/recovery evidence. No fabricated
            # confirmed result and no destructive generic rollback on uncertainty.
            plan.update(phase='committing',error='Commit requires journal recovery.',errorCode='commit-uncertain')
            plan['diagnosticType']=type(error).__name__;self.store.save(state)
            raise ProviderError('commit-uncertain','Explicit commit accepted but persistence not fully verified.') from error

    def _recover(self,state):
        for plan in state['plans'].values():
            if plan['phase'] == 'prepared' and self.backend.wall_time() >= plan['expiresAt']:
                plan['phase']='expired';self.store.save(state)
            if plan['phase'] in ('applying','pending','committing'):
                if self.backend.boot_id() != plan['bootId']:
                    plan.update(phase='rollback-failed',error='Boot identity changed; recovery needs explicit verification.',errorCode='boot-changed')
                    self.store.save(state);continue
                if plan.get('commitDecision'):
                    self._finish_commit(state,plan)
                elif self.backend.monotonic() >= plan['deadlineMonotonic']:
                    self._rollback(state,plan)

    def recover(self,token):
        """Local root/systemd helper only, never a public unauthenticated action."""
        if not UUID.fullmatch(token):raise ValueError('Invalid local recovery token.')
        with self.store.locked():
            state=self.store.load();plan=state['plans'].get(token)
            if not plan:raise ValueError('Recovery journal missing.')
            if plan['phase'] in ('confirmed','rolled-back','cancelled','expired'):return self._view(token,plan)
            if self.backend.boot_id()!=plan['bootId']:
                raise ProviderError('boot-changed','No unverified cross-boot manager operation.')
            if plan.get('commitDecision'):self._finish_commit(state,plan)
            elif self.backend.monotonic()>=plan['deadlineMonotonic']:self._rollback(state,plan)
            else:raise ProviderError('plan-not-due','Independent timer fired before the protected deadline.')
            return self._view(token,plan)

    def execute(self,action,data):
        owner=request(action,data)
        with self.store.locked():
            state=self.store.load();self._recover(state)
            if action=='snapshot':
                observed=self.backend.capture(self.allow_changes)
                return self.backend.public_snapshot(observed)
            if action=='prepare':
                if not self.allow_changes:raise ProviderError('permission-denied','Host writes are not opted in.')
                if any(p['phase'] in ('applying','pending','committing','rollback-failed') for p in state['plans'].values()):
                    raise ProviderError('revision-conflict','Another network transaction requires resolution.')
                if len(state['plans'])>=16:raise ProviderError('transaction-limit','Journal retention requires explicit safe maintenance.')
                configured=settings(data.get('settings'))
                baseline=self.backend.capture(True)
                if baseline['revision']!=data['expectedRevision']:
                    raise ProviderError('revision-conflict','Native configuration changed; refresh before preparing.')
                adapter=next((a for a in baseline['adapters'] if a['id']==data['adapterId']),None)
                if not adapter or adapter['capabilities'].get('configureIpv4') is not True:
                    raise ProviderError('unsupported','Exact config/identity/timer mapping is not writable.')
                token=str(uuid.uuid4())
                candidate=self.backend.build_candidate(adapter,configured,token,baseline,state['plans'])
                plan={'token':token,'owner':owner,'phase':'prepared','adapterId':adapter['id'],'name':adapter['name'],
                    'settings':configured,'baseline':baseline,'candidate':candidate,'bootId':self.backend.boot_id(),
                    'expiresAt':self.backend.wall_time()+300,'createdAt':self.backend.wall_time(),
                    'timerArmed':False,'timerState':'not-armed','commitDecision':False}
                state['plans'][token]=plan;self.store.save(state)
                return self._view(token,plan)
            token=data['token'];plan=self._owned_plan(state,token,owner)
            if action=='status':
                if plan.get('timerArmed'):plan['timerState']=self.backend.timer_state(plan)
                return self._view(token,plan)
            if action=='rollback':
                if plan['phase']=='prepared':plan['phase']='cancelled';self.store.save(state)
                elif plan['phase'] not in ('confirmed','rolled-back','cancelled','expired'):
                    self._rollback(state,plan)
                return self._view(token,plan)
            if not self.allow_changes:raise ProviderError('permission-denied','Host writes are not opted in.')
            if action=='apply':
                if plan['phase']!='prepared' or self.backend.wall_time()>=plan['expiresAt']:
                    raise ProviderError('plan-expired','Prepared transaction expired or already used.')
                if self.backend.boot_id()!=plan['bootId']:raise ProviderError('revision-conflict','Boot identity changed.')
                self.backend.check_baseline(plan)
                plan.update(phase='applying',deadlineMonotonic=self.backend.monotonic()+self.rollback_seconds,
                    confirmBy=self.backend.wall_time()+self.rollback_seconds)
                self.store.save(state)
                try:
                    timer=self.backend.arm_timer(plan,self.rollback_seconds)
                    plan.update(timerArmed=True,timerState='active',timer=timer)
                    if timer.get('deadlineMonotonic') is not None:
                        actual=timer['deadlineMonotonic']
                        if not self.backend.monotonic()<actual<=plan['deadlineMonotonic']+3:
                            raise ValueError('Unverified actual manager timer deadline.')
                        plan.update(deadlineMonotonic=actual,
                            confirmBy=self.backend.wall_time()+actual-self.backend.monotonic())
                    self.store.save(state)
                    self.backend.check_baseline(plan)
                    self.backend.install_runtime(plan)
                    self.backend.check_pending(plan)
                    if self.backend.monotonic()>=plan['deadlineMonotonic']:
                        raise ProviderError('plan-expired','Apply exhausted rollback window.')
                    plan['phase']='pending';self.store.save(state)
                except Exception:
                    self._rollback(state,plan)
                    raise
                return self._view(token,plan)
            if action=='confirm':
                if plan['phase']=='confirmed':return self._view(token,plan)
                if plan['phase']!='pending' or self.backend.monotonic()>=plan['deadlineMonotonic']:
                    raise ProviderError('plan-expired','Pending transaction cannot be committed.')
                if self.backend.boot_id()!=plan['bootId']:raise ProviderError('revision-conflict','Boot identity changed.')
                self.backend.check_pending(plan)
                plan.update(phase='committing',commitDecision=True,commitDecisionAt=self.backend.wall_time())
                self.store.save(state)
                self._finish_commit(state,plan)
                return self._view(token,plan)
            raise ProviderError('invalid-request','Unknown state transition.')
