"""Synthetic receiver/seed tests only; never cloud-init or manager execution."""
import base64
import copy
import hashlib
import importlib.util
import json
import pathlib
import unittest

DIR=pathlib.Path(__file__).resolve().parent
def module(name,file):
    spec=importlib.util.spec_from_file_location(name,DIR/file)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result
receipt=module('phase2_receipt','phase2-receipt.py')
seed=module('phase2_seed','cloud-seed.py')


def connections():
    return [{'argv':['ping',f,'-I',n,'-c','1','-W','2',p],'exitCode':0} for n,f,p in
        [('w3test0','-4','192.0.2.1'),('w3test0','-6','2001:db8:3::1'),
         ('w3canary0','-4','198.51.100.1'),('w3canary0','-6','2001:db8:4::1')]]


def target_fixture():
    adapter={'name':'w3test0','id':'2:test','mtu':1400,'dnsServers':['192.0.2.53'],
        'addresses':[{'family':'inet','local':'192.0.2.20','prefixLength':24},
                     {'family':'inet6','local':'2001:db8:3::10','prefixLength':64}],
        'routes':[],'selectedConfig':'/run/systemd/network/own.network'}
    plan={'adapterId':'2:test','settings':{'mtu':1400,'dnsServers':['192.0.2.53'],'address':'192.0.2.20','prefixLength':24},
        'candidate':{'basename':'own.network','sha256':'a'*64},
        'baseline':{'adapters':[copy.deepcopy(adapter)],'canonical':{'adapters':[copy.deepcopy(adapter)]},'fileGraph':{'/etc/netplan/existing.yaml':{'sha256':'b'*64}}}}
    graph={**plan['baseline']['fileGraph'],'/run/systemd/network/own.network':{'sha256':'a'*64,'uid':0,'mode':0o600}}
    actual={'adapters':[adapter],'fileGraph':graph,'canonical':{'adapters':[copy.deepcopy(adapter)]}}
    actual['revision']=receipt.digest(actual['canonical'])
    return plan,actual


def full_synthetic_receipt():
    """Complete protocol fixture, explicitly not actual manager evidence."""
    plan,_=target_fixture();target=copy.deepcopy(plan['baseline']['adapters'][0])
    target.update(mtu=1500,dnsServers=['192.0.2.54'],selectedConfig='/run/systemd/network/10-netplan-w3test0.network')
    target['addresses'][0]['local']='192.0.2.10'
    adapters=[{'name':n} for n in ('lo','w3boot0')]+[{'name':'w3canary0','mac':'02:73:33:00:00:03',
        'selectedConfig':'/run/systemd/network/10-netplan-w3canary0.network'}]+[target]
    baseline={'adapters':adapters,'fileGraph':plan['baseline']['fileGraph']}
    def canonical(state):
        state['canonical']={'adapters':copy.deepcopy(state['adapters']),'fileGraph':copy.deepcopy(state['fileGraph'])}
        state['revision']=receipt.digest(state['canonical']);return state
    canonical(baseline);docs={}
    for index,label in enumerate(('timer','manual','commit'),1):
        token='00000000-0000-0000-0000-'+str(index).zfill(12)
        unit='windows7-web-networkd-'+token
        candidate={'basename':'own'+str(index)+'.network','sha256':str(index)*64}
        settings={'address':'192.0.2.'+str(index*10+10),'prefixLength':24,'mtu':1400-index*20,
                  'gateway':None,'dnsServers':['192.0.2.53']}
        plan={'token':token,'adapterId':target['id'],'name':'w3test0','phase':'pending','commitDecision':False,
            'timerArmed':True,'deadlineMonotonic':160,'baseline':copy.deepcopy(baseline),'settings':settings,'candidate':candidate,
            'timer':{'unit':unit,'deadlineMonotonic':160,'armedMonotonic':101,'serviceCommandVerified':True,
                'actualTriggers':[unit+'.service'],'actualExecStart':[['/usr/bin/python3',
                ['/usr/bin/python3','/opt/worker3-lab/networkd_cli.py','recover','--token',token]]]}}
        actual=copy.deepcopy(baseline);changed=next(a for a in actual['adapters'] if a['name']=='w3test0')
        changed.update(mtu=settings['mtu'],dnsServers=settings['dnsServers'],selectedConfig='/run/systemd/network/'+candidate['basename'])
        changed['addresses'][0]['local']=settings['address']
        own={'sha256':candidate['sha256'],'uid':0,'mode':0o600}
        actual['fileGraph']['/run/systemd/network/'+candidate['basename']]=own;canonical(actual)
        docs[label+'-baseline.json']=copy.deepcopy(baseline)
        docs[label+'-prepared.json']={'token':token,'phase':'prepared'}
        docs[label+'-pending.json']={'plan':copy.deepcopy(plan),'actual':copy.deepcopy(actual),'persistentAbsent':True,'timerState':'active','connection':connections()}
        if label in ('timer','manual'):
            docs[label+'-final.json']={'plan':{'token':token,'phase':'rolled-back'},'connection':connections(),'fullBaselineRestored':True,'independentRestoreBeforeAnyStatus':True}
        if label=='timer':
            docs['timer-child.json']={'exitCode':-9,'pid':123,'timedOut':False,
                'stdout':json.dumps({'event':'actual-apply-before-sigkill','pid':123,'plan':{'token':token,'phase':'pending'}})}
            docs['timer-observations-before-any-status.json']=[{'phase':'pending','monotonic':120,'revision':actual['revision']},
                {'phase':'rolled-back','monotonic':161,'revision':baseline['revision']}]
            docs['timer-service-after-restore.json']={'unit':unit+'.service','exitCode':0,
                'stdout':'ActiveState=active\nSubState=exited\nResult=success\nExecMainStatus=0\n'}
        if label=='commit':
            plan.update(phase='confirmed',commitDecision=True)
            changed['selectedConfig']='/etc/systemd/network/'+candidate['basename']
            actual['fileGraph'][changed['selectedConfig']]=copy.deepcopy(own);canonical(actual)
            docs['commit-final.json']={'plan':{'token':token,'phase':'confirmed'},'journal':plan,'actual':actual,
                'persistentSha256':candidate['sha256'],'connection':connections()}
    pending_path='/run/systemd/network/00-00-worker3-pending-canary.network'
    pending_text='own synthetic pending canary fixture'
    pending_sha=hashlib.sha256(pending_text.encode()).hexdigest()
    canary_state=copy.deepcopy(docs['commit-final.json']['actual'])
    canary_state['fileGraph'][pending_path]={'sha256':pending_sha,'uid':0,'mode':0o600};canonical(canary_state)
    token='00000000-0000-0000-0000-000000000004'
    docs['foreign-pending-canary.json']={'initialCanary':copy.deepcopy(next(a for a in canary_state['canonical']['adapters'] if a['name']=='w3canary0')),
        'before':canary_state,'after':copy.deepcopy(canary_state),
        'pendingArtifact':{'path':pending_path,'sha256':pending_sha,'text':pending_text},
        'applyAttempted':True,'negativeCanaryCasePassed':True,'foreignPendingCanaryUnchangedObserved':True,'globalReloadIsolationVerified':False,
        'prepared':{'token':token},'journal':{'token':token,'phase':'rolled-back','commitDecision':False},
        'reloadEvents':[{'token':token,'completed':True,'beganMonotonic':200,'endedMonotonic':201}]}
    flags={k:False for k in ('productionReady','productionAccess','autoWritesVerified','crashDuringCommitVerified','globalReloadForeignPendingCaseVerified','globalReloadIsolationVerified')}
    passed={k:True for k in ('timerRollbackAfterSigkillVerified','manualRollbackVerified','explicitStaticCommitVerified',
        'positiveCasesPassed','foreignPendingCanaryExecuted','negativeCanaryCasePassed')}
    def encoded(value):
        data=json.dumps(value,sort_keys=True).encode()
        return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'base64':base64.b64encode(data).decode()}
    files={name:encoded(value) for name,value in docs.items()}
    files['result.json']=encoded({**flags,**passed,'phase':'phase2-static-provider','passed':True,
        'evidence':{name:record['sha256'] for name,record in files.items()}})
    return {**flags,**passed,'phase':'phase2-static-provider','passed':True,'caseExitCode':0,'evidence':files}


class ReceiptTests(unittest.TestCase):
    def test_complete_synthetic_receipt_and_removed_evidence(self):
        value=full_synthetic_receipt()
        self.assertEqual(receipt.verify(value)['phase2EvidenceFilesVerified'],17)
        value['evidence'].pop('timer-child.json')
        with self.assertRaises(ValueError):receipt.verify(value)

    def test_foreign_canary_change_incomplete_reload_or_commit_blocks_pass(self):
        encoded=full_synthetic_receipt()['evidence']['foreign-pending-canary.json']
        proof=json.loads(base64.b64decode(encoded['base64']))
        receipt.verify_canary(proof)
        for field in ('canary','reload','commit','pending'):
            with self.subTest(field=field):
                changed=copy.deepcopy(proof)
                if field=='canary':
                    item=next(a for a in changed['after']['canonical']['adapters'] if a['name']=='w3canary0')
                    item['selectedConfig']=changed['pendingArtifact']['path']
                    changed['after']['revision']=receipt.digest(changed['after']['canonical'])
                if field=='reload':changed['reloadEvents'][0]['completed']=False
                if field=='commit':changed['journal']['commitDecision']=True
                if field=='pending':changed['before']['fileGraph'].pop(changed['pendingArtifact']['path'])
                with self.assertRaises(ValueError):receipt.verify_canary(changed)
    def test_connection_exact_peers_and_failures(self):
        receipt.check_connection(connections())
        for mutation in (lambda d:d.pop(),lambda d:d[0].update(exitCode=1),lambda d:d[0]['argv'].__setitem__(3,'eth0'),
                         lambda d:d[0]['argv'].__setitem__(8,'8.8.8.8'),lambda d:d[0].update(exitCode=False)):
            data=connections();mutation(data)
            with self.assertRaises(ValueError):receipt.check_connection(data)

    def test_target_file_ipv6_dns_mtu_canonical_fail_closed(self):
        plan,actual=target_fixture();receipt.check_target(actual,plan,False)
        mutations=[lambda d:d['adapters'][0].update(mtu=1500),lambda d:d['adapters'][0].update(dnsServers=[]),
            lambda d:d['adapters'][0]['addresses'][0].update(local='192.0.2.21'),
            lambda d:d['adapters'][0]['addresses'][1].update(local='2001:db8:3::11'),
            lambda d:d['adapters'][0].update(selectedConfig='/etc/foreign.network'),
            lambda d:d['fileGraph']['/run/systemd/network/own.network'].update(uid=1000),
            lambda d:d['fileGraph']['/run/systemd/network/own.network'].update(mode=0o666),
            lambda d:d['fileGraph'].update({'/etc/foreign.conf':{}}),lambda d:d.update(revision='0'*64)]
        for index,mutation in enumerate(mutations):
            with self.subTest(index=index):
                data=copy.deepcopy(actual);mutation(data)
                with self.assertRaises(ValueError):receipt.check_target(data,plan,False)

    def test_persistent_requires_both_owned_files_and_selected_etc(self):
        plan,actual=target_fixture()
        actual['fileGraph']['/etc/systemd/network/own.network']=copy.deepcopy(actual['fileGraph']['/run/systemd/network/own.network'])
        actual['adapters'][0]['selectedConfig']='/etc/systemd/network/own.network'
        receipt.check_target(actual,plan,True)
        actual['fileGraph'].pop('/run/systemd/network/own.network')
        with self.assertRaises(ValueError):receipt.check_target(actual,plan,True)

    def test_missing_case_or_unbounded_file_is_not_a_pass(self):
        flags={k:False for k in ('productionReady','productionAccess','autoWritesVerified','crashDuringCommitVerified','globalReloadForeignPendingCaseVerified')}
        value={**flags,'phase':'phase2-static-provider','passed':True,'caseExitCode':0,'evidence':{}}
        with self.assertRaises(ValueError):receipt.verify(value)
        value['evidence']={name:{'bytes':999999999,'sha256':'a'*64,'base64':''} for name in receipt.NAMES}
        with self.assertRaises(ValueError):receipt.verify(value)
        value['caseExitCode']=False
        with self.assertRaises(ValueError):receipt.verify(value)

    def test_seed_uses_only_fixed_root_owned_source_files_and_explicit_permit(self):
        core=DIR if (DIR/'networkd_provider.py').is_file() else DIR.parent
        boot=DIR if (DIR/'guest-probe.py').is_file() else DIR.parent/'boot-lab'
        config=seed.cloud_config(core,DIR,boot)
        self.assertEqual(config['runcmd'],[['python3','/opt/worker3-lab/guest-supervisor.py'],['systemctl','poweroff']])
        self.assertEqual(len(config['write_files']),11)
        for file in config['write_files']:
            self.assertEqual(file['owner'],'root:root');self.assertEqual(file['permissions'],'0600')
            self.assertNotIn('eth0',file['path'])
        names={pathlib.PurePosixPath(f['path']).name for f in config['write_files']}
        self.assertEqual(names,set(seed.CORE)|set(seed.GUEST)|{'guest-probe.py','read-only-manager-probe.py','phase2-permit'})


if __name__=='__main__':unittest.main(verbosity=2)
