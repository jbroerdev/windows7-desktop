"""Actual manager cases, never run by Worker3 locally. Import has no side effects.

Requires a fresh disposable guest prepared by guest-fixture.py and centrally
selected phase2 cloud-init. This file does not set up/authorize its own fixture.
"""
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time
from networkd_provider import NetworkdProvider
from networkd_system import SystemBackend, STATE_FILE

ACTOR={'owner':'worker3-phase2-lab','admin':True}
OUTPUT=pathlib.Path('/run/worker3-phase2-evidence')


class AuditedSystemBackend(SystemBackend):
    """Observation only: every reload still invokes the real guarded base method."""
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.reload_events=[]
    def _reload(self,plan):
        event={'token':plan['token'],'beganMonotonic':self.monotonic(),'completed':False}
        self.reload_events.append(event)
        try:
            super()._reload(plan)
            event['completed']=True
        finally:event['endedMonotonic']=self.monotonic()


def record(name,value):
    file=OUTPUT/(name+'.json')
    data=json.dumps(value,sort_keys=True,indent=2).encode()
    with file.open('xb') as stream:stream.write(data)
    return {'file':file.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}


def journal_plan(token):
    # Read-only observation: never invokes provider status/recovery.
    return json.loads(STATE_FILE.read_text())['plans'][token]


def connection():
    output=[]
    for name,family,target in (('w3test0','-4','192.0.2.1'),('w3test0','-6','2001:db8:3::1'),
                               ('w3canary0','-4','198.51.100.1'),('w3canary0','-6','2001:db8:4::1')):
        argv=['ping',family,'-I',name,'-c','1','-W','2',target]
        run=subprocess.run(argv,stdin=subprocess.DEVNULL,capture_output=True,timeout=4,check=False)
        output.append({'argv':argv,'exitCode':run.returncode,'stdout':run.stdout.decode(errors='replace'),'stderr':run.stderr.decode(errors='replace')})
        if run.returncode:raise ValueError('Guest-only peer connection test failed: '+name+' '+family)
    return output


def settings(address,mtu):
    return {'ipv4Method':'manual','address':address,'prefixLength':24,'gateway':None,
            'dnsMode':'manual','dnsServers':['192.0.2.53'],'mtu':mtu}


def execute(provider,action,**data):return provider.execute(action,{**ACTOR,**data})


def child_message(returncode,stdout):
    if returncode!=-9:raise ValueError('Real applying process did not die by SIGKILL after apply.')
    message=json.loads(stdout)
    if message.get('event')!='actual-apply-before-sigkill' or message.get('plan',{}).get('phase')!='pending':
        raise ValueError('Child did not report actual pending apply.')
    return message


def helper_completed(text):
    fields=dict(line.split('=',1) for line in text.splitlines() if '=' in line)
    return all(fields.get(k)==v for k,v in {'Result':'success','ExecMainStatus':'0','ActiveState':'active','SubState':'exited'}.items())


def prepare(provider,backend,address,mtu,label):
    baseline=backend.capture(True)
    target=next(a for a in baseline['adapters'] if a['name']=='w3test0')
    if {a['name'] for a in baseline['adapters']}!={'lo','w3boot0','w3test0','w3canary0'}:
        raise ValueError('Unexpected host interface; eth0 is never a phase2 target.')
    if not target['capabilities']['configureIpv4']:raise ValueError('Candidate did not prove target write eligibility.')
    record(label+'-baseline',baseline)
    prepared=execute(provider,'prepare',adapterId=target['id'],expectedRevision=baseline['revision'],settings=settings(address,mtu))
    record(label+'-prepared',prepared)
    if backend.capture(True)['revision']!=baseline['revision']:raise ValueError('Prepare changed measured manager/files/kernel state.')
    return prepared['token'],baseline


def observe_pending(backend,token,label):
    plan=journal_plan(token)
    if plan['phase']!='pending' or plan.get('commitDecision'):raise ValueError('Expected uncommitted pending journal.')
    backend.check_pending(plan)
    runtime,persistent=backend._paths(plan)
    if not runtime.is_file() or persistent.exists():raise ValueError('Only runtime artifact allowed before explicit commit.')
    record(label+'-pending',{'plan':plan,'actual':backend.capture(True),'connection':connection(),
        'timerState':backend.timer_state(plan),'persistentAbsent':True})
    return plan


def timer_case(provider,backend):
    token,baseline=prepare(provider,backend,'192.0.2.20',1400,'timer')
    child=subprocess.Popen([sys.executable,str(pathlib.Path(__file__).with_name('guest-apply-child.py'))],
        stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    try:stdout,stderr=child.communicate(json.dumps({'token':token,'owner':ACTOR['owner']}).encode(),timeout=50)
    except subprocess.TimeoutExpired:
        child.kill();stdout,stderr=child.communicate(timeout=10)
        record('timer-child',{'pid':child.pid,'exitCode':child.returncode,'timedOut':True,
            'stdout':stdout.decode(errors='replace'),'stderr':stderr.decode(errors='replace')})
        raise ValueError('Applying child timed out; no post-apply SIGKILL proof.')
    record('timer-child',{'pid':child.pid,'exitCode':child.returncode,'timedOut':False,
        'stdout':stdout.decode(errors='replace'),'stderr':stderr.decode(errors='replace')})
    if child_message(child.returncode,stdout).get('pid')!=child.pid:raise ValueError('Apply child reported different process identity.')
    pending=observe_pending(backend,token,'timer')
    samples=[];end=pending['deadlineMonotonic']+35
    # Crucially: no execute/status/recover after child death until restoration is
    # independently observed in real state AND timer helper's durable journal.
    while time.monotonic()<end:
        current=backend.capture(True);plan=journal_plan(token)
        samples.append({'monotonic':time.monotonic(),'phase':plan['phase'],'revision':current['revision'],
                        'selectedConfig':next(a['selectedConfig'] for a in current['adapters'] if a['name']=='w3test0')})
        if plan['phase']=='rolled-back' and current['revision']==baseline['revision']:break
        if plan['phase']=='rollback-failed':raise ValueError('Independent timer helper could not verify restoration.')
        time.sleep(2)
    else:raise ValueError('No independently observed complete timer restoration.')
    record('timer-observations-before-any-status',samples)
    backend.check_baseline(pending)
    service=pending['timer']['unit']+'.service'
    until=time.monotonic()+8
    while True:
        unit=subprocess.run(['systemctl','show',service,'--property=ActiveState,SubState,Result,ExecMainCode,ExecMainStatus'],
            capture_output=True,timeout=5,check=False)
        if unit.returncode==0 and helper_completed(unit.stdout.decode()):break
        if time.monotonic()>=until:raise ValueError('Actual independent helper service has not completed successfully.')
        time.sleep(.2)
    record('timer-service-after-restore',{'unit':service,'exitCode':unit.returncode,'stdout':unit.stdout.decode(),'stderr':unit.stderr.decode()})
    result=execute(provider,'status',token=token)
    if result['phase']!='rolled-back':raise ValueError('Fresh status disagrees with prior independent restoration.')
    record('timer-final',{'plan':result,'connection':connection(),'independentRestoreBeforeAnyStatus':True})


def manual_case(provider,backend):
    token,baseline=prepare(provider,backend,'192.0.2.30',1380,'manual')
    execute(provider,'apply',token=token,confirmed=True)
    plan=observe_pending(backend,token,'manual')
    result=execute(provider,'rollback',token=token)
    backend.check_baseline(plan)
    if result['phase']!='rolled-back' or backend.capture(True)['revision']!=baseline['revision']:raise ValueError('Manual restoration not exact.')
    record('manual-final',{'plan':result,'connection':connection(),'fullBaselineRestored':True})


def commit_case(provider,backend):
    token,_=prepare(provider,backend,'192.0.2.40',1360,'commit')
    execute(provider,'apply',token=token,confirmed=True)
    observe_pending(backend,token,'commit')
    # Actual readback plus remote-in-guest peer connection precede explicit decision.
    result=execute(provider,'confirm',token=token,confirmed=True)
    plan=journal_plan(token);backend.verify_committed(plan)
    runtime,persistent=backend._paths(plan)
    if result['phase']!='confirmed' or not plan.get('commitDecision') or not persistent.is_file():raise ValueError('Durable explicit commit not proven.')
    if hashlib.sha256(persistent.read_bytes()).hexdigest()!=plan['candidate']['sha256']:raise ValueError('Persisted bytes differ.')
    record('commit-final',{'plan':result,'journal':plan,'actual':backend.capture(True),'connection':connection(),
        'runtimeRetained':runtime.exists(),'persistentSha256':hashlib.sha256(persistent.read_bytes()).hexdigest()})


def foreign_pending_case(provider,backend):
    """Negative gate after the three positives; never masks a foreign change."""
    backend._lab_guard()
    initial=backend.capture(True)
    canary=next(a for a in initial['adapters'] if a['name']=='w3canary0')
    if canary.get('mac')!='02:73:33:00:00:03':raise ValueError('Exact disposable canary MAC required.')
    pending=pathlib.Path('/run/systemd/network/00-00-worker3-pending-canary.network')
    text='[Match]\nName=w3canary0\nMACAddress=02:73:33:00:00:03\n\n[Link]\nMTUBytes=1500\n\n[Network]\nLinkLocalAddressing=no\nIPv6AcceptRA=no\nAddress=198.51.100.20/24\nAddress=2001:db8:4::10/64\nDNS=192.0.2.54\n'
    descriptor=os.open(pending,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(descriptor,'w') as stream:stream.write(text);stream.flush();os.fsync(stream.fileno())
    # Publish fixture profile ONLY; do not reload it. It is foreign to the provider.
    before=backend.capture(True)
    before_canary=next(a for a in before['canonical']['adapters'] if a['name']=='w3canary0')
    initial_canary=next(a for a in initial['canonical']['adapters'] if a['name']=='w3canary0')
    proof={'initialCanary':initial_canary,'before':before,'pendingArtifact':{'path':str(pending),
        'sha256':hashlib.sha256(pending.read_bytes()).hexdigest(),'text':text},'applyAttempted':False,
        'foreignPendingCanaryUnchangedObserved':False,'globalReloadIsolationVerified':False}
    try:
        if initial_canary!=before_canary or before_canary['selectedConfig']==str(pending):
            raise ValueError('Foreign fixture was not still pending before target Apply.')
        target=next(a for a in before['adapters'] if a['name']=='w3test0')
        prepared=execute(provider,'prepare',adapterId=target['id'],expectedRevision=before['revision'],settings=settings('192.0.2.50',1340))
        proof['prepared']=prepared
        start=len(backend.reload_events)
        proof['applyAttempted']=True
        try:
            applied=execute(provider,'apply',token=prepared['token'],confirmed=True)
            proof['applyResult']=applied
            # No commit is ever accepted in this negative case.
            proof['rollbackResult']=execute(provider,'rollback',token=prepared['token'])
        except Exception as error:
            proof['applyError']={'code':getattr(error,'code',None),'type':type(error).__name__,'message':str(error)}
        proof['reloadEvents']=backend.reload_events[start:]
        proof['journal']=journal_plan(prepared['token'])
        proof['after']=backend.capture(True)
        after_canary=next(a for a in proof['after']['canonical']['adapters'] if a['name']=='w3canary0')
        unchanged=(before_canary==after_canary and proof['after']['revision']==before['revision'])
        proof['foreignPendingCanaryUnchangedObserved']=unchanged
        proof['outcome']='foreign-change-observed' if before_canary!=after_canary else 'full-baseline-not-restored' if not unchanged else 'no-foreign-change-observed'
        if not any(e['completed'] for e in proof['reloadEvents']):
            raise ValueError('No completed real reload in negative canary case; not a tested isolation result.')
        if proof['journal']['phase']!='rolled-back' or proof['journal'].get('commitDecision') or not unchanged:
            raise ValueError('Global reload activated foreign pending configuration or restoration was incomplete.')
        proof['negativeCanaryCasePassed']=True
    except Exception as error:
        proof.update(negativeCanaryCasePassed=False,errorType=type(error).__name__,error=str(error))
        if 'after' not in proof:proof['after']=backend.capture(True)
    record('foreign-pending-canary',proof)
    return proof['negativeCanaryCasePassed']


def main():
    if not pathlib.Path('/run/worker3-networkd-lab/phase2-permit').is_file():raise ValueError('No explicitly prepared phase2 guest.')
    OUTPUT.mkdir(mode=0o700,exist_ok=False)
    result={'phase':'phase2-static-provider','passed':False,'productionReady':False,
            'autoWritesVerified':False,'crashDuringCommitVerified':False,'globalReloadForeignPendingCaseVerified':False,
            'foreignPendingCanaryExecuted':False,'negativeCanaryCasePassed':False,'globalReloadIsolationVerified':False}
    try:
        backend=AuditedSystemBackend(STATE_FILE,isolated_lab=True);backend._lab_guard()
        provider=NetworkdProvider(STATE_FILE,backend,allow_changes=True)
        timer_case(provider,backend);result['timerRollbackAfterSigkillVerified']=True
        manual_case(provider,backend);result['manualRollbackVerified']=True
        commit_case(provider,backend);result['explicitStaticCommitVerified']=True
        result['positiveCasesPassed']=True
        result['foreignPendingCanaryExecuted']=True
        result['negativeCanaryCasePassed']=foreign_pending_case(provider,backend)
        if not result['negativeCanaryCasePassed']:raise ValueError('Foreign pending canary gate failed; no overall Phase2 pass.')
        result['passed']=True
    except Exception as error:result.update(errorType=type(error).__name__,error=str(error))
    result['evidence']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUTPUT.glob('*.json'))}
    record('result',result)
    print(json.dumps(result,sort_keys=True),flush=True)
    return 0 if result['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
