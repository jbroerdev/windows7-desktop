"""Reproduce shell redirection sequence without Docker/guest/manager operations."""
import hashlib
import importlib.util
import json
import pathlib
import sys
import tempfile
import unittest

DIR=pathlib.Path(__file__).resolve().parent
GUARD=DIR/'lab-guard.py' if (DIR/'lab-guard.py').is_file() else DIR.parent/'boot-lab/lab-guard.py'
sys.path.insert(0,str(GUARD.parent))
spec=importlib.util.spec_from_file_location('recording_guard',GUARD)
guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)


class ReceiptRecordingTests(unittest.TestCase):
    def test_finished_summary_is_not_self_hashed_and_original_hashes_stay_stable(self):
        with tempfile.TemporaryDirectory(dir=DIR) as tmp:
            folder=pathlib.Path(tmp);self.assertTrue(folder.resolve().is_relative_to(DIR))
            (folder/'data.txt').write_bytes(b'own synthetic evidence')
            (folder/'container').mkdir()
            (folder/'container/receipt-summary.json').write_text('{"ordinaryNestedEvidence":true}')
            (folder/'receipt-summary.json').write_bytes(b'')  # Shell > opens it first.
            first=guard.finish(folder,1)
            (folder/'receipt-summary.json').write_text(json.dumps(first,sort_keys=True))
            second=guard.finish(folder,1)
            self.assertEqual(first,second)
            self.assertNotIn('receipt-summary.json',second['evidenceSha256'])
            self.assertNotIn('receipt.json',second['evidenceSha256'])
            self.assertIn('container/receipt-summary.json',second['evidenceSha256'])
            for name,expected in second['evidenceSha256'].items():
                self.assertEqual(expected,hashlib.sha256((folder/name).read_bytes()).hexdigest())


if __name__=='__main__':unittest.main(verbosity=2)
