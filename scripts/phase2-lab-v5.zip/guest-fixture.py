"""DISPOSABLE GUEST ONLY. Root must select/run after the boot availability gate.

No import-time operations. Never use this fixture on a native host or on eth0.
"""
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import time

MARKER = pathlib.Path('/run/worker3-networkd-lab/phase2-permit')
PERMIT = 'worker3-phase2-qemu-guest-only-v1\n'
FIXTURE = pathlib.Path('/run/netplan/99-worker3-phase2.yaml')
MACS = {'w3test0':'02:73:33:00:00:01','w3peer0':'02:73:33:00:00:02',
        'w3canary0':'02:73:33:00:00:03','w3canarypeer0':'02:73:33:00:00:04'}


def validate_initial_links(links):
    if not isinstance(links,list) or len(links)!=2 or {link['ifname'] for link in links}!={'lo','w3boot0'}:
        raise ValueError('Fixture requires pristine guest with exactly lo and w3boot0; never eth0.')
    boot=next(link for link in links if link['ifname']=='w3boot0')
    if boot.get('address')!='52:54:00:73:33:01' or type(boot.get('ifindex')) is not int or boot['ifindex']<=0:
        raise ValueError('Unexpected QEMU boot MAC/index.')
    return boot


def run(argv,timeout=20):
    result=subprocess.run(argv,stdin=subprocess.DEVNULL,capture_output=True,timeout=timeout,check=False)
    if result.returncode:raise ValueError('Guest fixture command failed: '+argv[0]+' '+argv[1])
    return result.stdout.decode().strip()


def identity_guard():
    if os.geteuid()!=0 or pathlib.Path('/proc/1/comm').read_text().strip()!='systemd':raise ValueError('Root guest PID1 required.')
    if MARKER.is_symlink() or not MARKER.is_file():raise ValueError('Explicit cloud-init phase2 permit required.')
    info=MARKER.stat()
    if info.st_uid!=0 or info.st_mode&0o077 or MARKER.read_text()!=PERMIT:raise ValueError('Unsafe phase2 permit.')
    # QEMU firmware plus dedicated Name/MAC and absence of other interfaces:
    # marker alone is never sufficient to authorize a production host.
    vendor=pathlib.Path('/sys/class/dmi/id/sys_vendor').read_text().strip()
    product=pathlib.Path('/sys/class/dmi/id/product_name').read_text().strip()
    if vendor not in ('QEMU','Bochs') or not any(tag in product for tag in ('QEMU','Standard PC')):
        raise ValueError('Dedicated QEMU DMI boundary missing.')
    links=json.loads(run(['ip','-j','link','show']))
    boot=validate_initial_links(links)
    if run(['systemctl','is-active','systemd-networkd.service'])!='active':raise ValueError('No manager-start fallback.')
    if not shutil.which('ping'):raise ValueError('Guest ping prerequisite absent; no network installation fallback.')
    if pathlib.Path('/var/lib/worker3-networkd-lab/state.json').exists() or FIXTURE.exists():raise ValueError('Fresh guest journal/config required.')
    return {'vendor':vendor,'product':product,'bootIdentity':boot}


def definition(name,address,ipv6):
    # Netplan match.macaddress is a permanent hardware address, unsuitable for
    # veth's assigned virtual MAC. Baseline matches exact Name; the candidate
    # later enforces actual Name+MAC in its owned networkd runtime profile.
    return {'match':{'name':name},'dhcp4':False,'dhcp6':False,
        'accept-ra':False,'link-local':[], 'optional':True,'mtu':1500,
        'addresses':[address,ipv6], 'nameservers':{'addresses':['192.0.2.54']}}


def setup():
    guard=identity_guard()
    before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('/etc/netplan').glob('*.yaml')}
    for name,peer in (('w3test0','w3peer0'),('w3canary0','w3canarypeer0')):
        run(['ip','link','add',name,'type','veth','peer','name',peer])
        for link in (name,peer):run(['ip','link','set','dev',link,'address',MACS[link]])
    run(['ip','netns','add','w3phase2peer'])
    run(['ip','-n','w3phase2peer','link','set','lo','up'])
    for name,ipv4,ipv6 in (('w3peer0','192.0.2.1/24','2001:db8:3::1/64'),
                          ('w3canarypeer0','198.51.100.1/24','2001:db8:4::1/64')):
        run(['ip','link','set',name,'netns','w3phase2peer'])
        run(['ip','-n','w3phase2peer','address','add',ipv4,'dev',name])
        run(['ip','-n','w3phase2peer','-6','address','add',ipv6,'dev',name])
        run(['ip','-n','w3phase2peer','link','set','dev',name,'up'])
    specs={'w3test0':('192.0.2.10/24','2001:db8:3::10/64'),
           'w3canary0':('198.51.100.10/24','2001:db8:4::10/64')}
    network={'network':{'version':2,'renderer':'networkd','ethernets':{
        name:definition(name,*values) for name,values in specs.items()}}}
    FIXTURE.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    descriptor=os.open(FIXTURE,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(descriptor,'w') as stream:json.dump(network,stream)
    pathlib.Path('/etc/systemd/network').mkdir(mode=0o755,parents=True,exist_ok=True)
    private=pathlib.Path('/var/lib/worker3-networkd-lab');private.mkdir(mode=0o700,exist_ok=False)
    # Initial lab setup is deliberately global and precedes the measured baseline.
    run(['netplan','generate']);run(['networkctl','reload'])
    for name in specs:run(['ip','link','set','dev',name,'up']);run(['networkctl','reconfigure',name])
    deadline=time.monotonic()+30
    while True:
        try:
            for family,target in (('-4','192.0.2.1'),('-6','2001:db8:3::1')):
                run(['ping',family,'-I','w3test0','-c','1','-W','2',target],timeout=4)
            break
        except ValueError:
            if time.monotonic()>=deadline:raise
            time.sleep(.25)
    after={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('/etc/netplan').glob('*.yaml')}
    if before!=after:raise ValueError('Existing /etc Netplan bytes changed during fixture setup.')
    permit=pathlib.Path('/run/worker3-networkd-lab/permit')
    descriptor=os.open(permit,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(descriptor,'w') as stream:stream.write('worker3-networkd-isolated-v1\n')
    return {'guard':guard,'originalEtcNetplanSha256':before,'fixtureSha256':hashlib.sha256(FIXTURE.read_bytes()).hexdigest(),
        'setupOnly':True,'providerCasesPassed':False}


if __name__=='__main__':print(json.dumps(setup(),sort_keys=True))
