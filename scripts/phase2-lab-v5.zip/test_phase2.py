"""Pure harness guards only. No setup, provider execute, commands or manager reads."""
import copy
import importlib.util
import json
import pathlib
import sys
import unittest

DIR=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(DIR if (DIR/'networkd_provider.py').is_file() else DIR.parent))
def module(name,file):
    spec=importlib.util.spec_from_file_location(name,DIR/file)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result
fixture=module('phase2_fixture','guest-fixture.py')
cases=module('phase2_cases','guest-cases.py')


class Phase2GuardTests(unittest.TestCase):
    def test_native_eth0_extra_link_duplicate_name_or_wrong_binding_rejected(self):
        good=[{'ifname':'lo','ifindex':1},{'ifname':'w3boot0','ifindex':2,'address':'52:54:00:73:33:01'}]
        self.assertEqual(fixture.validate_initial_links(good)['ifname'],'w3boot0')
        bad=[]
        for values in (dict(ifname='eth0'),dict(address='52:54:00:73:33:02'),dict(ifindex=True),dict(ifindex=0)):
            links=copy.deepcopy(good);links[1].update(values);bad.append(links)
        bad.extend([good+[{'ifname':'eth0'}],good+[copy.deepcopy(good[1])],good[:1]])
        for index,links in enumerate(bad):
            with self.subTest(index=index):
                with self.assertRaises(ValueError):fixture.validate_initial_links(links)

    def test_normal_exit_or_sigkill_without_pending_apply_is_not_proof(self):
        message=json.dumps({'event':'actual-apply-before-sigkill','plan':{'phase':'pending'}})
        self.assertEqual(cases.child_message(-9,message)['plan']['phase'],'pending')
        for code,text in ((0,message),(124,message),(-15,message),(-9,'{}'),(-9,message.replace('pending','prepared'))):
            with self.subTest(code=code,text=text):
                with self.assertRaises(ValueError):cases.child_message(code,text)

    def test_running_helper_or_default_zero_exit_status_does_not_prove_completion(self):
        success='ActiveState=active\nSubState=exited\nResult=success\nExecMainStatus=0\n'
        self.assertTrue(cases.helper_completed(success))
        for text in (success.replace('exited','running'),success.replace('success','exit-code'),
                     success.replace('ExecMainStatus=0','ExecMainStatus=1'),success.replace('active','inactive'),'ExecMainStatus=0'):
            with self.subTest(text=text):self.assertFalse(cases.helper_completed(text))


if __name__=='__main__':unittest.main(verbosity=2)
