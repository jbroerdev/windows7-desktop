"""Bounded stdout evidence transport. No archive extraction or arbitrary paths."""
import base64
import hashlib
import json
import pathlib

PREFIX = b'WORKER3_EVIDENCE_V3 '
LIMITS = {'result.json': 6*1024*1024, 'serial.log': 12*1024*1024, 'qemu-argv.json': 16384}
MAX_PAYLOAD = 25*1024*1024
MAX_ATTACH = 34*1024*1024
CHUNK = 49152


def sha(data):return hashlib.sha256(data).hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:raise ValueError('Duplicate JSON key.')
        result[key] = value
    return result


def loads(data):return json.loads(data, object_pairs_hook=unique)


def frames(folder):
    files = {}
    for name, limit in LIMITS.items():
        file = pathlib.Path(folder)/name
        if file.is_symlink() or not file.is_file() or file.stat().st_size > limit:
            raise ValueError('Missing/unsafe/oversized evidence: '+name)
        data = file.read_bytes()
        if len(data) > limit:raise ValueError('Evidence changed beyond limit.')
        files[name] = {'bytes':len(data),'sha256':sha(data),'base64':base64.b64encode(data).decode('ascii')}
    payload = json.dumps({'version':3,'files':files},sort_keys=True,separators=(',',':')).encode('ascii')
    if len(payload) > MAX_PAYLOAD:raise ValueError('Evidence payload too large.')
    count = (len(payload)+CHUNK-1)//CHUNK
    yield PREFIX+json.dumps({'kind':'begin','bytes':len(payload),'sha256':sha(payload),'chunks':count}).encode()+b'\n'
    for index in range(count):
        yield PREFIX+json.dumps({'kind':'chunk','index':index,'base64':base64.b64encode(payload[index*CHUNK:(index+1)*CHUNK]).decode()}).encode()+b'\n'
    yield PREFIX+json.dumps({'kind':'end','sha256':sha(payload)}).encode()+b'\n'


def decode(log):
    if len(log) > MAX_ATTACH:raise ValueError('Attach log exceeds bounded transport.')
    lines = log.splitlines()
    if not lines or any(not line.startswith(PREFIX) for line in lines):
        raise ValueError('Unexpected or missing transport line.')
    records = [loads(line[len(PREFIX):]) for line in lines]
    begin, end = records[0], records[-1]
    if set(begin) != {'kind','bytes','sha256','chunks'} or begin['kind'] != 'begin':raise ValueError('Invalid begin.')
    if type(begin['bytes']) is not int or not 0 < begin['bytes'] <= MAX_PAYLOAD:raise ValueError('Invalid payload bound.')
    count = (begin['bytes']+CHUNK-1)//CHUNK
    if type(begin['chunks']) is not int or begin['chunks'] != count or len(records) != count+2:raise ValueError('Missing/duplicate frames.')
    if set(end) != {'kind','sha256'} or end != {'kind':'end','sha256':begin['sha256']}:raise ValueError('Invalid end.')
    parts = []
    for index, record in enumerate(records[1:-1]):
        if set(record) != {'kind','index','base64'} or record['kind'] != 'chunk' or type(record['index']) is not int or record['index'] != index:
            raise ValueError('Unexpected chunk/order.')
        data = base64.b64decode(record['base64'],validate=True)
        expected = CHUNK if index < count-1 else begin['bytes']-index*CHUNK
        if len(data) != expected:raise ValueError('Wrong chunk size.')
        parts.append(data)
    payload = b''.join(parts)
    if sha(payload) != begin['sha256']:raise ValueError('Payload digest mismatch.')
    bundle = loads(payload)
    if set(bundle) != {'version','files'} or bundle['version'] != 3 or set(bundle['files']) != set(LIMITS):raise ValueError('Evidence allowlist mismatch.')
    files = {}
    for name, limit in LIMITS.items():
        item = bundle['files'][name]
        if set(item) != {'bytes','sha256','base64'} or type(item['bytes']) is not int or not 0 <= item['bytes'] <= limit:raise ValueError('Invalid file bounds.')
        data = base64.b64decode(item['base64'],validate=True)
        if len(data) != item['bytes'] or sha(data) != item['sha256']:raise ValueError('File digest/size mismatch.')
        files[name] = data
    return files, {'version':3,'payloadSha256':sha(payload),'files':{n:{'bytes':len(d),'sha256':sha(d)} for n,d in files.items()}}


def extract(log_file, destination):
    log_file = pathlib.Path(log_file)
    if log_file.stat().st_size > MAX_ATTACH:raise ValueError('Oversized attach log.')
    files, manifest = decode(log_file.read_bytes())
    destination = pathlib.Path(destination)
    destination.mkdir(mode=0o700,exist_ok=False)
    for name, data in files.items():
        with (destination/name).open('xb') as target:target.write(data)
    return manifest
