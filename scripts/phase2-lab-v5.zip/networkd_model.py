"""Pure networkd candidate validation/DTO helpers; no manager or filesystem actions."""
import ipaddress
import re

MANAGER = 'systemd-networkd'
ROLLBACK = 'systemd-transient-timer'
PERSISTENCE = 'owned-networkd-override'
UUID = re.compile(r'^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$')
REVISION = re.compile(r'^[a-f0-9]{64}$')
OWNER = re.compile(r'^[a-zA-Z0-9_.@:-]{1,128}$')
IFACE = re.compile(r'^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,14}$')
MAC = re.compile(r'^[a-f0-9]{2}(:[a-f0-9]{2}){5}$')


class ProviderError(ValueError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def fields(data, allowed):
    if not isinstance(data, dict) or set(data) - set(allowed):
        raise ProviderError('invalid-request', 'Unknown or malformed request fields.')


def request(action, data):
    allowed = {'snapshot': [], 'prepare': ['adapterId','expectedRevision','settings'],
        'apply': ['token','confirmed'], 'confirm': ['token','confirmed'],
        'rollback': ['token'], 'status': ['token']}
    if action not in allowed:
        raise ProviderError('invalid-request', 'Unsupported provider action; diagnose remains with existing mapper.')
    fields(data, allowed[action]+['owner','admin'])
    if data.get('admin') is not True or not isinstance(data.get('owner'), str) or not OWNER.fullmatch(data['owner']):
        raise ProviderError('permission-denied', 'Server-bound personal administrator required.')
    if action in ('apply','confirm') and data.get('confirmed') is not True:
        raise ProviderError('permission-denied', 'Explicit confirmation required.')
    if action not in ('snapshot','prepare') and not UUID.fullmatch(str(data.get('token',''))):
        raise ProviderError('invalid-request', 'Invalid transaction token.')
    if action == 'prepare' and (not isinstance(data.get('adapterId'), str) or not REVISION.fullmatch(str(data.get('expectedRevision','')))):
        raise ProviderError('invalid-request', 'Adapter identity and configuration CAS revision required.')
    return data['owner']


def settings(value):
    fields(value, ['ipv4Method','address','prefixLength','gateway','dnsMode','dnsServers','mtu'])
    if value.get('ipv4Method') != 'manual' or value.get('dnsMode') != 'manual':
        raise ProviderError('unsupported-mode', 'This candidate writes static IPv4/manual DNS only; auto is not inferred or simulated.')
    prefix = value.get('prefixLength')
    if type(prefix) is not int or not 1 <= prefix <= 32 or not isinstance(value.get('address'),str):
        raise ProviderError('invalid-request', 'Valid IPv4 address/prefix required.')
    try:
        address = ipaddress.IPv4Address(value['address'])
        network = ipaddress.IPv4Network((address,prefix),strict=False)
        if address.is_unspecified or address.is_multicast or (prefix <= 30 and address in (network.network_address,network.broadcast_address)):
            raise ValueError('Not a host address.')
        gateway = value.get('gateway')
        if gateway is not None:
            if not isinstance(gateway,str):raise ValueError('Invalid gateway type.')
            gateway = ipaddress.IPv4Address(gateway)
            if gateway not in network or gateway == address or gateway.is_multicast or gateway.is_unspecified or (prefix <= 30 and gateway in (network.network_address,network.broadcast_address)):
                raise ValueError('Gateway must be another host in subnet.')
        servers = value.get('dnsServers')
        if not isinstance(servers,list) or not 1 <= len(servers) <= 3:raise ValueError('One to three manual DNS servers required.')
        dns = []
        for item in servers:
            if not isinstance(item,str):raise ValueError('Invalid DNS type.')
            ip = ipaddress.ip_address(item)
            if ip.is_unspecified or ip.is_multicast:raise ValueError('Invalid DNS server.')
            if str(ip) not in dns:dns.append(str(ip))
    except ValueError as error:
        raise ProviderError('invalid-request', str(error)) from error
    mtu = value.get('mtu')
    if mtu is not None and (type(mtu) is not int or not 1280 <= mtu <= 9000):
        raise ProviderError('invalid-request', 'MTU must be null or1280..9000.')
    return {'ipv4Method':'manual','address':str(address),'prefixLength':prefix,
        'gateway':str(gateway) if gateway else None,'dnsMode':'manual','dnsServers':dns,'mtu':mtu}


def unknown_configuration(reason):
    return {'ipv4Method':'unknown','dnsMode':'unknown','address':None,'prefixLength':None,
        'gateway':None,'dnsServers':None,'mtu':None,'source':'unknown','configurationRevision':None,
        'writeCapabilities':dict(manualIpv4=False,autoIpv4=False,manualDns=False,autoDns=False,mtu=False),
        'writeReasons':{key:reason for key in ('manualIpv4','autoIpv4','manualDns','autoDns','mtu')}}


def plan_view(token, plan, monotonic_now):
    active = plan['phase'] in ('applying','pending','committing')
    remaining = max(0,plan.get('deadlineMonotonic',monotonic_now)-monotonic_now) if active else None
    return {'token':token,'phase':plan['phase'],'adapterId':plan['adapterId'],'name':plan['name'],
        'settings':plan['settings'],'expiresAt':plan['expiresAt'],'confirmBy':plan.get('confirmBy'),
        'requiresConfirmation':plan['phase'] in ('prepared','pending'),
        'error':plan.get('error'),'errorCode':plan.get('errorCode'),
        'manager':MANAGER,'rollbackMethod':ROLLBACK,'persistenceMode':PERSISTENCE,
        'preview':plan['candidate']['preview'],
        'rollback':{'armed':bool(plan.get('timerArmed')),'remainingSeconds':remaining,
            'timerState':plan.get('timerState','not-armed'),'deadlineUnix':plan.get('confirmBy')}}
