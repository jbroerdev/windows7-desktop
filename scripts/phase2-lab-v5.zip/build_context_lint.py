"""Strict lint for this own flat COPY/allowlist context, not a general Docker parser.

No Docker, build, network, guest or manager execution. Unsupported syntax fails.
"""
import hashlib
import json
import pathlib
import re
import shlex
import sys

NAME=re.compile(r'^[A-Za-z0-9_.-]+$')


def copy_sources(dockerfile):
    lines=re.sub(r'\\\r?\n',' ',dockerfile).splitlines();sources=[]
    for raw in lines:
        line=raw.strip()
        if not line or line.startswith('#'):continue
        if re.match(r'(?i)^ADD(?:\s|$)',line):raise ValueError('ADD is outside this bounded build context.')
        match=re.match(r'(?i)^COPY\s+(.*)$',line)
        if not match:continue
        args=shlex.split(match[1])
        if len(args)<2 or args[-1]!='./' or any(not NAME.fullmatch(s) or s in ('.','..') for s in args[:-1]):
            raise ValueError('Only explicit flat COPY filenames to ./ are supported.')
        sources.extend(args[:-1])
    if not sources:raise ValueError('No explicit COPY inputs found.')
    return sorted(set(sources))


def allowed_files(ignore):
    lines=[line.strip() for line in ignore.splitlines() if line.strip() and not line.strip().startswith('#')]
    if not lines or lines[0]!='*':raise ValueError('Context must default-deny all files.')
    allowed=[]
    for line in lines[1:]:
        if not line.startswith('!') or not NAME.fullmatch(line[1:]) or line[1:] in ('.','..'):
            raise ValueError('Only exact flat filename exceptions allowed.')
        allowed.append(line[1:])
    if len(allowed)!=len(set(allowed)):raise ValueError('Duplicate allowlist input.')
    return set(allowed)


def validate(folder):
    folder=pathlib.Path(folder).resolve()
    for name in ('Dockerfile','.dockerignore'):
        file=folder/name
        if file.is_symlink() or not file.is_file() or file.stat().st_size>65536:raise ValueError('Invalid context control file.')
    if (folder/'Dockerfile.dockerignore').exists():raise ValueError('Per-Dockerfile ignore override is not allowed.')
    sources=copy_sources((folder/'Dockerfile').read_text())
    allowed=allowed_files((folder/'.dockerignore').read_text())
    expected=set(sources)|{'Dockerfile'}
    if allowed!=expected:
        raise ValueError('COPY inputs and context allowlist differ; excluded='+str(sorted(expected-allowed))+' extra='+str(sorted(allowed-expected)))
    hashes={}
    for name in sorted(expected):
        file=folder/name
        if file.is_symlink() or not file.is_file() or file.resolve().parent!=folder or file.stat().st_size>256*1024:
            raise ValueError('Missing/unsafe COPY input: '+name)
        hashes[name]=hashlib.sha256(file.read_bytes()).hexdigest()
    return {'flatCopyContextVerified':True,'copySources':sources,'allowedFiles':sorted(allowed),'inputSha256':hashes,
        'dockerExecuted':False}


if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Pass own extracted context folder.')
    print(json.dumps(validate(sys.argv[1]),sort_keys=True))
