"""Local context tests only. Never builds/starts Docker or managers."""
import pathlib
import tempfile
import unittest
import build_context_lint as lint

DIR=pathlib.Path(__file__).resolve().parent


class BuildContextTests(unittest.TestCase):
    def fixture(self,folder):
        (folder/'Dockerfile').write_text('FROM ubuntu:26.04\nCOPY data.py evidence_transport.py ./\n')
        (folder/'.dockerignore').write_text('*\n!Dockerfile\n!data.py\n!evidence_transport.py\n')
        (folder/'data.py').write_text('# own fixture\n');(folder/'evidence_transport.py').write_text('# own transport fixture\n')

    def test_every_copy_input_allowed_and_present(self):
        with tempfile.TemporaryDirectory(dir=DIR) as tmp:
            folder=pathlib.Path(tmp);self.fixture(folder)
            self.assertEqual(lint.validate(folder)['copySources'],['data.py','evidence_transport.py'])

    def test_original_v4_missing_transport_exception_rejected(self):
        with tempfile.TemporaryDirectory(dir=DIR) as tmp:
            folder=pathlib.Path(tmp);self.fixture(folder)
            (folder/'.dockerignore').write_text('*\n!Dockerfile\n!data.py\n')
            with self.assertRaisesRegex(ValueError,'excluded=.*evidence_transport'):lint.validate(folder)

    def test_extra_context_missing_input_or_override_rejected(self):
        for mode in ('extra','missing','override'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory(dir=DIR) as tmp:
                folder=pathlib.Path(tmp);self.fixture(folder)
                if mode=='extra':(folder/'.dockerignore').write_text((folder/'.dockerignore').read_text()+'!secrets.txt\n')
                if mode=='missing':(folder/'evidence_transport.py').unlink()
                if mode=='override':(folder/'Dockerfile.dockerignore').write_text('*\n')
                with self.assertRaises(ValueError):lint.validate(folder)

    def test_wildcards_traversal_multistage_add_or_nondefault_deny_fail_closed(self):
        for text in ('COPY *.py ./','COPY ../secret ./','COPY --from=other data.py ./','COPY ["data.py", "./"]','ADD data.py ./'):
            with self.subTest(text=text):
                with self.assertRaises(ValueError):lint.copy_sources(text)
        for text in ('!Dockerfile\n','*\n!*.py\n','*\n!../secret\n','*\n!data.py\n!data.py\n'):
            with self.subTest(text=text):
                with self.assertRaises(ValueError):lint.allowed_files(text)


if __name__=='__main__':unittest.main(verbosity=2)
