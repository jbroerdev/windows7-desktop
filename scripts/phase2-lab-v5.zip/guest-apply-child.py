"""Measured real-provider apply in a child that then dies by SIGKILL. Guest only."""
import json
import os
import signal
import sys
from networkd_provider import NetworkdProvider
from networkd_system import SystemBackend, STATE_FILE


def main():
    raw=sys.stdin.buffer.read(65537)
    if len(raw)>65536:raise ValueError('Bounded child request required.')
    request=json.loads(raw)
    if set(request)!={'token','owner'}:raise ValueError('Exact child request required.')
    backend=SystemBackend(STATE_FILE,isolated_lab=True)
    backend._lab_guard()
    provider=NetworkdProvider(STATE_FILE,backend,allow_changes=True)
    result=provider.execute('apply',{'owner':request['owner'],'admin':True,'token':request['token'],'confirmed':True})
    print(json.dumps({'event':'actual-apply-before-sigkill','pid':os.getpid(),'plan':result}),flush=True)
    os.kill(os.getpid(),signal.SIGKILL)


if __name__=='__main__':main()
