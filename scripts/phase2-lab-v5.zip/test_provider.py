"""Local logic preflight only. Explicit in-memory doubles are NOT manager evidence."""
import copy
import unittest
from contextlib import nullcontext
from networkd_model import ProviderError, settings, unknown_configuration
from networkd_provider import NetworkdProvider
from networkd_system import configuration, earlier_cannot_match, validate_staged_artifacts

ACTOR={'owner':'worker3-lab','admin':True}
SETTINGS={'ipv4Method':'manual','address':'192.0.2.20','prefixLength':24,
          'gateway':None,'dnsMode':'manual','dnsServers':['192.0.2.53'],'mtu':1400}


class MemoryStore:
    def __init__(self):self.state={'version':1,'plans':{}}
    def locked(self):return nullcontext()
    def load(self):return copy.deepcopy(self.state)
    def save(self,state):self.state=copy.deepcopy(state)


class LogicOnlyBackend:
    """No processes, files, systemd, Netplan or network operation exists here."""
    def __init__(self):
        self.now=100.;self.boot='boot-A';self.state='baseline';self.operations=[]
        self.cas='a'*64;self.fail_timer=False;self.fail_persist=False
    def monotonic(self):return self.now
    def wall_time(self):return self.now+1000
    def boot_id(self):return self.boot
    def capture(self,allow_changes=False):return {'revision':self.cas,'adapters':[
        {'id':'2:020000000001','name':'w3test0','capabilities':{'configureIpv4':True}}]}
    def public_snapshot(self,state):return state
    def build_candidate(self,*args):return {'preview':{'persistenceMode':'owned-networkd-override'}}
    def check_baseline(self,plan):
        if self.cas!=plan['baseline']['revision'] or self.state!='baseline':raise ProviderError('revision-conflict','changed')
    def arm_timer(self,plan,seconds):
        self.operations.append('arm')
        if self.fail_timer:raise ValueError('timer unavailable')
        return {'deadlineMonotonic':self.now+seconds}
    def install_runtime(self,plan):self.operations.append('runtime');self.state='pending'
    def check_pending(self,plan,allow_persistent=False):
        if self.state not in (('pending','committed') if allow_persistent else ('pending',)):
            raise ProviderError('ownership-conflict','unexpected target')
    def restore(self,plan):self.operations.append('restore');self.state='baseline'
    def persist(self,plan):
        self.operations.append('persist')
        if not plan.get('commitDecision'):raise AssertionError('No decision!')
        if self.fail_persist:self.fail_persist=False;raise OSError('injected write uncertainty')
        self.state='committed'
    def verify_committed(self,plan):
        if self.state!='committed':raise ValueError('not persisted')
    def disarm_timer(self,plan):self.operations.append('disarm')
    def timer_state(self,plan):return 'active'


class CandidateLogicTests(unittest.TestCase):
    def setUp(self):
        self.backend=LogicOnlyBackend();self.store=MemoryStore()
        self.service=NetworkdProvider('unused',self.backend,True,self.store)
    def prepare(self):
        return self.service.execute('prepare',{**ACTOR,'adapterId':'2:020000000001',
            'expectedRevision':self.backend.cas,'settings':SETTINGS})
    def apply(self):
        plan=self.prepare();return self.service.execute('apply',{**ACTOR,'token':plan['token'],'confirmed':True})
    def test_prepare_is_nonmutating_and_timer_precedes_runtime(self):
        plan=self.prepare();self.assertEqual(self.backend.operations,[])
        result=self.service.execute('apply',{**ACTOR,'token':plan['token'],'confirmed':True})
        self.assertEqual(result['phase'],'pending');self.assertEqual(self.backend.operations,['arm','runtime'])
        self.assertNotIn('persist',self.backend.operations)
    def test_explicit_confirm_is_only_persist_path(self):
        plan=self.apply()
        with self.assertRaises(ProviderError):self.service.execute('confirm',{**ACTOR,'token':plan['token'],'confirmed':1})
        result=self.service.execute('confirm',{**ACTOR,'token':plan['token'],'confirmed':True})
        self.assertEqual(result['phase'],'confirmed');self.assertEqual(self.backend.operations,['arm','runtime','persist','disarm'])
    def test_owner_and_unknown_fields_fail(self):
        plan=self.prepare()
        for data in ({**ACTOR,'owner':'other','token':plan['token']},
                     {**ACTOR,'token':plan['token'],'profileId':'client-spoof'}):
            with self.assertRaises(ProviderError):self.service.execute('status',data)
    def test_cas_and_duplicate_apply(self):
        plan=self.prepare();self.backend.cas='b'*64
        with self.assertRaises(ProviderError):self.service.execute('apply',{**ACTOR,'token':plan['token'],'confirmed':True})
        self.assertEqual(self.backend.operations,[])
        self.backend.cas='a'*64
        self.service.execute('apply',{**ACTOR,'token':plan['token'],'confirmed':True})
        with self.assertRaises(ProviderError):self.service.execute('apply',{**ACTOR,'token':plan['token'],'confirmed':True})
    def test_timer_failure_prevents_runtime(self):
        self.backend.fail_timer=True;plan=self.prepare()
        with self.assertRaises(ValueError):self.service.execute('apply',{**ACTOR,'token':plan['token'],'confirmed':True})
        self.assertNotIn('runtime',self.backend.operations);self.assertNotIn('persist',self.backend.operations)
    def test_fresh_recovery_object_only_after_deadline(self):
        plan=self.apply();fresh=NetworkdProvider('unused',self.backend,False,self.store)
        with self.assertRaises(ProviderError):fresh.recover(plan['token'])
        self.backend.now+=61
        self.assertEqual(fresh.recover(plan['token'])['phase'],'rolled-back')
        self.assertEqual(self.backend.state,'baseline');self.assertNotIn('persist',self.backend.operations)
    def test_durable_commit_uncertainty_rolls_forward_explicit_decision(self):
        plan=self.apply();self.backend.fail_persist=True
        with self.assertRaises(ProviderError):self.service.execute('confirm',{**ACTOR,'token':plan['token'],'confirmed':True})
        self.assertTrue(self.store.state['plans'][plan['token']]['commitDecision'])
        fresh=NetworkdProvider('unused',self.backend,False,self.store)
        self.assertEqual(fresh.execute('status',{**ACTOR,'token':plan['token']})['phase'],'confirmed')
        self.assertNotIn('restore',self.backend.operations)
    def test_boot_change_never_reports_restore_without_verification(self):
        plan=self.apply();self.backend.boot='boot-B'
        result=self.service.execute('status',{**ACTOR,'token':plan['token']})
        self.assertEqual(result['phase'],'rollback-failed');self.assertEqual(result['errorCode'],'boot-changed')
        self.assertNotIn('persist',self.backend.operations)
    def test_static_only_validation(self):
        self.assertEqual(settings(SETTINGS),SETTINGS)
        for change in ({'ipv4Method':'auto'},{'dnsMode':'auto'},{'prefixLength':True},
                       {'gateway':'203.0.113.1'},{'mtu':999999},{'dnsServers':[]}):
            with self.assertRaises(ProviderError):settings({**SETTINGS,**change})
    def test_unknown_and_method_readback_do_not_guess_from_kernel(self):
        self.assertEqual(unknown_configuration('unknown')['ipv4Method'],'unknown')
        known=configuration({'dhcp4':True,'accept-ra':False},'netplan-effective')
        self.assertEqual(known['ipv4Method'],'auto');self.assertFalse(known['writeCapabilities']['autoIpv4'])
        mixed=configuration({'dhcp4':True,'accept-ra':False,'nameservers':{'addresses':['192.0.2.53']}},'netplan-effective')
        self.assertEqual(mixed['dnsMode'],'unknown')
    def test_earlier_profile_exclusion_never_treats_negation_as_exact_name(self):
        self.assertTrue(earlier_cannot_match('[Match]\nName=other0\n','w3test0','02:00:00:00:00:01'))
        for name in ('!other0','w3*','','w3test0'):
            self.assertFalse(earlier_cannot_match('[Match]\nName='+name+'\n','w3test0','02:00:00:00:00:01'))

    def test_staged_link_mtu_difference_is_allowed_only_with_exact_network_mtu(self):
        target='10-netplan-w3test0.network';link='10-netplan-w3test0.link'
        before={target:'[Match]\nName=w3test0\n[Link]\nMTUBytes=1500\n',
            link:'[Match]\nOriginalName=w3test0\n[Link]\nWakeOnLan=off\nMTUBytes=1500\n'}
        after={key:value.replace('1500','1400') for key,value in before.items()}
        validate_staged_artifacts(before,after,target,1400)
        for change in (lambda d:d[link].replace('WakeOnLan=off','WakeOnLan=magic'),
                       lambda d:d[link].replace('OriginalName=w3test0','OriginalName=eth0'),
                       lambda d:d[link]+'MTUBytes=1300\n'):
            data=copy.deepcopy(after);data[link]=change(data)
            with self.assertRaises(ProviderError):validate_staged_artifacts(before,data,target,1400)
        data=copy.deepcopy(after);data[target]=data[target].replace('1400','1300')
        with self.assertRaises(ProviderError):validate_staged_artifacts(before,data,target,1400)
        data=copy.deepcopy(after);data['foreign.netdev']='[NetDev]\nName=foreign\n'
        with self.assertRaises(ProviderError):validate_staged_artifacts(before,data,target,1400)
        with self.assertRaises(ProviderError):validate_staged_artifacts({target:before[target]},after,target,1400)


if __name__=='__main__':unittest.main(verbosity=2)
