#!/bin/sh
set -eu
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ "$#" -ne 1 ]; then printf '%s\n' 'Usage: sh run-boot-lab.sh /absolute/path/to/boot-lab.zip' >&2; exit 2; fi
archive=$1
evidence=$(mktemp -d "$script_dir/evidence.XXXXXXXX")
container_id=
finish() {
    outcome=$1
    trap - EXIT HUP INT TERM
    set +e
    if [ -n "$container_id" ]; then
        docker inspect "$container_id" > "$evidence/container-final.json"
        inspect_result=$?
        python3 "$script_dir/lab-guard.py" decode "$evidence/attach.log" "$evidence/container" > "$evidence/transport.json" 2> "$evidence/transport-error.log"
        transport_result=$?
        docker rm --force "$container_id" > "$evidence/cleanup.log" 2>&1
        cleanup_result=$?
        if [ "$outcome" -eq 0 ] && { [ "$inspect_result" -ne 0 ] || [ "$transport_result" -ne 0 ] || [ "$cleanup_result" -ne 0 ]; }; then outcome=1; fi
    fi
    printf '%s\n' "$outcome" > "$evidence/runner-exit-code.txt"
    python3 "$script_dir/lab-guard.py" finish "$evidence" "$outcome" > "$evidence/receipt-summary.json"
    record_result=$?
    if [ "$record_result" -ne 0 ]; then
        outcome=1
        printf '%s\n' "$outcome" > "$evidence/runner-exit-code.txt"
        python3 "$script_dir/lab-guard.py" finish "$evidence" "$outcome" > "$evidence/receipt-summary.json"
    fi
    printf 'Evidence: %s\n' "$evidence"
    exit "$outcome"
}
trap 'finish "$?"' EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
python3 "$script_dir/lab-guard.py" package "$archive" "$script_dir" > "$evidence/package-identity.json"
tag="worker3-networkd-boot:run-$(date +%s)-$$"
timeout 900s docker build --tag "$tag" "$script_dir" > "$evidence/build.log" 2>&1
docker image inspect --format '{{.Id}}' "$tag" > "$evidence/image.id"
image=$(cat "$evidence/image.id")
container_id=$(docker create --network none --cap-drop ALL --security-opt no-new-privileges \
    --read-only --memory 2g --cpus 1 --pids-limit 128 \
    --tmpfs /run/lab:rw,nosuid,nodev,size=1g --tmpfs /tmp:rw,nosuid,nodev,size=64m \
    --env WORKER3_QEMU_LAB=phase2-static-v1 "$image")
case "$container_id" in ''|*[!a-f0-9]*) container_id=; exit 2;; esac
if [ "${#container_id}" -ne 64 ]; then container_id=; exit 2; fi
docker inspect "$container_id" > "$evidence/container-before.json"
python3 "$script_dir/lab-guard.py" container "$image" < "$evidence/container-before.json" > "$evidence/metadata-check.json"
attach_exit=0
timeout 1260s docker start --attach "$container_id" > "$evidence/attach.log" 2>&1 || attach_exit=$?
printf '%s\n' "$attach_exit" > "$evidence/attach-exit-code.txt"
if [ "$attach_exit" -ne 0 ]; then exit "$attach_exit"; fi
container_exit=$(docker inspect --format '{{.State.ExitCode}}' "$container_id")
case "$container_exit" in ''|*[!0-9]*) exit 2;; esac
exit "$container_exit"
