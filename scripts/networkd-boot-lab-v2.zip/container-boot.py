"""TCG-only bounded guest. This process has no capabilities or host network."""
import base64
import hashlib
import json
import os
import pathlib
import subprocess

ROOT = pathlib.Path('/opt/worker3-lab')
WORK = pathlib.Path('/run/lab')


def checked(argv, timeout=20):
    return subprocess.run(argv, stdin=subprocess.DEVNULL, capture_output=True,
                          check=True, timeout=timeout).stdout.decode().strip()


def sha(file):
    digest = hashlib.sha256()
    with open(file,'rb') as source:
        for block in iter(lambda:source.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()


def main():
    WORK.mkdir(mode=0o700,parents=True,exist_ok=True)
    result = {'phase': 'availability-only', 'passed': False, 'applyExecuted': False,
              'rollbackVerified': False, 'commitVerified': False, 'productionAccess': False}
    try:
        if os.environ.get('WORKER3_QEMU_LAB') != 'boot-availability-v1' or not pathlib.Path('/.dockerenv').exists():
            raise ValueError('Dedicated explicitly marked container required.')
        status = dict(line.split(':',1) for line in pathlib.Path('/proc/self/status').read_text().splitlines() if ':' in line)
        if any(int(status[key].strip(),16) for key in ('CapEff','CapPrm','CapBnd','CapInh','CapAmb')) or status['NoNewPrivs'].strip() != '1':
            raise ValueError('All capabilities must be dropped; no-new-privileges required.')
        if pathlib.Path('/dev/kvm').exists():raise ValueError('No KVM device allowed.')
        links = json.loads(checked(['ip','-j','link','show']))
        if [item['ifname'] for item in links] != ['lo']:
            raise ValueError('Outer container must have only loopback.')
        if json.loads(checked(['ip','-j','route','show'])) or json.loads(checked(['ip','-j','-6','route','show'])):
            raise ValueError('Outer container routes must be empty.')
        source = json.loads((ROOT/'image-sources.json').read_text())
        actual = sha(ROOT/'base.img')
        if actual != source['cloudImageSha256']:raise ValueError('Pinned official guest image SHA mismatch.')
        result['guestImageSha256'] = actual
        result['qemuVersion'] = checked(['qemu-system-x86_64','--version'])
        result['installedPackages'] = checked(['dpkg-query','-W','qemu-system-x86','qemu-utils','cloud-image-utils'])
        result['binarySha256'] = {name:sha('/usr/bin/'+name) for name in ('qemu-system-x86_64','qemu-img','cloud-localds')}
        files = [{'path':'/opt/worker3-lab/'+name,'permissions':'0600','encoding':'b64',
                  'content':base64.b64encode((ROOT/name).read_bytes()).decode()}
                 for name in ('guest-probe.py','read-only-manager-probe.py')]
        cloud = {'users':[], 'disable_root':True, 'ssh_pwauth':False, 'write_files':files,
                 'runcmd':[['python3','/opt/worker3-lab/guest-probe.py'],['systemctl','poweroff']]}
        (WORK/'user-data').write_text('#cloud-config\n'+json.dumps(cloud))
        (WORK/'meta-data').write_text('instance-id: worker3-networkd-boot-v1\nlocal-hostname: worker3-lab\n')
        network = {'version':2,'ethernets':{'w3boot':{'match':{'macaddress':'52:54:00:73:33:01'},
            'set-name':'w3boot0','dhcp4':True,'dhcp6':False,'optional':True}}}
        (WORK/'network-config').write_text(json.dumps(network))
        checked(['cloud-localds','--network-config='+str(WORK/'network-config'),str(WORK/'seed.img'),
                 str(WORK/'user-data'),str(WORK/'meta-data')])
        checked(['qemu-img','create','-f','qcow2','-F','qcow2','-b',str(ROOT/'base.img'),str(WORK/'guest.qcow2')])
        argv = ['qemu-system-x86_64','-accel','tcg,thread=single','-machine','q35','-cpu','max',
            '-smp','1','-m','1024','-nodefaults','-no-reboot','-display','none','-monitor','none','-serial','stdio',
            '-drive','file='+str(WORK/'guest.qcow2')+',if=virtio,format=qcow2',
            '-drive','file='+str(WORK/'seed.img')+',if=virtio,format=raw,readonly=on',
            '-netdev','user,id=isolated,restrict=on',
            '-device','virtio-net-pci,netdev=isolated,mac=52:54:00:73:33:01']
        (WORK/'qemu-argv.json').write_text(json.dumps(argv))
        with (WORK/'serial.log').open('wb') as serial:
            try:run=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=serial,stderr=subprocess.STDOUT,timeout=780,check=False);rc=run.returncode
            except subprocess.TimeoutExpired:rc=124
        result['qemuExitCode'] = rc
        records = [line.split(b'WORKER3_LAB_RESULT ',1)[1].strip() for line in (WORK/'serial.log').read_bytes().splitlines() if line.startswith(b'WORKER3_LAB_RESULT ')]
        if len(records) != 1:raise ValueError('Exactly one actual guest result required.')
        guest = json.loads(base64.b64decode(records[0],validate=True))
        result['guest'] = guest
        if rc != 0 or guest.get('passed') is not True or guest.get('phase') != 'availability-only':
            raise ValueError('Actual TCG guest availability failed.')
        result['passed'] = True
    except Exception as error:
        result['error'] = str(error)
    (WORK/'result.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'event':'worker3-qemu-boot-finished','passed':result['passed']}),flush=True)
    return 0 if result['passed'] else 1


if __name__ == '__main__':raise SystemExit(main())
