"""Artifact/metadata unit tests only. No Docker/QEMU/guest/manager execution."""
import copy
import importlib.util
import json
import pathlib
import tempfile
import unittest
import zipfile

DIR = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('lab_guard', DIR/'lab-guard.py')
guard = importlib.util.module_from_spec(spec); spec.loader.exec_module(guard)
guest_spec=importlib.util.spec_from_file_location('guest_probe',DIR/'guest-probe.py')
guest=importlib.util.module_from_spec(guest_spec);guest_spec.loader.exec_module(guest)


def valid():
    return {'Image':'sha256:expected','Config':{'Env':['WORKER3_QEMU_LAB=boot-availability-v1'],
        'Entrypoint':['python3','/opt/worker3-lab/container-boot.py']},'Mounts':[],
        'HostConfig':{'NetworkMode':'none','CapDrop':['ALL'],'CapAdd':[],
            'SecurityOpt':['no-new-privileges'],'ReadonlyRootfs':True,
            'Tmpfs':{'/run/lab':'rw,nosuid,nodev,size=1g','/tmp':'rw,nosuid,nodev,size=64m'},
            'Memory':2147483648,'NanoCpus':1000000000,'PidsLimit':128}}


def mapping_probe():
    return {'commands':{'links':{'exitCode':0,'truncated':False,'output':json.dumps([
        {'ifname':'w3boot0','address':'52:54:00:73:33:01','ifindex':2}])}},
        'linkAssignmentMetadata':{'links':[{'ifindexFile':'2','fields':{
            'ADMIN_STATE':'configured','NETWORK_FILE':'/run/systemd/network/10-netplan-w3boot.network'}}]},
        'fileInventory':{'files':[{'path':'/run/systemd/network/10-netplan-w3boot.network',
            'hashAvailable':True,'stable':True,'symlink':False,'uid':0,'mode':'0o640','sha256':'a'*64}]}}


class GuestMappingTests(unittest.TestCase):
    def test_exact_target_mapping(self):
        result=guest.verify_guest_mapping(mapping_probe())
        self.assertEqual(result['ifindex'],2)
        self.assertEqual(result['name'],'w3boot0')

    def test_other_link_file_cannot_prove_target(self):
        probe=mapping_probe();probe['linkAssignmentMetadata']['links'][0]['ifindexFile']='3'
        with self.assertRaises(ValueError):guest.verify_guest_mapping(probe)
        probe=mapping_probe();probe['linkAssignmentMetadata']['links'].append(copy.deepcopy(probe['linkAssignmentMetadata']['links'][0]))
        with self.assertRaises(ValueError):guest.verify_guest_mapping(probe)

    def test_bad_name_mac_index_state_file_fail_closed(self):
        changes=[lambda p:p['commands']['links'].update(output=json.dumps([{'ifname':'other','address':'52:54:00:73:33:01','ifindex':2}])),
            lambda p:p['commands']['links'].update(output=json.dumps([{'ifname':'w3boot0','address':'wrong','ifindex':2}])),
            lambda p:p['commands']['links'].update(output=json.dumps([{'ifname':'w3boot0','address':'52:54:00:73:33:01','ifindex':True}])),
            lambda p:p['linkAssignmentMetadata']['links'][0]['fields'].update(ADMIN_STATE='unmanaged'),
            lambda p:p['linkAssignmentMetadata']['links'][0]['fields'].update(NETWORK_FILE='/etc/foreign.network'),
            lambda p:p['fileInventory']['files'][0].update(stable=False),
            lambda p:p['fileInventory']['files'][0].update(symlink=True),
            lambda p:p['fileInventory']['files'][0].update(mode='0o666')]
        for change in changes:
            with self.subTest(change=changes.index(change)):
                probe=mapping_probe();change(probe)
                with self.assertRaises(ValueError):guest.verify_guest_mapping(probe)


class GuardTests(unittest.TestCase):
    def test_exact_metadata(self):
        self.assertTrue(guard.verify_container(valid(),'sha256:expected')['metadataVerified'])

    def test_unsafe_metadata_rejected(self):
        changes = [('NetworkMode','host'),('Privileged',True),('CapAdd',['NET_ADMIN']),
            ('CapDrop',[]),('Binds',['/:/host']),('Devices',[{'PathOnHost':'/dev/kvm'}]),
            ('DeviceRequests',[{'Count':-1}]),('VolumesFrom',['foreign']),('PidMode','host'),
            ('IpcMode','host'),('UTSMode','host'),('SecurityOpt',['seccomp=unconfined']),
            ('ReadonlyRootfs',False),('Tmpfs',{'/run/lab':'rw','/host':'rw'}),
            ('PortBindings',{'22/tcp':[{'HostPort':'2222'}]}),('PublishAllPorts',True),
            ('Memory',4294967296),('NanoCpus',2000000000),('PidsLimit',512)]
        for key,value in changes:
            with self.subTest(key=key):
                item=valid();item['HostConfig'][key]=value
                with self.assertRaises(ValueError):guard.verify_container(item,'sha256:expected')

    def test_wrong_image_entrypoint_or_mount(self):
        for mutation in (lambda d:d.update(Image='sha256:foreign'),
                lambda d:d['Config'].update(Entrypoint=['sh']),
                lambda d:d['Config'].update(Env=[]),
                lambda d:d.update(Mounts=[{'Type':'bind','Destination':'/run/lab'}])):
            item=valid();mutation(item)
            with self.assertRaises(ValueError):guard.verify_container(item,'sha256:expected')

    def test_package_tamper_is_detected(self):
        with tempfile.TemporaryDirectory(prefix='unit-package-',dir=DIR) as tmp:
            folder=pathlib.Path(tmp);self.assertTrue(folder.resolve().is_relative_to(DIR))
            (folder/'data.txt').write_bytes(b'fixed')
            (folder/'source-hashes.json').write_text(json.dumps({'data.txt':guard.digest(b'fixed')}))
            archive=folder/'test.zip'
            with zipfile.ZipFile(archive,'w') as package:
                for name in ('data.txt','source-hashes.json'):package.write(folder/name,name)
            self.assertEqual(guard.verify_package(archive,folder)['filesVerified'],1)
            (folder/'data.txt').write_bytes(b'changed')
            with self.assertRaises(ValueError):guard.verify_package(archive,folder)

    def test_outer_failure_never_inferred_as_pass(self):
        with tempfile.TemporaryDirectory(prefix='unit-receipt-',dir=DIR) as tmp:
            folder=pathlib.Path(tmp);self.assertTrue(folder.resolve().is_relative_to(DIR))
            (folder/'container').mkdir()
            (folder/'container/result.json').write_text('{"passed":true}')
            (folder/'container-final.json').write_text('[{"Id":"own","State":{"ExitCode":0}}]')
            (folder/'attach-exit-code.txt').write_text('0')
            self.assertFalse(guard.finish(folder,42)['availabilityPassed'])
            self.assertTrue(guard.finish(folder,0)['availabilityPassed'])
            (folder/'attach-exit-code.txt').write_text('124')
            self.assertFalse(guard.finish(folder,0)['availabilityPassed'])


if __name__ == '__main__':unittest.main(verbosity=2)
