"""Local artifact/metadata recorder; never starts Docker, QEMU or a manager."""
import hashlib
import json
import pathlib
import sys
import zipfile


def digest(data):return hashlib.sha256(data).hexdigest()


def verify_package(archive, context):
    context = pathlib.Path(context).resolve()
    manifest = json.loads((context/'source-hashes.json').read_text())
    with zipfile.ZipFile(archive) as package:
        names = package.namelist()
        if len(names) != len(set(names)) or set(names) != set(manifest) | {'source-hashes.json'}:
            raise ValueError('Package entry allowlist/duplicates differ.')
        for name, sha in manifest.items():
            file = context/name
            if not file.resolve().is_relative_to(context) or file.is_symlink():
                raise ValueError('Package path outside context/symlink.')
            data = file.read_bytes()
            if digest(data) != sha or package.read(name) != data:
                raise ValueError('Extracted/package bytes differ: '+name)
        if package.read('source-hashes.json') != (context/'source-hashes.json').read_bytes():
            raise ValueError('Manifest differs from ZIP.')
    return {'archiveSha256':digest(pathlib.Path(archive).read_bytes()),
            'sourceManifestSha256':digest((context/'source-hashes.json').read_bytes()),
            'filesVerified':len(manifest),'phase':'availability-only'}


def verify_container(item, image):
    host = item['HostConfig']
    normalize = lambda a:{s.upper().removeprefix('CAP_') for s in (a or [])}
    if item['Image'] != image or host.get('Privileged') or host.get('NetworkMode') != 'none':
        raise ValueError('Wrong image/isolation.')
    if normalize(host.get('CapDrop')) != {'ALL'} or normalize(host.get('CapAdd')):
        raise ValueError('Capabilities must all be dropped.')
    if host.get('Binds') or host.get('Devices') or host.get('DeviceRequests') or host.get('VolumesFrom'):
        raise ValueError('No host resources/devices allowed.')
    if any(host.get(key) == 'host' for key in ('PidMode','IpcMode','UTSMode')):
        raise ValueError('No shared host namespace.')
    security = host.get('SecurityOpt') or []
    if not any(s in ('no-new-privileges','no-new-privileges:true') for s in security):
        raise ValueError('no-new-privileges missing.')
    if any(s.startswith(('seccomp=','apparmor=')) for s in security):
        raise ValueError('Default seccomp/AppArmor must not be overridden.')
    if not host.get('ReadonlyRootfs') or set(host.get('Tmpfs') or {}) != {'/run/lab','/tmp'}:
        raise ValueError('Read-only root and exact private tmpfs set required.')
    if any(m.get('Type') != 'tmpfs' or m.get('Destination') not in ('/run/lab','/tmp') for m in item.get('Mounts',[])):
        raise ValueError('Unexpected mount.')
    if item['Config'].get('Volumes') or host.get('PortBindings') or host.get('PublishAllPorts'):
        raise ValueError('No volumes or published ports.')
    if host.get('Memory') != 2147483648 or host.get('NanoCpus') != 1000000000 or host.get('PidsLimit') != 128:
        raise ValueError('Exact CPU/RAM/PID bounds required.')
    if item['Config'].get('Entrypoint') != ['python3','/opt/worker3-lab/container-boot.py']:
        raise ValueError('Unexpected entrypoint.')
    if 'WORKER3_QEMU_LAB=boot-availability-v1' not in item['Config'].get('Env',[]):
        raise ValueError('Explicit boot-only lab marker missing.')
    return {'metadataVerified':True,'imageId':image,'network':'none','caps':[],
            'kvmAllowed':False,'bindsAllowed':False,'portsAllowed':False}


def finish(folder, runner_exit):
    folder = pathlib.Path(folder)
    result = {'phase':'availability-only','outerRunnerExitCode':int(runner_exit),
              'applyExecuted':False,'rollbackVerified':False,'commitVerified':False}
    for file, key in [('package-identity.json','package'),('container-final.json','container'),
                      ('container/result.json','bootResult')]:
        path = folder/file
        if path.is_file():
            try:result[key] = json.loads(path.read_text())
            except (ValueError,OSError):result[key] = {'invalidOrUnavailable':True}
    if (folder/'image.id').is_file():result['imageId'] = (folder/'image.id').read_text().strip()
    if (folder/'attach-exit-code.txt').is_file():result['attachExitCode'] = int((folder/'attach-exit-code.txt').read_text())
    metadata = result.get('container')
    if isinstance(metadata,list) and len(metadata) == 1:
        result['containerId'] = metadata[0].get('Id')
        result['containerExitCode'] = metadata[0].get('State',{}).get('ExitCode')
    result['availabilityPassed'] = bool(result['outerRunnerExitCode'] == 0 and result.get('containerExitCode') == 0
        and result.get('attachExitCode') == 0 and result.get('bootResult',{}).get('passed') is True)
    result['evidenceSha256'] = {str(p.relative_to(folder)):digest(p.read_bytes()) for p in folder.rglob('*')
        if p.is_file() and p.name != 'receipt.json' and not p.is_symlink()}
    (folder/'receipt.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    return result


def main():
    action, *args = sys.argv[1:]
    if action == 'package':result=verify_package(*args)
    elif action == 'container':
        data=json.load(sys.stdin)
        if not isinstance(data,list) or len(data) != 1:raise ValueError('Expected own single container.')
        result=verify_container(data[0],args[0])
    elif action == 'finish':
        result=finish(*args)
        if result['outerRunnerExitCode'] == 0 and not result['availabilityPassed']:
            raise ValueError('A zero runner status requires consistent actual guest/container evidence.')
    else:raise ValueError('Unknown action.')
    print(json.dumps(result,sort_keys=True))


if __name__ == '__main__':main()
