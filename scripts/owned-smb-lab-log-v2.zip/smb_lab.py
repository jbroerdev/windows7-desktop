"""Real SMB loopback laboratory; requires explicit Root review of SETUID/SETGID.

Never run on a native host. It provisions synthetic users only in the image and
all credentials/config/data in container tmpfs. Nothing is published to the host.
"""
import base64
import hashlib
import json
import os
import pathlib
import re
import signal
import subprocess
import sys
import time
from smb_owned_share import OwnedSmbShare,SharingError,render

RUN=pathlib.Path('/run/worker2-smb')
PUBLIC=pathlib.Path('/data/public')
CANARY=pathlib.Path('/data/canary')
PASSWORD='Worker2_Synthetic_Lab_Only_2026'
SEED=b'worker2 synthetic public data\n'
CANARY_DATA=b'worker2 unrelated canary data\n'
BASE={'publicFolderSharing':'off','passwordProtectedSharing':'on','smbEncryption':'required'}
CAPS=(1<<6)|(1<<7)  # SETGID and SETUID, no network administration/raw capability


def emit(event,**values):print(json.dumps({'event':event,**values}),flush=True)


def command(argv,input=None,timeout=8):
    result=subprocess.run(argv,input=input,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
        timeout=timeout,check=False,env={**os.environ,'LC_ALL':'C','NO_COLOR':'1'})
    output=result.stdout.decode('utf-8',errors='replace')[-12000:]
    if result.returncode:raise RuntimeError(str(argv[0])+' failed: '+output)
    return output


def guard():
    if sys.platform!='linux' or os.geteuid()!=0 or not pathlib.Path('/.dockerenv').is_file():
        raise ValueError('Dedicated disposable Linux Docker laboratory required.')
    if os.environ.get('WORKER2_SMB_LAB')!='loopback-auth-two-identities-v1':
        raise ValueError('Reviewed SMB laboratory marker missing.')
    fields=dict(line.split(':',1) for line in pathlib.Path('/proc/self/status').read_text().splitlines() if ':' in line)
    if any(int(fields[key].strip(),16)!=CAPS for key in ('CapEff','CapPrm','CapBnd')):
        raise ValueError('Exactly SETUID/SETGID are required; no extra capabilities allowed.')
    if any(int(fields.get(key,'0').strip(),16)!=0 for key in ('CapAmb','CapInh')) or fields['NoNewPrivs'].strip()!='1':
        raise ValueError('Unexpected privilege inheritance or missing no-new-privileges.')
    links=json.loads(command(['ip','-j','link','show']))
    if [link['ifname'] for link in links]!=['lo']:raise ValueError('Only loopback may exist.')
    routes=json.loads(command(['ip','-j','route','show']))+json.loads(command(['ip','-j','-6','route','show']))
    if any(route.get('dst')=='default' for route in routes):raise ValueError('No default route permitted.')


def client(command_text,*,share='windows7-public',auth='good',encrypt=True,smb2=False):
    argv=['smbclient','//127.0.0.1/'+share,'-I','127.0.0.1','-p','1445','-t','3','-m','SMB2' if smb2 else 'SMB3',
          '--option=client min protocol=SMB2_02','--client-protection='+('encrypt' if encrypt else 'off')]
    if auth in ('good','wrong'):argv+=['-A',str(RUN/(auth+'.credentials'))]
    else:argv+=['-U','worker2_unknown_guest','-N']
    argv+=['-c',command_text]
    result=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=8)
    output=result.stdout.decode('utf-8',errors='replace')
    success=result.returncode==0 and not re.search(r'NT_STATUS_[A-Z_]+',output)
    return success,output[-3000:]


def require_client(success,expected,label,detail):
    if success is not expected:raise RuntimeError(label+' result differs from expected: '+detail)


def verify_access(values):
    # Fresh connections test the effective daemon, independently of testparm.
    out=RUN/'canary.download';out.unlink(missing_ok=True)
    success,detail=client('get canary.txt '+str(out),share='canary')
    require_client(success,True,'authenticated canary',detail)
    if out.read_bytes()!=CANARY_DATA:raise RuntimeError('Canary contents changed.')
    success,detail=client('ls',share='canary',encrypt=False,smb2=True)
    require_client(success,True,'SMB2 canary control connection',detail)
    success,detail=client('ls',share='canary',auth='guest',encrypt=False)
    require_client(success,False,'canary anonymous denial',detail)
    if values['publicFolderSharing']=='off':
        success,detail=client('ls');require_client(success,False,'disabled public share',detail)
        if (PUBLIC/'seed.txt').read_bytes()!=SEED:raise RuntimeError('Local public file disappeared when disabled.')
        return True
    out=RUN/'public.download';out.unlink(missing_ok=True)
    success,detail=client('put '+str(RUN/'upload.txt')+' roundtrip.txt')
    require_client(success,True,'authenticated public put',detail)
    if (PUBLIC/'roundtrip.txt').stat().st_uid!=25001:raise RuntimeError('Authenticated write did not use the real Unix test identity.')
    success,detail=client('get roundtrip.txt '+str(out)+'; del roundtrip.txt')
    require_client(success,True,'authenticated public roundtrip',detail)
    if out.read_bytes()!=(RUN/'upload.txt').read_bytes():raise RuntimeError('Authenticated roundtrip bytes differ.')
    success,detail=client('ls',auth='wrong',encrypt=values['smbEncryption']=='required')
    require_client(success,False,'wrong existing-user password',detail)
    success,detail=client('ls',auth='guest',encrypt=False)
    require_client(success,values['passwordProtectedSharing']=='off','guest access policy',detail)
    if values['passwordProtectedSharing']=='off':
        out=RUN/'guest.download';out.unlink(missing_ok=True)
        success,detail=client('put '+str(RUN/'upload.txt')+' guest-roundtrip.txt',auth='guest',encrypt=False)
        require_client(success,True,'guest public put',detail)
        import pwd
        if (PUBLIC/'guest-roundtrip.txt').stat().st_uid!=pwd.getpwnam('nobody').pw_uid:raise RuntimeError('Guest write did not use the real guest Unix identity.')
        success,detail=client('get guest-roundtrip.txt '+str(out)+'; del guest-roundtrip.txt',auth='guest',encrypt=False)
        require_client(success,True,'guest public roundtrip',detail)
        if out.read_bytes()!=(RUN/'upload.txt').read_bytes():raise RuntimeError('Guest roundtrip bytes differ.')
    else:
        success,detail=client('ls',encrypt=False,smb2=True)
        if values['smbEncryption']=='required':require_client(success,False,'SMB2 required-encryption denial',detail)
    out=RUN/'symlink.download';out.unlink(missing_ok=True)
    success,detail=client('get escape.txt '+str(out))
    if success or (out.exists() and out.stat().st_size):raise RuntimeError('Share symlink escaped the public directory.')
    return True


def main():
    process=None;stream=None;interactive=None;passed=False;step='guard'
    try:
        guard()
        for filename,key in [('smb_owned_share.py','WORKER2_CONTROLLER_SHA'),('smb_lab.py','WORKER2_HARNESS_SHA')]:
            actual=hashlib.sha256(pathlib.Path(__file__).with_name(filename).read_bytes()).hexdigest()
            if actual!=os.environ.get(key):raise ValueError('Runtime source hash does not match reviewed input: '+filename)
            emit('smb-lab-source',file=filename,sha256=actual)
        emit('smb-lab-guard-pass',capabilities=['SETUID','SETGID'],interfaces=['lo'],productionAccess=False)
        emit('smb-lab-version',samba=command(['smbd','--version']).strip())
        step='synthetic-configuration'
        RUN.mkdir(mode=0o700)
        for name in ('private','state','cache','lock','pid','ncalrpc'):(RUN/name).mkdir(mode=0o700)
        PUBLIC.mkdir(mode=0o777);PUBLIC.chmod(0o777);CANARY.mkdir(mode=0o755)
        (PUBLIC/'seed.txt').write_bytes(SEED);(PUBLIC/'seed.txt').chmod(0o666)
        (CANARY/'canary.txt').write_bytes(CANARY_DATA)
        (PUBLIC/'escape.txt').symlink_to(CANARY/'canary.txt')
        (RUN/'upload.txt').write_bytes(b'worker2 synthetic SMB roundtrip\n')
        for name,password in [('good',PASSWORD),('wrong','Definitely_Wrong_Synthetic_Password')]:
            file=RUN/(name+'.credentials');file.write_text('username = w2smbtest\npassword = '+password+'\n');file.chmod(0o600)
        include=RUN/'owned.conf';include.write_bytes(render(BASE,PUBLIC));include.chmod(0o600)
        master=RUN/'master.conf'
        text='[global]\nserver role = standalone server\nsecurity = user\nmap to guest = Bad User\nguest account = nobody\n'
        text+='server min protocol = SMB2_02\nserver max protocol = SMB3\nsmb ports = 1445\ninterfaces = 127.0.0.1\nbind interfaces only = yes\ndisable netbios = yes\n'
        text+='load printers = no\ndisable spoolss = yes\nprinting = bsd\nprintcap name = /dev/null\n'
        for key,sub in [('private dir','private'),('state directory','state'),('cache directory','cache'),('lock directory','lock'),('pid directory','pid'),('ncalrpc dir','ncalrpc')]:text+=key+' = '+str(RUN/sub)+'\n'
        text+='passdb backend = tdbsam:'+str(RUN/'private/passdb.tdb')+'\nlog file = '+str(RUN/'smbd.log')+'\n'
        text+='include = '+str(include)+'\n[canary]\npath = '+str(CANARY)+'\nguest ok = no\nread only = yes\nserver smb encrypt = desired\nfollow symlinks = no\nwide links = no\n'
        master.write_text(text);master.chmod(0o600)
        master_hash=hashlib.sha256(master.read_bytes()).hexdigest()
        command(['testparm','--suppress-prompt','--parameter-name=server role',str(master)])
        command(['smbpasswd','-s','-a','-c',str(master),'w2smbtest'],input=(PASSWORD+'\n'+PASSWORD+'\n').encode())
        step='owned-daemon-start'
        stream=(RUN/'daemon.stdout').open('wb')
        process=subprocess.Popen(['smbd','--foreground','--no-process-group','--configfile='+str(master),'--debuglevel=1'],
            stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        deadline=time.monotonic()+10
        while time.monotonic()<deadline:
            if process.poll() is not None:raise RuntimeError('Owned smbd exited before ready.')
            ready,_=client('ls',share='canary')
            if ready:break
            time.sleep(.2)
        else:raise TimeoutError('Owned smbd did not accept authenticated connections.')
        def reload_service():
            if process.poll() is not None:raise RuntimeError('Owned smbd is not running.')
            command(['smbcontrol','-s',str(master),'smbd','reload-config'])
            # Close only this controller's share trees, not the canary or whole service.
            command(['smbcontrol','-s',str(master),'smbd','close-share','windows7-public'])
            time.sleep(.25)
        service=OwnedSmbShare(include_file=include,master_config=master,directory=PUBLIC,
            journal_file=RUN/'transaction.json',reload_service=reload_service,verify_access=verify_access,
            adopted=True,auth_ready=True,guest_policy_ready=True)
        verify_access(BASE);emit('smb-baseline-pass',publicDisabled=True,canaryAuthenticated=True)
        step='authenticated-share-enable'
        result=service.save({'publicFolderSharing':'readwrite'},service.snapshot(lambda:True)['revision'],lambda:True)
        emit('smb-authenticated-share-pass',values=result['values'],actualClientRoundtrip=True,anonymousDenied=True,wrongPasswordDenied=True)
        step='guest-explicit-policy'
        result=service.save({'passwordProtectedSharing':'off','smbEncryption':'desired'},result['revision'],lambda:True)
        emit('smb-guest-share-pass',values=result['values'],actualGuestRoundtrip=True,canaryStillProtected=True)
        step='existing-guest-session-revocation'
        before=RUN/'session.before';after=RUN/'session.after';log=RUN/'interactive.log'
        with log.open('wb') as output:
            interactive=subprocess.Popen(['smbclient','//127.0.0.1/windows7-public','-I','127.0.0.1','-p','1445',
                '-m','SMB3','--client-protection=off','-U','worker2_unknown_guest','-N'],stdin=subprocess.PIPE,stdout=output,stderr=subprocess.STDOUT)
            interactive.stdin.write(('get seed.txt '+str(before)+'\n').encode());interactive.stdin.flush()
            deadline=time.monotonic()+5
            while time.monotonic()<deadline and (not before.exists() or before.read_bytes()!=SEED):time.sleep(.1)
            if not before.exists() or before.read_bytes()!=SEED:raise RuntimeError('Persistent guest session was not established.')
            result=service.save({'passwordProtectedSharing':'on','smbEncryption':'required'},result['revision'],lambda:True)
            interactive.stdin.write(('get seed.txt '+str(after)+'\nquit\n').encode());interactive.stdin.flush();interactive.stdin.close();interactive.wait(timeout=8)
            if after.exists() and after.stat().st_size:raise RuntimeError('Existing guest session retained access after protection enabled.')
            interactive=None
        emit('smb-existing-guest-revoked-pass',ownedShareOnly=True)
        step='independent-verifier-failure-rollback'
        previous=include.read_bytes();old_verify=service.verify
        service.verify=lambda values:False if values['publicFolderSharing']=='off' else old_verify(values)
        try:service.save({'publicFolderSharing':'off'},result['revision'],lambda:True)
        except SharingError as error:
            if error.mutation!='rolled-back':raise
        else:raise RuntimeError('Injected verifier failure was falsely accepted.')
        service.verify=old_verify
        if include.read_bytes()!=previous:raise RuntimeError('Failed change did not restore configuration bytes.')
        verify_access(result['values']);emit('smb-rollback-pass',configurationBytesRestored=True,actualAccessRestored=True)
        step='actual-process-abort-and-recovery'
        previous=include.read_bytes()
        crashed=subprocess.run([sys.executable,__file__,'--crash-after-apply'],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
        if crashed.returncode!=73 or include.read_bytes()==previous:raise RuntimeError('Crash fixture did not stop after actual configuration replacement.')
        restarted=OwnedSmbShare(include_file=include,master_config=master,directory=PUBLIC,
            journal_file=RUN/'transaction.json',reload_service=reload_service,verify_access=verify_access,
            adopted=True,auth_ready=True,guest_policy_ready=True)
        if not restarted.snapshot(lambda:True)['recoveryRequired']:raise RuntimeError('Interrupted state was not detected.')
        restarted.recover(lambda:True)
        if include.read_bytes()!=previous:raise RuntimeError('Restart recovery did not restore exact configuration bytes.')
        if list(RUN.glob('owned.conf.*.candidate')) or list(RUN.glob('owned.conf.*.validation')):raise RuntimeError('Owned staging artifacts leaked after recovery.')
        verify_access(result['values']);service=restarted
        emit('smb-process-recovery-pass',abortedChildExit=73,configurationRestored=True,actualAccessRestored=True,ownedStagingCleaned=True)
        step='network-disable-local-preservation'
        service.save({'publicFolderSharing':'off'},service.snapshot(lambda:True)['revision'],lambda:True)
        if master.read_bytes()!=text.encode() or hashlib.sha256(master.read_bytes()).hexdigest()!=master_hash:raise RuntimeError('Unrelated master/canary configuration was changed.')
        emit('smb-lab-pass',actualController=True,authenticatedReadWrite=True,guestReadWrite=True,
            protectedAnonymousDenied=True,existingGuestRevoked=True,symlinkEscapeDenied=True,
            requiredEncryptionVerifiedBySmb2Denial=True,canaryConfigAndAccessPreserved=True,
            rollbackVerified=True,actualProcessRecoveryVerified=True,localFilePreserved=True,nativeHostInstalled=False,productionAccess=False)
        passed=True
    except Exception as error:emit('smb-lab-fail',step=step,error=str(error),broadenPrivileges=False)
    finally:
        if interactive is not None and interactive.poll() is None:interactive.kill();interactive.wait()
        if process is not None:
            try:os.killpg(process.pid,signal.SIGTERM);process.wait(timeout=3)
            except ProcessLookupError:pass
            except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
        if stream:stream.close()
        for name in ('daemon.stdout','smbd.log'):
            file=RUN/name
            try:
                # Export before the container exits: tmpfs cannot be copied later.
                # Refuse a success claim if a full bounded log cannot be exported.
                present=file.is_file()
                if present and file.stat().st_size>16*1024*1024:raise ValueError('Full daemon log exceeds the export bound.')
                data=file.read_bytes() if present else b''
                emit('smb-log-file',file=name,present=present,bytes=len(data),
                    sha256=hashlib.sha256(data).hexdigest(),base64=base64.b64encode(data).decode('ascii'))
            except Exception as error:
                passed=False;emit('smb-log-export-fail',file=name,error=str(error))
        emit('smb-lab-finished',passed=passed)
    return 0 if passed else 1


def crash_after_apply():
    guard()
    def abort():os._exit(73)
    service=OwnedSmbShare(include_file=RUN/'owned.conf',master_config=RUN/'master.conf',directory=PUBLIC,
        journal_file=RUN/'transaction.json',reload_service=abort,verify_access=verify_access,
        adopted=True,auth_ready=True,guest_policy_ready=True)
    service.save({'publicFolderSharing':'off'},service.snapshot(lambda:True)['revision'],lambda:True)
    raise RuntimeError('Crash point was not reached.')


if __name__=='__main__':
    if sys.argv[1:]==['--crash-after-apply']:crash_after_apply()
    elif sys.argv[1:]:raise SystemExit('Unknown laboratory action.')
    else:raise SystemExit(main())
