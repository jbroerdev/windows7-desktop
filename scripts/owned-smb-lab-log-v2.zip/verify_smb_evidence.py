"""Extract full synthetic daemon logs and bind successful markers to real exits.

Runs outside the container. No Docker calls, host service access or remote I/O.
The runner's EXIT trap records its final exit after this verifier returns.
"""
import base64
import hashlib
import json
import pathlib
import re
import sys
from verify_smb_container import verify as verify_container

LOGS={'daemon.stdout','smbd.log'}
REQUIRED_EVENTS=['smb-lab-guard-pass','smb-baseline-pass','smb-authenticated-share-pass',
    'smb-guest-share-pass','smb-existing-guest-revoked-pass','smb-rollback-pass',
    'smb-process-recovery-pass','smb-lab-pass','smb-lab-finished']


def digest(data):return hashlib.sha256(data).hexdigest()


def verify(root):
    root=pathlib.Path(root);events=[];logs={}
    with (root/'smb-lab.log').open(encoding='utf-8') as stream:
        for line in stream:
            # Docker can add non-JSON attach diagnostics. Required markers still
            # have to be unambiguous JSON from the reviewed harness.
            try:event=json.loads(line)
            except json.JSONDecodeError:continue
            if not isinstance(event,dict):continue
            events.append(event)
            if event.get('event')!='smb-log-file':continue
            name=event.get('file')
            if name not in LOGS or name in logs:raise ValueError('Invalid or duplicate daemon log identity.')
            if type(event.get('bytes')) is not int or not 0<=event['bytes']<=16*1024*1024:
                raise ValueError('Invalid daemon log size.')
            if not isinstance(event.get('base64'),str) or len(event['base64'])>24*1024*1024:
                raise ValueError('Invalid daemon log payload.')
            data=base64.b64decode(event['base64'],validate=True)
            if len(data)!=event['bytes'] or digest(data)!=event.get('sha256'):
                raise ValueError('Daemon log size/hash mismatch.')
            if type(event.get('present')) is not bool or (not event['present'] and data):
                raise ValueError('Invalid daemon log presence.')
            target=root/('full-'+name)
            with target.open('xb') as output:output.write(data)
            logs[name]={'present':event['present'],'bytes':len(data),'sha256':digest(data),'artifact':target.name}
    # Preserve extracted complete logs even if the case/exit checks fail below.
    (root/'daemon-log-manifest.json').write_text(json.dumps(logs,indent=2)+'\n',encoding='utf-8')
    if set(logs)!=LOGS:raise ValueError('Full daemon log records missing.')
    if any(e.get('event') in ('smb-lab-fail','smb-log-export-fail') for e in events):raise ValueError('Failure event present.')
    positions=[]
    for name in REQUIRED_EVENTS:
        found=[i for i,e in enumerate(events) if e.get('event')==name]
        if len(found)!=1:raise ValueError('Missing or duplicate case marker: '+name)
        positions.append(found[0])
    if positions!=sorted(positions):raise ValueError('Case markers out of order.')
    if events[positions[-1]].get('passed') is not True:raise ValueError('Final pass is not true.')
    if positions[-1]!=len(events)-1:raise ValueError('Unexpected events after final marker.')
    if (root/'attach-exit.txt').read_text(encoding='ascii').strip()!='0' or (root/'container-exit.txt').read_text(encoding='ascii').strip()!='0':
        raise ValueError('Nonzero attach or container exit.')
    image=(root/'image-id.txt').read_text(encoding='ascii').strip()
    cid=(root/'container-id.txt').read_text(encoding='ascii').strip()
    if not re.fullmatch(r'sha256:[a-f0-9]{64}',image) or not re.fullmatch(r'[a-f0-9]{64}',cid):raise ValueError('Invalid image/container identity.')
    for name in ('container-before.json','container-after.json'):
        items=json.loads((root/name).read_text(encoding='utf-8'))
        if not isinstance(items,list) or len(items)!=1:raise ValueError('Expected exact container inspect.')
        item=items[0];verify_container(item)
        if item.get('Id')!=cid or item.get('Image')!=image:raise ValueError('Image/container binding mismatch.')
        if name=='container-after.json':
            state=item.get('State',{})
            if state.get('Status')!='exited' or state.get('Running') is not False or state.get('ExitCode')!=0 or state.get('OOMKilled') or state.get('Error'):
                raise ValueError('Container state is not successful terminal completion.')
    expected={}
    for line in (root/'actual-source-hashes.txt').read_text(encoding='utf-8').splitlines():
        sha,filename=line.split(None,1);filename=pathlib.PurePosixPath(filename.strip()).name
        if filename in ('smb_owned_share.py','smb_lab.py'):
            if filename in expected or not re.fullmatch(r'[a-f0-9]{64}',sha):raise ValueError('Invalid actual source manifest.')
            expected[filename]=sha
    for name in ('smb_owned_share.py','smb_lab.py'):
        found=[e for e in events if e.get('event')=='smb-lab-source' and e.get('file')==name]
        if len(found)!=1 or expected.get(name) is None or found[0].get('sha256')!=expected[name]:raise ValueError('Runtime/reviewed source mismatch.')
    return {'passed':True,'caseMarkers':REQUIRED_EVENTS,'sourceHashes':expected,'image':image,'container':cid,'fullDaemonLogs':logs,
        'attachExit':0,'containerExit':0,'outerRunnerExit':'recorded by runner EXIT trap after this verifier'}


if __name__=='__main__':
    root=pathlib.Path(sys.argv[1]);result={'passed':False}
    try:result=verify(root)
    except Exception as error:result['error']=str(error)
    (root/'evidence-verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result))
    raise SystemExit(0 if result['passed'] else 1)
