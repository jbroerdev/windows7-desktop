# Owned SMB controller and real-client laboratory — Root review required

## Log-v2 freeze

This is a separate successor to controller/owned-smb-lab.zip SHA256 05259c7e7ea1e823cf4eb13ab631c788b871d04e6c896eb4cc8d7bbe86f19ab8. That previous freeze is preserved. The controller itself is byte-identical (SHA256 473ff381e2e5b6cad797b5ebef21317d9d3df43310dbdde2a649906a3803c7e7). Root has reviewed the SETUID+SETGID-only synthetic isolated CI boundary; this successor does not add privileges, host resources, users or ports. No native installation is authorized.

Daemon logs are now exported in full, with base64/byte count/SHA256, to attached stdout BEFORE the container exits. No docker cp from expired tmpfs is used. The outside verifier reconstructs full-daemon.stdout and full-smbd.log in evidence/, preserving bytes beyond the previous 16000-byte tail. Each log is bounded at 16 MiB; an exceeded bound or export failure forces failed completion. Missing files are represented explicitly as present=false rather than inventing a log. Full logs remain saved even when a later case/exit check fails.

verify_smb_evidence.py requires all ordered case markers, unique final passed=true, no failure markers, matching runtime/source hashes, matching actual image/container IDs and safe before/after metadata, completed non-OOM container state and zero attach/container exits. The runner creates from the recorded immutable image ID and exits nonzero if this verifier fails. The EXIT trap separately records the real outer runner exit; Root must still verify runner-exit.txt=0 in the CI artifact. Eight local evidence tests cover reconstruction beyond the former tail limit, failure-log preservation, nonzero exit, missing crash marker, false final marker, source mismatch, nonterminal state, corruption and path escape.

Native evidence is now available: `../native-host-inventory-20261105.json` reports active systemd-networkd/Netplan, no installed standard Samba/CUPS/wsdd/media services, no selected sharing listeners and no managed sharing artifacts. There is therefore no existing Samba service to assume adopted. This package does not install or start anything on that native host.

## Implemented controller

`OwnedSmbShare` manages exactly the marked `windows7-public` include and its private transaction journal. It never rewrites the master/global configuration or accepts a path, service, command or arbitrary share name in a change request. Constructor paths and service/verifier callbacks are trusted Root setup, not client JSON.

Supported changes are publicFolderSharing=off/readwrite, passwordProtectedSharing=on/off and the separately named real smbEncryption=required/desired. Guest plus required encryption is rejected rather than silently weakening policy. It enforces no-follow/no-wide-links. Unknown managed config content, revision conflicts and external master edits are refused. A whole candidate configuration is validated with real testparm before replacement. Revision includes master and owned include bytes. The final write rechecks revision and authorization; atomic replacement, reload, effective readback and an independent real access verifier are required. Verification/reload failures restore the prior owned bytes, reload and verify the prior behavior. Interrupted transactions block further writes until hash/ownership-checked recovery. Thread locking plus Linux advisory file locking serialize writers/recovery.

Atomic file and journal replacements fsync both the file and parent directory on Linux. Crash recovery removes only recorded staging basenames with their expected content hashes. Changed staging files, symlinks and escaped paths require review instead of deletion. Fourteen local controller tests cover CAS, authorization revocation, rollback/recovery and these staging ownership boundaries; five additional tests cover the proposed container boundary. These injected tests do not replace the Linux/Samba run.

The snapshot identifies its source as validated effective configuration; it is not by itself proof of a live reachable daemon. Root's outer host provider must include actual service/adoption state when mapping writable capabilities. No default callback pretends to be a real access verifier. `adopted`, `auth_ready` and explicit guest-policy readiness must be provisioned from reviewed host setup. No web password hash is reused as an SMB credential.

The reload adapter must reload the owned instance and close **only the owned share's existing trees** when changing access policy. Reload alone does not revoke established sessions. The lab uses the private config/state messaging context for `smbcontrol reload-config` and `close-share windows7-public`; it does not restart or close the canary share. Samba documents this reload limitation in its [smbd manual](https://www.samba.org/samba/docs/current/man-html/smbd.8.html).

## New laboratory boundary to review before execution

This is a **different capability set** from the NetworkManager test. It proposes exactly SETUID and SETGID, with **no NET_ADMIN/NET_RAW**, so real smbd sessions can access the synthetic filesystem as separate authenticated and guest Unix identities. This proposal is not authorization to broaden any existing runner. Root must review this exact package before choosing to execute it. Do not add further capabilities if it fails.

Other boundaries remain: `--network none`, only loopback, port 1445 only inside that namespace, no published ports, no bind mounts/host D-Bus/host udev/devices/host PID-IPC-UTS namespace, cap-drop ALL, no-new-privileges, default seccomp/AppArmor, read-only root and three private tmpfs mounts. Runtime is limited to 180 seconds, 256 MiB, one CPU and 64 PIDs. The image contains one synthetic Unix account; temporary Samba passdb/credentials/config/files exist only in container tmpfs. Native host users, files and services are untouched. The synthetic password is test data, never a production default.

Root may run after review, from an extracted new temporary directory:

```sh
sh run-smb-lab.sh
```

The runner builds only a separate Docker image, verifies actual container metadata before start and checks exact capabilities/network inside the container before provisioning its fixture. Only the newly created validated container ID is cleaned up. `evidence/` retains actual source hashes, image ID, container ID/metadata, attached log, attach exit, container exit and actual outer runner exit. The package is **not yet Docker-built or real-Samba-tested in this Windows worker**.

## Actual synthetic cases implemented in the runner

- Baseline public share unavailable; local seed file retained; unrelated canary available only with authentication.
- Enable owned share: actual authenticated put/get byte roundtrip and Unix file owner 25001; wrong password and anonymous access denied.
- Required public encryption: SMB3 encrypted connection succeeds; unencrypted SMB2 public connection fails while a same-account SMB2 canary control succeeds.
- Explicit guest/optional-encryption change: actual guest put/get and real guest Unix file ownership; canary remains protected.
- Keep a guest client session open, re-enable authentication/encryption, then require the old session to receive no seed bytes after the owned tree closure.
- Real SMB symlink-escape attempts may not download any bytes from the outside canary file.
- Inject access-verifier failure after a real config change; require exact owned bytes and actual prior client behavior to be restored.
- Abort a separate controller process with os._exit(73) after the active file replacement and applied journal, bypassing Python finally. A new controller must detect recovery-required, restore exact prior bytes, reload and verify actual client behavior, and clean only its recorded unchanged staging files. The owned daemon stays alive throughout this controller-process failure.
- Disable network availability again; local data and master/canary config bytes remain unchanged.

Success requires smb-lab-pass, smb-lab-finished passed=true and all separately recorded outer/container exits 0. Failure retains the exact stage and daemon/client diagnostics; there is no synthetic success or unreviewed privilege fallback. This verifies only the lab's Samba version and synthetic service, not a production installation or complete Windows sharing equivalence. [smbclient](https://www.samba.org/samba/docs/current/man-html/smbclient.1.html) and [smbpasswd](https://www.samba.org/samba/docs/current/man-html/smbpasswd.8.html) are the primary command references.

## Native installation proposal, not executed

After the lab passes, prepare a separate Root-reviewed fresh standalone package: owned config/state paths and service unit, startup suppression while installing Samba, fixed dedicated public directory and explicit ACLs/identities, initially unavailable share, actual credentials provisioning, and an explicit trusted-network binding/firewall policy. Do not auto-bind guest access to every interface, import unknown global Samba policy or use the lab's account/password on the host. Existing package daemons must not auto-start before that configuration is reviewed. Default native bind remains restricted until the intended network scope is established.

Root must integrate the typed personal-admin service, revision/session validation, actual readback, UI shared-scope mapping and installer/rollback. Woker's native Windows encryption/HomeGroup controls remain semantically distinct; the real modern SMB encryption controller needs its honest host-specific options. This is controller implementation work with open integration/real-test gates, not a completed sharing feature.
