import concurrent.futures
import pathlib
import tempfile
import unittest
import json
import hashlib
from smb_owned_share import OwnedSmbShare,SharingError,render,parse_owned

BASE={'publicFolderSharing':'off','passwordProtectedSharing':'on','smbEncryption':'required'}


class ConfigTools:
    def __init__(self,directory):self.directory=directory;self.on_validate=None;self.break_effective=False
    def validate(self,path):
        if self.on_validate:self.on_validate()
    def effective(self,path):
        text=pathlib.Path(path).read_text(encoding='utf-8')
        include=next(line.partition('=')[2].strip() for line in text.splitlines() if line.startswith('include = '))
        values=parse_owned(pathlib.Path(include).read_bytes(),self.directory)
        return {**values,'path':str(self.directory),'readOnly':'yes' if self.break_effective else 'no',
                'followSymlinks':'no','wideLinks':'no'}


class OwnedShareTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        root=pathlib.Path(self.temp.name);self.config=root/'private';self.config.mkdir(mode=0o700)
        self.directory=root/'public';self.directory.mkdir()
        self.include=self.config/'owned.conf';self.include.write_bytes(render(BASE,self.directory))
        self.master=self.config/'master.conf'
        self.master.write_text('[global]\nserver role = standalone server\ninclude = '+str(self.include)+'\n[canary]\npath = /fixed/canary\n',encoding='utf-8',newline='\n')
        self.journal=self.config/'journal.json';self.tools=ConfigTools(self.directory)
        self.reloads=0;self.access=[]
        def reload_service():self.reloads+=1
        def verify(values):self.access.append(dict(values));return True
        self.reload=reload_service;self.verify=verify
        self.service=self.create()
    def create(self,**overrides):
        options=dict(include_file=self.include,master_config=self.master,directory=self.directory,
            journal_file=self.journal,tools=self.tools,reload_service=self.reload,
            verify_access=self.verify,adopted=True,auth_ready=True,guest_policy_ready=True)
        return OwnedSmbShare(**{**options,**overrides})
    def snapshot(self):return self.service.snapshot(lambda:True)
    def save(self,changes,**options):return self.service.save(changes,options.get('revision',self.snapshot()['revision']),options.get('authorized',lambda:True))

    def test_real_controller_revision_and_master_preservation(self):
        before=self.master.read_bytes();revision=self.snapshot()['revision']
        result=self.save({'publicFolderSharing':'readwrite'})
        self.assertEqual(result['values']['publicFolderSharing'],'readwrite')
        self.assertNotEqual(result['revision'],revision);self.assertEqual(self.master.read_bytes(),before)
        self.assertEqual(self.reloads,1);self.assertEqual(self.access[-1],result['values'])
        with self.assertRaises(SharingError) as error:self.save({'publicFolderSharing':'off'},revision=revision)
        self.assertEqual(error.exception.status,409);self.assertEqual(self.reloads,1)

    def test_unknown_path_and_unauthorized_request_do_not_write(self):
        before=self.include.read_bytes();revision=self.snapshot()['revision']
        with self.assertRaises(SharingError):self.save({'path':'/etc'},revision=revision)
        with self.assertRaises(SharingError) as error:self.save({'publicFolderSharing':'readwrite'},revision=revision,authorized=lambda:False)
        self.assertEqual(error.exception.status,403);self.assertEqual(self.include.read_bytes(),before)
        self.assertEqual(self.reloads,0)

    def test_guest_requires_explicit_encryption_change_and_reviewed_policy(self):
        with self.assertRaises(SharingError):self.save({'passwordProtectedSharing':'off'})
        service=self.create(guest_policy_ready=False)
        with self.assertRaises(SharingError):service.save({'passwordProtectedSharing':'off','smbEncryption':'desired'},self.snapshot()['revision'],lambda:True)
        result=self.save({'passwordProtectedSharing':'off','smbEncryption':'desired'})
        self.assertEqual(result['values']['passwordProtectedSharing'],'off')

    def test_no_adoption_or_missing_real_verifier_cannot_write(self):
        for kwargs in [dict(adopted=False),dict(auth_ready=False),dict(verify_access=None),dict(reload_service=None)]:
            service=self.create(**kwargs)
            self.assertFalse(service.snapshot(lambda:True)['writable'])
            with self.assertRaises(SharingError) as error:service.save({'publicFolderSharing':'readwrite'},self.snapshot()['revision'],lambda:True)
            self.assertEqual(error.exception.status,501)

    def test_revocation_during_validation_leaves_active_config_unchanged(self):
        revision=self.snapshot()['revision'];before=self.include.read_bytes();allowed=[True]
        self.tools.on_validate=lambda:allowed.__setitem__(0,False)
        with self.assertRaises(SharingError) as error:self.service.save({'publicFolderSharing':'readwrite'},revision,lambda:allowed[0])
        self.assertEqual(error.exception.status,403);self.assertEqual(self.include.read_bytes(),before)
        self.assertEqual(self.reloads,0);self.assertEqual(sorted(p.name for p in self.config.iterdir() if not p.name.endswith('.lock')),['master.conf','owned.conf'])

    def test_external_master_change_during_validation_is_not_overwritten(self):
        revision=self.snapshot()['revision'];before=self.include.read_bytes()
        self.tools.on_validate=lambda:self.master.write_bytes(self.master.read_bytes()+b'# external edit\n')
        with self.assertRaises(SharingError) as error:self.save({'publicFolderSharing':'readwrite'},revision=revision)
        self.assertEqual(error.exception.status,409);self.assertEqual(self.include.read_bytes(),before)
        self.assertIn(b'# external edit',self.master.read_bytes());self.assertEqual(self.reloads,0)

    def test_client_failure_rolls_back_active_config_and_checks_previous_access(self):
        previous=self.include.read_bytes()
        self.service.verify=lambda values:values['publicFolderSharing']=='off'
        with self.assertRaises(SharingError) as error:self.save({'publicFolderSharing':'readwrite'})
        self.assertEqual(error.exception.mutation,'rolled-back');self.assertEqual(self.include.read_bytes(),previous)
        self.assertEqual(self.reloads,2);self.assertEqual(json.loads(self.journal.read_text())['phase'],'rolled-back')

    def test_reload_failure_and_recovery_are_journaled(self):
        self.service.reload=lambda:(_ for _ in ()).throw(RuntimeError('service unavailable'))
        with self.assertRaises(SharingError) as error:self.save({'publicFolderSharing':'readwrite'})
        self.assertEqual(error.exception.mutation,'recovery-required')
        restored=self.create().recover(lambda:True)
        self.assertEqual(restored['values'],BASE);self.assertFalse(restored['recoveryRequired'])

    def test_process_stop_requires_recovery_before_further_save(self):
        def stopped():raise SystemExit('process stopped after active replacement')
        self.service.reload=stopped
        with self.assertRaises(SystemExit):self.save({'publicFolderSharing':'readwrite'})
        restarted=self.create();snapshot=restarted.snapshot(lambda:True)
        self.assertTrue(snapshot['recoveryRequired']);self.assertFalse(snapshot['writable'])
        with self.assertRaises(SharingError):restarted.save({'publicFolderSharing':'off'},snapshot['revision'],lambda:True)
        restored=restarted.recover(lambda:True);self.assertEqual(restored['values'],BASE)

    def test_external_unknown_owned_content_refuses_replacement(self):
        self.include.write_bytes(self.include.read_bytes()+b'admin users = someone\n')
        with self.assertRaises(SharingError):self.snapshot()
        self.assertIn(b'admin users',self.include.read_bytes())

    def interrupted_with_staging(self):
        def stopped():raise SystemExit('interrupted')
        self.service.reload=stopped
        with self.assertRaises(SystemExit):self.save({'publicFolderSharing':'readwrite'})
        record=json.loads(self.journal.read_text(encoding='utf-8'))
        # SystemExit executes finally; reconstruct the exact recorded file that
        # a real os._exit/SIGKILL leaves behind before finally can run.
        staging=self.config/record['validationName'];data=b'owned staged validation fixture\n'
        staging.write_bytes(data);record['validationHash']=hashlib.sha256(data).hexdigest()
        self.journal.write_text(json.dumps(record),encoding='utf-8')
        return staging,record

    def test_recovery_removes_only_recorded_unchanged_staging(self):
        staging,record=self.interrupted_with_staging()
        unrelated=self.config/'unrelated.validation';unrelated.write_bytes(b'other owner')
        restored=self.create().recover(lambda:True)
        self.assertFalse(staging.exists());self.assertEqual(unrelated.read_bytes(),b'other owner')
        self.assertEqual(restored['values'],BASE);self.assertFalse(restored['recoveryRequired'])

    def test_recovery_preserves_changed_staging_and_requires_review(self):
        staging,record=self.interrupted_with_staging();staging.write_bytes(b'external changes')
        with self.assertRaises(SharingError) as error:self.create().recover(lambda:True)
        self.assertEqual(error.exception.mutation,'recovery-required')
        self.assertEqual(staging.read_bytes(),b'external changes')
        self.assertTrue(self.create().snapshot(lambda:True)['recoveryRequired'])

    def test_recovery_rejects_staging_path_escape(self):
        staging,record=self.interrupted_with_staging()
        unrelated=self.config.parent/'outside.validation';unrelated.write_bytes(b'preserve')
        record['validationName']='../outside.validation'
        self.journal.write_text(json.dumps(record),encoding='utf-8')
        with self.assertRaises(SharingError):self.create().recover(lambda:True)
        self.assertEqual(unrelated.read_bytes(),b'preserve');self.assertTrue(staging.exists())

    def test_concurrent_compare_and_swap_has_one_winner(self):
        revision=self.snapshot()['revision']
        def attempt():
            try:self.save({'publicFolderSharing':'readwrite'},revision=revision);return 'success'
            except SharingError as error:return error.status
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(lambda ignored:attempt(),range(2)))
        self.assertCountEqual(results,['success',409]);self.assertEqual(self.reloads,1)


if __name__=='__main__':unittest.main(verbosity=2)
