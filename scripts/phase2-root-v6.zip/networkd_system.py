"""Concrete Linux/networkd backend, WRITE PATH HARD-GATED TO THE ISOLATED QEMU LAB.

Native reads are possible; no production write authorization is implemented here.
Global reload scope is an explicit open real gate, not hidden behind reconfigure.
"""
import copy
import hashlib
import ipaddress
import json
import os
import pathlib
import re
import shutil
import stat
import subprocess
import tempfile
import time
from networkd_model import ProviderError, IFACE, MAC, UUID, MANAGER, ROLLBACK, PERSISTENCE, unknown_configuration

RUN = pathlib.Path('/run/systemd/network')
ETC = pathlib.Path('/etc/systemd/network')
ROOTS = [pathlib.Path(p) for p in ('/etc/netplan','/run/netplan','/lib/netplan',
    '/etc/systemd/network','/run/systemd/network','/usr/local/lib/systemd/network','/usr/lib/systemd/network')]
BASENAME = re.compile(r'^00-00-windows7-web-[0-9]+-[a-f0-9]{12}-[0-9]{16}\.network$')
STATE_FILE = pathlib.Path('/var/lib/worker3-networkd-lab/state.json')


def digest(value):return hashlib.sha256(value if isinstance(value,bytes) else json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def run(argv, timeout=12):
    result=subprocess.run(argv,stdin=subprocess.DEVNULL,capture_output=True,timeout=timeout,check=False,
        env={**os.environ,'LC_ALL':'C','SYSTEMD_COLORS':'0','SYSTEMD_PAGER':''})
    if result.returncode:
        raise ProviderError('manager-command-failed',argv[0]+' '+argv[1]+' failed with exit '+str(result.returncode))
    if len(result.stdout)>2*1024*1024:raise ValueError('Manager output limit.')
    return result.stdout.decode('utf8').strip()


def graph():
    result={};total=0
    for root in ROOTS:
        if not root.exists():result[str(root)]={'type':'absent-directory'};continue
        patterns=('*.yaml','*.yml') if root.name=='netplan' else (
            '*.network','*.link','*.netdev','*.network.d/*.conf','*.link.d/*.conf','*.netdev.d/*.conf')
        for file in sorted({f for pattern in patterns for f in root.glob(pattern)}):
            info=file.lstat()
            if file.is_symlink() or not stat.S_ISREG(info.st_mode) or not file.resolve().is_relative_to(root.resolve()):
                raise ProviderError('unsupported-config','Relevant symlink/nonregular config cannot be safely managed.')
            if info.st_size>1024*1024 or len(result)>512 or total+info.st_size>32*1024*1024:
                raise ValueError('Config graph size limit.')
            data=file.read_bytes();after=file.stat();total+=len(data)
            if (info.st_ino,info.st_size,info.st_mtime_ns)!=(after.st_ino,after.st_size,after.st_mtime_ns):
                raise ProviderError('revision-conflict','Config changed while reading.')
            result[str(file)]={'sha256':digest(data),'mode':stat.S_IMODE(info.st_mode),'uid':info.st_uid,'gid':info.st_gid}
    # Global networkd/resolved configuration can change routing/DNS policy too.
    for base in ('/etc/systemd','/run/systemd','/usr/local/lib/systemd','/usr/lib/systemd'):
        for service in ('networkd','resolved'):
            parent=pathlib.Path(base);main=parent/(service+'.conf')
            for file in ([main] if main.exists() else [])+list((parent/(service+'.conf.d')).glob('*.conf')):
                info=file.lstat()
                if file.is_symlink() or not stat.S_ISREG(info.st_mode) or info.st_size>1024*1024:
                    raise ProviderError('unsupported-config','Global manager config is not a bounded regular file.')
                data=file.read_bytes();after=file.stat()
                if (info.st_ino,info.st_size,info.st_mtime_ns)!=(after.st_ino,after.st_size,after.st_mtime_ns):
                    raise ProviderError('revision-conflict','Global manager config changed while reading.')
                total+=len(data)
                if len(result)>512 or total>32*1024*1024:raise ValueError('Config graph size limit.')
                result[str(file)]={'sha256':digest(data),'mode':stat.S_IMODE(info.st_mode),'uid':info.st_uid,'gid':info.st_gid}
    return result


def selected_file(index):
    file=pathlib.Path('/run/systemd/netif/links')/str(index)
    if file.is_symlink() or file.stat().st_size>65536:return None
    for line in file.read_text().splitlines():
        if line.startswith('NETWORK_FILE='):
            value=line.partition('=')[2].strip().strip('"')
            return value if value.startswith(('/run/systemd/network/','/etc/systemd/network/','/usr/lib/systemd/network/')) else None
    return None


def earlier_cannot_match(text, name, mac):
    """Prove exclusion only for simple positive exact [Match] names/MACs."""
    if text.count('[Match]')!=1:return False
    match=re.search(r'(?ms)^\[Match\]\s*\n(.*?)(?=^\[|\Z)',text)
    if not match:return False
    names=[];macs=[]
    for line in match[1].splitlines():
        line=line.strip()
        if line.startswith('Name='):
            values=line.partition('=')[2].split()
            if not values or not all(IFACE.fullmatch(v) for v in values):return False
            names.extend(values)
        if line.startswith('MACAddress='):
            values=line.partition('=')[2].lower().split()
            if not values or not all(MAC.fullmatch(v) for v in values):return False
            macs.extend(values)
    return bool(names and name not in names) or bool(macs and mac not in macs)


def without_link_mtu(text):
    """Inspect generated staging text only; reject ambiguous MTU placement."""
    section=None;sections=0;mtu=None;remaining=[]
    for line in text.splitlines(keepends=True):
        plain=line.strip()
        if plain.startswith('[') and plain.endswith(']'):
            section=plain
            if section=='[Link]':sections+=1
        if plain.startswith('MTUBytes='):
            value=plain.partition('=')[2]
            if section!='[Link]' or mtu is not None or not re.fullmatch('[0-9]+',value):
                raise ProviderError('unsupported-config','Ambiguous generated Link MTU.')
            mtu=int(value);continue
        remaining.append(line)
    if sections!=1:raise ProviderError('unsupported-config','Exactly one generated Link section required for MTU comparison.')
    return ''.join(remaining),mtu


def validate_staged_artifacts(before,after,target,wanted_mtu):
    if target not in after:raise ProviderError('unsupported-config','Missing generated target network profile.')
    target_link=target.removesuffix('.network')+'.link'
    for name in set(before)|set(after):
        if name==target or before.get(name)==after.get(name):continue
        # Netplan1.2 emits MTUBytes in both .link and .network. The .link is
        # staging-only and is NEVER installed. Permit only an existing exact
        # target .link whose sole changed assignment is its explicit Link MTU.
        if name!=target_link or name not in before or name not in after or wanted_mtu is None:
            raise ProviderError('unsupported-config','Staging changed unrelated target artifacts.')
        old,old_mtu=without_link_mtu(before[name]);new,new_mtu=without_link_mtu(after[name])
        _,network_mtu=without_link_mtu(after[target])
        if old!=new or old_mtu is None or new_mtu!=wanted_mtu or network_mtu!=wanted_mtu:
            raise ProviderError('unsupported-config','Staged ancillary difference exceeds exact owned-network MTU support.')


def netdef_for(network, name, mac):
    matches=[]
    for ident,definition in network.get('ethernets',{}).items():
        if not isinstance(definition,dict):continue
        match=definition.get('match')
        if match is None:ok=ident==name
        elif not isinstance(match,dict) or set(match)-{'name','macaddress'}:continue
        else:ok=bool(match) and match.get('name',name)==name and match.get('macaddress',mac).lower()==mac
        if ok and definition.get('set-name',name)==name:matches.append((ident,definition))
    if len(matches)!=1:raise ProviderError('unsupported-config','Netplan target mapping is ambiguous or absent.')
    ident,definition=matches[0]
    if not IFACE.fullmatch(ident) or definition.get('renderer',network.get('renderer','networkd'))!='networkd':
        raise ProviderError('unsupported-config','Unsupported Netplan identity/renderer.')
    if any(key in definition for key in ('auth','openvswitch','sriov','virtual-function-count')):
        raise ProviderError('unsupported-config','Complex/secrets-bearing Ethernet definition is outside this candidate.')
    return ident,copy.deepcopy(definition)


def configuration(definition, source, revision=None):
    result=unknown_configuration('Writes require explicit isolated-lab/target/timer eligibility.')
    for key in ('autoIpv4','autoDns'):result['writeReasons'][key]='Automatic writes are not implemented in this static-only candidate.'
    addresses=[]
    for item in definition.get('addresses',[]):
        text=item if isinstance(item,str) else next(iter(item)) if isinstance(item,dict) and len(item)==1 else None
        if text is None:raise ProviderError('unsupported-config','Unsupported address options.')
        value=ipaddress.ip_interface(text)
        if value.version==4:addresses.append(value)
    method='auto' if definition.get('dhcp4') is True else 'manual'
    static=definition.get('nameservers',{}).get('addresses',[])
    auto=(definition.get('dhcp4') is True and definition.get('dhcp4-overrides',{}).get('use-dns',True)) or (
        definition.get('dhcp6') is True and definition.get('dhcp6-overrides',{}).get('use-dns',True)) or (
        definition.get('accept-ra') is not False and definition.get('ra-overrides',{}).get('use-dns',True))
    dns='unknown' if auto and static else 'auto' if auto else 'manual'
    gateways=[r['via'] for r in definition.get('routes',[]) if r.get('to') in ('default','0.0.0.0/0') and 'via' in r and ipaddress.ip_address(r['via']).version==4]
    if definition.get('gateway4'):gateways.append(definition['gateway4'])
    result.update(ipv4Method=method,dnsMode=dns,address=str(addresses[0].ip) if len(addresses)==1 else None,
        prefixLength=addresses[0].network.prefixlen if len(addresses)==1 else None,
        gateway=gateways[0] if len(set(gateways))==1 else None,dnsServers=static if dns!='unknown' else None,
        mtu=definition.get('mtu'),source=source,configurationRevision=revision)
    return result


class SystemBackend:
    def __init__(self,state_file,isolated_lab=False):
        self.state_file=pathlib.Path(state_file);self.isolated_lab=isolated_lab is True
        if self.state_file != STATE_FILE:raise ValueError('Concrete lab backend uses one fixed private journal path.')
        self.helper=pathlib.Path(__file__).with_name('networkd_cli.py').resolve()

    def monotonic(self):return time.monotonic()
    def wall_time(self):return time.time()
    def boot_id(self):return pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()

    def _lab_guard(self):
        marker=pathlib.Path('/run/worker3-networkd-lab/permit')
        if not self.isolated_lab or os.geteuid()!=0 or pathlib.Path('/proc/1/comm').read_text().strip()!='systemd':
            raise ProviderError('lab-only','Writes are restricted to the explicitly selected isolated PID1 guest.')
        if marker.is_symlink() or marker.stat().st_uid!=0 or marker.stat().st_mode&0o077 or marker.read_text()!='worker3-networkd-isolated-v1\n':
            raise ProviderError('lab-only','Private explicit lab permit missing.')
        links=json.loads(run(['ip','-j','link','show']))
        allowed={'lo','w3boot0','w3test0','w3peer0','w3canary0','w3canarypeer0'}
        if set(l['ifname'] for l in links)-allowed or not any(l['ifname']=='w3boot0' and l.get('address')=='52:54:00:73:33:01' for l in links):
            raise ProviderError('lab-only','Guest interface boundary differs; no native-host fallback.')
        if not self.helper.is_file() or self.helper.is_symlink() or self.helper.stat().st_uid!=0 or self.helper.stat().st_mode&0o022:
            raise ProviderError('lab-only','Fixed root-owned local recovery helper not installed.')

    def _registry(self):
        if not self.state_file.exists():return {}
        if self.state_file.is_symlink() or self.state_file.stat().st_uid!=0 or self.state_file.stat().st_size>4*1024*1024:
            raise ValueError('Unsafe ownership registry.')
        return json.loads(self.state_file.read_text()).get('plans',{})

    def capture(self, allow_changes=False):
        import yaml
        files=graph();network=yaml.safe_load(run(['netplan','get','all'])).get('network',{})
        active=run(['systemctl','is-active','systemd-networkd.service'])=='active'
        raw=json.loads(run(['ip','-j','-d','address','show']))
        routes=[]
        for family,argv in [('inet',['ip','-j','route','show']),('inet6',['ip','-j','-6','route','show'])]:
            for r in json.loads(run(argv)):
                routes.append({'family':family,**{k:r[k] for k in ('dst','gateway','dev','metric','table','protocol','prefsrc') if k in r}})
        lab_ready=False
        if allow_changes:
            try:self._lab_guard();lab_ready=True
            except (OSError,ValueError):pass
        registry=self._registry();adapters=[];definitions={}
        for link in raw:
            name=link.get('ifname');mac=link.get('address','').lower();index=link.get('ifindex')
            if not isinstance(name,str) or type(index)is not int:continue
            ident=str(index)+':'+mac.replace(':','');reason='Only the isolated eligible Ethernet lab case can write.'
            cfg=unknown_configuration(reason);selected=None;definition=None
            addresses=sorted([{'family':a['family'],'local':a['local'],'prefixLength':a['prefixlen'],'scope':a.get('scope')}
                for a in link.get('addr_info',[]) if a.get('family') in ('inet','inet6')],key=lambda x:json.dumps(x,sort_keys=True))
            try:
                selected=selected_file(index)
                net_id,definition=netdef_for(network,name,mac)
                expected='/run/systemd/network/10-netplan-'+net_id+'.network'
                source='netplan-effective'
                if selected!=expected:
                    owned=next((p for p in registry.values() if p['phase']=='confirmed' and p['candidate']['basename']==pathlib.Path(selected or '').name and
                        files.get(selected,{}).get('sha256')==p['candidate']['sha256']),None)
                    if not owned:raise ProviderError('unsupported-config','Selected config does not match exact Netplan definition or owned receipt.')
                    # Foreign Netplan changes cannot silently be hidden by an old override.
                    baseline_np={k:v for k,v in owned['baseline']['fileGraph'].items() if '/netplan' in k}
                    if baseline_np!={k:v for k,v in files.items() if '/netplan' in k}:raise ProviderError('ownership-conflict','Underlying Netplan sources changed.')
                    definition=copy.deepcopy(owned['candidate']['effectiveDefinition']);source='owned-networkd-override'
                if selected not in files:raise ValueError('Selected config not in complete file graph.')
                if any('.network.d/' in path for path in files):
                    raise ValueError('Networkd drop-in precedence needs a separately verified parser; configuration origin unknown.')
                cfg=configuration(definition,source)
                if not MAC.fullmatch(mac) or link.get('link_type')!='ether' or link.get('linkinfo',{}).get('info_kind') not in (None,'veth'):
                    raise ValueError('Plain managed Ethernet required.')
                if definition.get('dhcp6') or definition.get('accept-ra') is not False:
                    raise ValueError('First candidate requires explicit static IPv6/RA-off baseline to prove preservation.')
                if cfg['address'] is None and cfg['ipv4Method']!='auto':raise ValueError('Exactly one baseline IPv4 address required.')
                writable=bool(active and lab_ready and name=='w3test0' and all(shutil.which(c) for c in ('systemd-run','busctl','resolvectl')))
                if writable:
                    reason=None;cfg['writeCapabilities'].update(manualIpv4=True,manualDns=True,mtu=True)
                    for field in ('manualIpv4','manualDns','mtu'):cfg['writeReasons'][field]=None
                definitions[ident]={'id':net_id,'definition':definition}
            except (OSError,ValueError) as error:
                writable=False;reason=str(error)
                if cfg['source']=='unknown':cfg=unknown_configuration(reason)
                else:
                    cfg['writeCapabilities']={key:False for key in cfg['writeCapabilities']}
                    for key in ('manualIpv4','manualDns','mtu'):cfg['writeReasons'][key]=reason
            dns=None
            try:
                text=run(['resolvectl','dns',name]);dns=[]
                for line in text.splitlines():
                    if ':' not in line:continue
                    for word in line.split(':',1)[1].split():
                        try:dns.append(str(ipaddress.ip_address(word)))
                        except ValueError:pass
            except (OSError,ValueError):pass
            adapters.append({'id':ident,'name':name,'ifindex':index,'mac':mac or None,'kind':link.get('linkinfo',{}).get('info_kind') or link.get('link_type'),
                'adminUp':'UP' in link.get('flags',[]),'operState':link.get('operstate','UNKNOWN'),'mtu':link.get('mtu'),
                'addresses':addresses,'routes':sorted([r for r in routes if r.get('dev')==name],key=lambda r:json.dumps(r,sort_keys=True)),
                'dnsServers':dns,'dnsSource':'resolvectl' if dns is not None else None,'selectedConfig':selected,
                'configuration':cfg,'capabilities':{'configureIpv4':writable,'enable':False,'disable':False},'configurationReason':reason})
        adapters.sort(key=lambda a:a['id'])
        baseline={'bootId':self.boot_id(),'fileGraph':files,'adapters':copy.deepcopy(adapters),
            'managerPid':run(['systemctl','show','--value','--property=MainPID','systemd-networkd.service']),
            'managerVersion':run(['networkctl','--version']).splitlines()[0]}
        # Permission flags/configRevision are not native-state changes.
        for a in baseline['adapters']:
            a.pop('capabilities');a.pop('configurationReason');a['configuration'].pop('configurationRevision',None)
            a['configuration'].pop('writeCapabilities',None);a['configuration'].pop('writeReasons',None)
        revision=digest(baseline)
        for a in adapters:
            if a['configuration']['source']!='unknown':a['configuration']['configurationRevision']=revision
        return {'schemaVersion':1,'scope':'host','generatedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
            'manager':MANAGER,'rollbackMethod':ROLLBACK,'revision':revision,'bootId':self.boot_id(),
            'adapters':adapters,'fileGraph':files,'definitions':definitions,'canonical':baseline,
            'capabilities':{'readAdapters':True,'diagnose':True,'configureIpv4':any(a['capabilities']['configureIpv4'] for a in adapters),
                'enable':False,'disable':False,'networkManagerCheckpoint':False}}

    def public_snapshot(self, observed):
        return {k:v for k,v in observed.items() if k not in ('fileGraph','definitions','canonical','bootId')}

    def build_candidate(self, adapter, settings, token, baseline, plans):
        import yaml
        self._lab_guard()
        if not UUID.fullmatch(token) or not IFACE.fullmatch(adapter['name']) or not MAC.fullmatch(adapter['mac']):raise ValueError('Invalid candidate identity.')
        info=baseline['definitions'][adapter['id']];definition=copy.deepcopy(info['definition'])
        before=copy.deepcopy(definition)
        definition['dhcp4']=False
        definition['addresses']=[entry for entry in definition.get('addresses',[]) if ipaddress.ip_interface(
            entry if isinstance(entry,str) else next(iter(entry))).version==6]+[settings['address']+'/'+str(settings['prefixLength'])]
        definition.pop('gateway4',None)
        definition['routes']=[r for r in definition.get('routes',[]) if not (r.get('to') in ('default','0.0.0.0/0') and
            ('via' not in r or ipaddress.ip_address(r['via']).version==4))]
        if settings['gateway']:definition['routes'].append({'to':'0.0.0.0/0','via':settings['gateway']})
        definition.setdefault('nameservers',{})['addresses']=settings['dnsServers']
        definition.setdefault('dhcp4-overrides',{})['use-dns']=False
        if settings['mtu'] is not None:definition['mtu']=settings['mtu']
        outputs=[]
        private=self.state_file.parent/'staging';private.mkdir(mode=0o700,parents=True,exist_ok=True)
        for variant in (before,definition):
            with tempfile.TemporaryDirectory(prefix='netplan-',dir=private) as folder:
                stage=pathlib.Path(folder);np=stage/'etc/netplan';np.mkdir(mode=0o700,parents=True)
                file=np/'own-target.yaml';file.write_text(yaml.safe_dump({'network':{'version':2,'renderer':'networkd','ethernets':{info['id']:variant}}}));file.chmod(0o600)
                run(['netplan','generate','--root-dir='+str(stage)])
                generated=stage/'run/systemd/network'
                outputs.append({str(p.relative_to(generated)):p.read_text() for p in generated.rglob('*') if p.is_file()})
        target='10-netplan-'+info['id']+'.network'
        validate_staged_artifacts(outputs[0],outputs[1],target,settings['mtu'])
        text=outputs[1][target]
        if text.count('[Match]')!=1:raise ValueError('Ambiguous generated match.')
        text=re.sub(r'(?ms)^\[Match\]\s*\n.*?(?=^\[|\Z)','[Match]\nName='+adapter['name']+'\nMACAddress='+adapter['mac']+'\n\n',text,count=1)
        text='# windows7-web token='+token+'\n'+text
        prefix='00-00-windows7-web-'+str(adapter['ifindex'])+'-'+adapter['mac'].replace(':','')+'-'
        existing=[]
        for file,record in baseline['fileGraph'].items():
            if pathlib.Path(file).name.startswith(prefix):
                owned=next((p for p in plans.values() if p['phase']=='confirmed' and p['candidate']['basename']==pathlib.Path(file).name and p['candidate']['sha256']==record.get('sha256')),None)
                if not owned:raise ProviderError('ownership-conflict','Unregistered same-target owned namespace exists.')
                existing.append(int(pathlib.Path(file).stem.rsplit('-',1)[1]))
        generation=min(existing)-1 if existing else 9999999999999999
        if generation<=0:raise ValueError('Owned generation exhausted.')
        name=prefix+str(generation).zfill(16)+'.network'
        # Refuse any earlier arbitrary profile; never guess complex matching.
        for file in baseline['fileGraph']:
            path=pathlib.Path(file)
            if path.suffix=='.network' and path.name<name:
                body=path.read_text()
                if earlier_cannot_match(body,adapter['name'],adapter['mac']):
                    continue
                raise ProviderError('unsupported-config','Earlier networkd profile precedence not proven.')
        return {'basename':name,'text':text,'sha256':digest(text.encode()),'effectiveDefinition':definition,
            'preview':{'before':adapter['configuration'],'after':settings,'persistenceMode':PERSISTENCE,
                'ownershipTransfer':{'from':adapter['selectedConfig'],'to':'own target-only networkd override'},
                'runtimeArtifact':name,'persistentArtifact':name,'globalReloadPolicy':'isolated-lab-only',
                'productionReady':False,'originalNetplanFilesUnchanged':True}}

    def _paths(self,plan):
        candidate=plan['candidate'];name=candidate['basename']
        for folder in (RUN,ETC):
            info=folder.lstat()
            if folder.is_symlink() or not stat.S_ISDIR(info.st_mode) or info.st_uid!=0 or info.st_mode&0o022:
                raise PermissionError('Native config directory ownership/type invalid.')
        if not BASENAME.fullmatch(name) or digest(candidate['text'].encode())!=candidate['sha256'] or not candidate['text'].startswith('# windows7-web token='+plan['token']+'\n'):
            raise ValueError('Candidate ownership/integrity invalid.')
        return RUN/name,ETC/name

    def _check_graph(self,plan,current,allow_persistent=False):
        if current['bootId']!=plan['bootId'] or any(current['canonical'][k]!=plan['baseline']['canonical'][k] for k in ('managerPid','managerVersion')):
            raise ProviderError('revision-conflict','Boot/manager identity changed.')
        runtime,persistent=self._paths(plan);expected=plan['baseline']['fileGraph'];actual=copy.deepcopy(current['fileGraph'])
        for file in (runtime,persistent) if allow_persistent else (runtime,):
            record=actual.pop(str(file),None)
            if record is not None and (record.get('sha256')!=plan['candidate']['sha256'] or record.get('uid')!=0 or record.get('mode')!=0o600):
                raise ProviderError('ownership-conflict','Own artifact changed; refusing replacement/deletion.')
        if actual!=expected:raise ProviderError('revision-conflict','Foreign config graph changed.')

    def check_baseline(self,plan):
        self._lab_guard()
        if self.capture(True)['revision']!=plan['baseline']['revision']:raise ProviderError('revision-conflict','Full native baseline changed.')

    def _check_others(self,plan,current):
        old={a['id']:a for a in plan['baseline']['canonical']['adapters'] if a['id']!=plan['adapterId']}
        new={a['id']:a for a in current['canonical']['adapters'] if a['id']!=plan['adapterId']}
        if old!=new:raise ProviderError('foreign-interface-changed','Unrelated interface changed; no target-only success claim.')

    def check_pending(self,plan,allow_persistent=False):
        self._lab_guard();current=self.capture(True);self._check_graph(plan,current,allow_persistent);self._check_others(plan,current)
        if not plan.get('commitDecision') and self.timer_state(plan)!='active':
            raise ProviderError('ownership-conflict','Independent rollback timer is no longer active.')
        adapter=next((a for a in current['adapters'] if a['id']==plan['adapterId']),None)
        baseline=next(a for a in plan['baseline']['adapters'] if a['id']==plan['adapterId'])
        runtime,persistent=self._paths(plan)
        expected_path=str(persistent if allow_persistent and persistent.exists() else runtime)
        if not adapter or adapter['name']!=plan['name'] or adapter['mac']!=baseline['mac'] or adapter['selectedConfig']!=expected_path:
            raise ProviderError('ownership-conflict','Actual selected target file/identity differs.')
        wanted=plan['settings'];actual4=[a['local']+'/'+str(a['prefixLength']) for a in adapter['addresses'] if a['family']=='inet']
        if actual4!=[wanted['address']+'/'+str(wanted['prefixLength'])] or adapter['mtu']!=(wanted['mtu'] if wanted['mtu'] is not None else baseline['mtu']):
            raise ProviderError('readback-failed','Actual IPv4/MTU differs from plan.')
        if sorted(adapter['dnsServers'] or [])!=sorted(wanted['dnsServers']):raise ProviderError('readback-failed','Actual per-link DNS differs from plan.')
        if [a for a in adapter['addresses'] if a['family']=='inet6']!=[a for a in baseline['addresses'] if a['family']=='inet6']:
            raise ProviderError('readback-failed','IPv6 addresses changed unexpectedly.')
        if [r for r in adapter['routes'] if r['family']=='inet6']!=[r for r in baseline['routes'] if r['family']=='inet6']:
            raise ProviderError('readback-failed','IPv6 routes changed unexpectedly.')
        defaults=[r for r in adapter['routes'] if r['family']=='inet' and r.get('dst') in ('default','0.0.0.0/0')]
        if (wanted['gateway'] is None and defaults) or (wanted['gateway'] is not None and
                (len(defaults)!=1 or defaults[0].get('gateway')!=wanted['gateway'])):
            raise ProviderError('readback-failed','Actual IPv4 default route differs from preview.')

    def _write_new(self,file,plan):
        self._lab_guard();data=plan['candidate']['text'].encode()
        if file.exists():
            info=file.lstat()
            if file.is_symlink() or info.st_uid!=0 or stat.S_IMODE(info.st_mode)!=0o600 or digest(file.read_bytes())!=plan['candidate']['sha256']:
                raise ProviderError('ownership-conflict','Existing artifact is not owned exact candidate.')
            return
        descriptor=os.open(file,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(descriptor,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
        directory=os.open(file.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(directory)
        finally:os.close(directory)

    def _reload(self,plan):
        self._lab_guard()
        # Explicitly NOT claimed production target-only: native259 has no no-reconfigure.
        run(['networkctl','reload']);run(['networkctl','reconfigure',plan['name']])

    def _wait(self,check):
        deadline=self.monotonic()+12;last=None
        while self.monotonic()<deadline:
            try:check();return
            except (OSError,ValueError) as error:last=error;time.sleep(.2)
        raise last or ValueError('Readback timeout.')

    def install_runtime(self,plan):
        runtime,_=self._paths(plan);self._write_new(runtime,plan);self._reload(plan)
        self._wait(lambda:self.check_pending(plan))

    def restore(self,plan):
        self._lab_guard();current=self.capture(True);self._check_graph(plan,current)
        runtime,_=self._paths(plan)
        if runtime.exists():
            runtime.unlink();directory=os.open(runtime.parent,os.O_RDONLY|os.O_DIRECTORY)
            try:os.fsync(directory)
            finally:os.close(directory)
            self._reload(plan)
        self._wait(lambda:self.check_baseline(plan))

    def persist(self,plan):
        if not plan.get('commitDecision'):raise ProviderError('permission-denied','Explicit durable commit decision missing.')
        _,persistent=self._paths(plan);self._write_new(persistent,plan);self._reload(plan)
        self._wait(lambda:self.check_pending(plan,True))

    def verify_committed(self,plan):self.check_pending(plan,True)

    def _unit_path(self,name):
        value=json.loads(run(['busctl','--json=short','call','org.freedesktop.systemd1','/org/freedesktop/systemd1',
            'org.freedesktop.systemd1.Manager','GetUnit','s',name]))['data'][0]
        if not value.startswith('/org/freedesktop/systemd1/unit/'):raise ValueError('Invalid timer unit object.')
        return value

    def arm_timer(self,plan,seconds):
        self._lab_guard();unit='windows7-web-networkd-'+plan['token']
        args=['/usr/bin/python3',str(self.helper),'recover','--token',plan['token']]
        run(['systemd-run','--unit='+unit,'--on-active='+str(seconds)+'s','--timer-property=AccuracySec=100ms',
            '--property=Type=oneshot','--property=RemainAfterExit=yes','--property=NoNewPrivileges=yes',*args])
        try:
            path=self._unit_path(unit+'.timer')
            if self.timer_state({'token':plan['token']})!='active':raise ValueError('Independent timer not active.')
            def property_value(object_path,interface,name,signature):
                value=json.loads(run(['busctl','--json=short','get-property','org.freedesktop.systemd1',
                    object_path,interface,name]))
                if not isinstance(value,dict) or value.get('type')!=signature or 'data' not in value:
                    raise ValueError('Unexpected systemd property type: '+name)
                return value['data']
            micros=property_value(path,'org.freedesktop.systemd1.Timer','NextElapseUSecMonotonic','t')
            if type(micros) is not int or not 0<micros<2**64:raise ValueError('Invalid timer deadline.')
            deadline=micros/1000000.0
            service_path=self._unit_path(unit+'.service')
            command=property_value(service_path,'org.freedesktop.systemd1.Service','ExecStart','a(sasbttttuii)')
            if (not isinstance(command,list) or len(command)!=1 or not isinstance(command[0],list)
                    or len(command[0])!=10 or command[0][0]!='/usr/bin/python3' or command[0][1]!=args):
                raise ValueError('Timer service command identity differs.')
            if not self.monotonic()<deadline<=plan['deadlineMonotonic']+3:raise ValueError('Invalid actual systemd monotonic deadline.')
            triggers=property_value(path,'org.freedesktop.systemd1.Unit','Triggers','as')
            if triggers!=[unit+'.service']:raise ValueError('Timer triggers a different service.')
            return {'unit':unit,'deadlineMonotonic':deadline,'serviceCommandVerified':True,
                'actualExecStart':command,'actualTriggers':triggers,'timerObjectPath':path,
                'serviceObjectPath':service_path,'armedMonotonic':self.monotonic()}
        except Exception:
            # Only stop a unit after systemd-run succeeded; never touch an existing unit on creation failure.
            self.disarm_timer(plan)
            raise

    def timer_state(self,plan):
        return run(['systemctl','show','--value','--property=ActiveState','windows7-web-networkd-'+plan['token']+'.timer'])

    def disarm_timer(self,plan):
        self._lab_guard()
        run(['systemctl','stop','windows7-web-networkd-'+plan['token']+'.timer'])
