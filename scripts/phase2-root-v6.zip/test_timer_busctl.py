"""Timer metadata parsing and cleanup; all manager operations are mocked."""
import copy
import json
import unittest
from unittest.mock import patch
import networkd_system as system


class TimerMetadataTests(unittest.TestCase):
    def setUp(self):
        self.backend=system.SystemBackend(system.STATE_FILE,True)
        self.backend.helper='/test/networkd_cli.py'
        self.plan={'token':'0123456789abcdef','deadlineMonotonic':120.0}
        self.unit='windows7-web-networkd-'+self.plan['token']
        self.args=['/usr/bin/python3',str(self.backend.helper),'recover','--token',self.plan['token']]
        self.properties={
            'NextElapseUSecMonotonic':{'type':'t','data':115000000},
            'ExecStart':{'type':'a(sasbttttuii)','data':[['/usr/bin/python3',self.args,False,0,0,0,0,0,0,0]]},
            'Triggers':{'type':'as','data':[self.unit+'.service']},
        }
        self.calls=[]
        self.create_fails=False

    def fake_run(self,argv,timeout=12):
        self.calls.append(argv)
        if argv[0]=='systemd-run':
            if self.create_fails:raise OSError('creation failed')
            return ''
        if argv[0]=='busctl' and 'get-property' in argv:return json.dumps(self.properties[argv[-1]])
        if argv[:2]==['systemctl','stop']:return ''
        raise AssertionError(argv)

    def run_timer(self):
        with patch.object(self.backend,'_lab_guard'), patch.object(self.backend,'_unit_path',side_effect=lambda n:'/unit/'+n), \
             patch.object(self.backend,'timer_state',return_value='active'), patch.object(self.backend,'monotonic',return_value=100), \
             patch.object(system,'run',side_effect=self.fake_run):
            return self.backend.arm_timer(self.plan,15)

    def assert_stopped(self):
        self.assertEqual([c for c in self.calls if c[:2]==['systemctl','stop']],
                         [['systemctl','stop',self.unit+'.timer']])

    def test_scalar_and_array_properties_and_exact_service(self):
        result=self.run_timer()
        self.assertEqual(result['deadlineMonotonic'],115.0)
        self.assertEqual(result['actualTriggers'],[self.unit+'.service'])
        self.assertEqual(result['actualExecStart'][0][1],self.args)
        self.assertFalse(any(c[:2]==['systemctl','stop'] for c in self.calls))

    def test_invalid_timer_data_fail_closed_and_remove_created_timer(self):
        for data in (True,0,-1,2**64,[115000000],'115000000'):
            with self.subTest(data=data):
                self.calls=[];self.properties['NextElapseUSecMonotonic']['data']=data
                with self.assertRaises(ValueError):self.run_timer()
                self.assert_stopped()

    def test_wrong_signature_command_trigger_and_expired_deadline_are_rejected(self):
        good=copy.deepcopy(self.properties)
        changes=[('NextElapseUSecMonotonic',{'type':'s','data':115000000}),
                 ('NextElapseUSecMonotonic',{'type':'t','data':99000000}),
                 ('ExecStart',{'type':'a(sasbttttuii)','data':[['/bin/false',self.args,False,0,0,0,0,0,0,0]]}),
                 ('Triggers',{'type':'as','data':['other.service']})]
        for key,value in changes:
            with self.subTest(key=key,value=value):
                self.calls=[];self.properties=copy.deepcopy(good);self.properties[key]=value
                with self.assertRaises(ValueError):self.run_timer()
                self.assert_stopped()

    def test_failed_creation_does_not_stop_a_preexisting_timer(self):
        self.create_fails=True
        with self.assertRaises(OSError):self.run_timer()
        self.assertFalse(any(c[:2]==['systemctl','stop'] for c in self.calls))


if __name__=='__main__':unittest.main()
