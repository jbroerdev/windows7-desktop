"""Isolated owned-share controller. Never installs Samba or edits global policy.

Root must explicitly adopt a standalone service, provision its auth/guest policy,
own the config directory and supply a real access verifier before enabling writes.
"""
import base64
import contextlib
import hashlib
import json
import os
import pathlib
import re
import stat
import subprocess
import threading
import uuid

MARKER='# windows7-desktop-owned-share v1'
SHARE='windows7-public'
FIELDS={'publicFolderSharing':{'off','readwrite'},'passwordProtectedSharing':{'on','off'},
        'smbEncryption':{'required','desired','default'}}


class SharingError(RuntimeError):
    def __init__(self,message,status=400,mutation='none'):
        super().__init__(message);self.status=status;self.mutation=mutation


def model(value):
    if not isinstance(value,dict) or set(value)!=set(FIELDS):raise SharingError('Invalid managed-share model.')
    if any(not isinstance(value[key],str) or value[key] not in allowed for key,allowed in FIELDS.items()):
        raise SharingError('Invalid managed-share value.')
    if value['passwordProtectedSharing']=='off' and value['smbEncryption']!='default':
        raise SharingError('Guest access requires an explicitly selected client-controlled default encryption policy.',422)
    return dict(value)


def render(value,directory):
    value=model(value);directory=str(directory)
    if any(char in directory for char in '\r\n\x00[]'):raise SharingError('Invalid fixed share directory.')
    on=value['publicFolderSharing']=='readwrite'
    return (MARKER+'\n['+SHARE+']\npath = '+directory+'\n'
        +'available = '+('yes' if on else 'no')+'\nbrowseable = '+('yes' if on else 'no')
        +'\nread only = no\nguest ok = '+('yes' if value['passwordProtectedSharing']=='off' else 'no')
        +'\nserver smb encrypt = '+value['smbEncryption']
        +'\nfollow symlinks = no\nwide links = no\n').encode('utf-8')


def parse_owned(data,directory):
    if len(data)>65536:raise SharingError('Owned configuration too large.',409)
    text=data.decode('utf-8',errors='strict')
    lines=text.splitlines()
    if not lines or lines[0]!=MARKER:raise SharingError('Configuration is not adopted by this controller.',409)
    values={}
    for line in lines[1:]:
        if line=='['+SHARE+']':continue
        key,separator,value=line.partition('=')
        if not separator or key.strip() in values:raise SharingError('Unexpected owned configuration content.',409)
        values[key.strip()]=value.strip()
    desired={'publicFolderSharing':{'yes':'readwrite','no':'off'}.get(values.get('available')),
             'passwordProtectedSharing':{'yes':'off','no':'on'}.get(values.get('guest ok')),
             'smbEncryption':values.get('server smb encrypt')}
    try:expected=render(desired,directory)
    except SharingError:raise SharingError('Owned configuration cannot be represented safely.',409)
    if data!=expected:raise SharingError('Owned configuration has unrecognized changes; refusing replacement.',409)
    return desired


def sync_directory(directory):
    if os.name=='posix':
        descriptor=os.open(directory,os.O_RDONLY|getattr(os,'O_DIRECTORY',0))
        try:os.fsync(descriptor)
        finally:os.close(descriptor)


def atomic_write(file,data):
    temporary=file.with_name(file.name+'.'+str(uuid.uuid4())+'.tmp')
    try:
        fd=os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
        os.replace(temporary,file);sync_directory(file.parent)
    finally:temporary.unlink(missing_ok=True)


class SambaTools:
    """Fixed testparm calls. Outputs are selected values, never full configs/secrets."""
    def parameter(self,config,key,section=None):
        argv=['testparm','--suppress-prompt','--parameter-name='+key]
        if section:argv.append('--section-name='+section)
        argv.append(str(config))
        result=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
            timeout=5,check=False,env={'PATH':'/usr/sbin:/usr/bin:/sbin:/bin','LANG':'C.UTF-8','LC_ALL':'C'})
        if result.returncode or len(result.stdout)>4096:raise SharingError('Samba rejected or could not read configuration.',503)
        return result.stdout.decode('utf-8',errors='strict').strip()

    def validate(self,config):
        if self.parameter(config,'server role').lower()!='standalone server':
            raise SharingError('Only an explicitly adopted standalone Samba service is supported.',409)

    def effective(self,config):
        self.validate(config)
        get=lambda key:self.parameter(config,key,SHARE)
        encryption=get('server smb encrypt').lower()
        # Samba documents default as its implicit if_required policy. This
        # equivalent readback alias never maps desired/required to default.
        if encryption=='if_required':encryption='default'
        return {'publicFolderSharing':{'yes':'readwrite','no':'off'}.get(get('available').lower()),
                'passwordProtectedSharing':{'yes':'off','no':'on'}.get(get('guest ok').lower()),
                'smbEncryption':encryption,
                'path':get('path'),'readOnly':get('read only').lower(),
                'followSymlinks':get('follow symlinks').lower(),'wideLinks':get('wide links').lower()}


class OwnedSmbShare:
    def __init__(self,*,include_file,master_config,directory,journal_file,tools=None,
                 reload_service=None,verify_access=None,adopted=False,auth_ready=False,guest_policy_ready=False):
        self.include=pathlib.Path(include_file).absolute();self.master=pathlib.Path(master_config).absolute()
        self.directory=pathlib.Path(directory).absolute();self.journal=pathlib.Path(journal_file).absolute()
        self.tools=tools or SambaTools();self.reload=reload_service;self.verify=verify_access
        self.adopted=adopted is True;self.auth_ready=auth_ready is True;self.guest_ready=guest_policy_ready is True
        self.lock=threading.RLock();self.lock_depth=0
        for file in (self.include,self.master,self.journal):
            if file.is_symlink() or file.parent.is_symlink():raise SharingError('Configuration symlinks are not allowed.',409)
            if not file.parent.is_dir():raise SharingError('Root-owned configuration directory must be provisioned first.',503)
            if os.name=='posix':
                info=file.parent.stat()
                if info.st_uid!=os.geteuid() or info.st_mode&(stat.S_IWGRP|stat.S_IWOTH):
                    raise SharingError('Configuration directory is not privately owned.',409)
        if self.directory.is_symlink() or not self.directory.is_dir():raise SharingError('Fixed public directory must be provisioned first.',503)

    @contextlib.contextmanager
    def _locked(self):
        with self.lock:
            descriptor=None
            try:
                if self.lock_depth==0 and os.name=='posix':
                    import fcntl
                    lockfile=self.journal.with_name(self.journal.name+'.lock')
                    descriptor=os.open(lockfile,os.O_RDWR|os.O_CREAT|getattr(os,'O_NOFOLLOW',0),0o600)
                    info=os.fstat(descriptor)
                    if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.geteuid() or info.st_mode&0o077:
                        raise SharingError('Invalid private transaction lock.',409)
                    fcntl.flock(descriptor,fcntl.LOCK_EX)
                self.lock_depth+=1
                try:yield
                finally:self.lock_depth-=1
            finally:
                if descriptor is not None:
                    import fcntl
                    fcntl.flock(descriptor,fcntl.LOCK_UN);os.close(descriptor)

    @staticmethod
    def guard(authorized):
        if not callable(authorized) or authorized() is not True:raise SharingError('Personal administrator authorization changed.',403)

    def _read(self):
        if self.include.is_symlink() or self.master.is_symlink():raise SharingError('Configuration identity changed.',409)
        data=self.include.read_bytes();master=self.master.read_bytes()
        if len(master)>1024*1024:raise SharingError('Master configuration exceeds adopted scope.',409)
        current=parse_owned(data,self.directory)
        line='include = '+str(self.include)
        matches=[item for item in master.decode('utf-8',errors='strict').splitlines() if item.strip()==line]
        if len(matches)!=1:raise SharingError('Master must contain exactly the adopted include directive.',409)
        revision=hashlib.sha256(master+b'\x00'+data).hexdigest()
        return current,data,master,revision

    def _verify_effective(self,config,expected):
        actual=self.tools.effective(config)
        if any(actual.get(key)!=expected[key] for key in FIELDS) or actual.get('path')!=str(self.directory) or any(actual.get(key)!='no' for key in ('readOnly','followSymlinks','wideLinks')):
            raise SharingError('Effective Samba settings do not match the managed model.',503)

    def _pending_recovery(self):
        if not self.journal.exists():return False
        if self.journal.is_symlink() or self.journal.stat().st_size>131072:raise SharingError('Invalid recovery journal.',409)
        record=json.loads(self.journal.read_text(encoding='utf-8'))
        if not isinstance(record,dict) or record.get('version')!=1:raise SharingError('Invalid recovery journal.',409)
        phase=record.get('phase')
        if phase not in ('prepared','applied','rolled-back','committed','recovery-required'):raise SharingError('Invalid recovery phase.',409)
        return phase not in ('rolled-back','committed')

    def snapshot(self,authorized):
        self.guard(authorized)
        with self._locked():
            self.guard(authorized);current,data,master,revision=self._read()
            self._verify_effective(self.master,current);self.guard(authorized)
            pending=self._pending_recovery()
            return {'scope':'managed-public-share','values':current,'revision':revision,
                'source':'validated-effective-config','recoveryRequired':pending,
                'writable':bool(not pending and self.adopted and self.auth_ready and callable(self.reload) and callable(self.verify))}

    def _journal(self,value):atomic_write(self.journal,json.dumps(value,sort_keys=True).encode('utf-8'))

    def save(self,changes,expected_revision,authorized):
        self.guard(authorized)
        with self._locked():
            self.guard(authorized)
            if self._pending_recovery():raise SharingError('Recover the interrupted sharing transaction first.',409,'recovery-required')
            if not self.adopted or not self.auth_ready or not callable(self.reload) or not callable(self.verify):
                raise SharingError('Service adoption, credentials and a real access verifier are required.',501)
            if not isinstance(expected_revision,str) or not re.fullmatch(r'[a-f0-9]{64}',expected_revision):raise SharingError('Invalid sharing revision.')
            if not isinstance(changes,dict) or not changes or set(changes)-set(FIELDS):raise SharingError('Unknown or empty sharing change.')
            current,old,master,revision=self._read()
            if expected_revision!=revision:raise SharingError('Sharing configuration changed.',409)
            desired=model({**current,**changes})
            if desired['passwordProtectedSharing']=='off' and not self.guest_ready:raise SharingError('Reviewed server guest policy is required.',409)
            self._verify_effective(self.master,current);self.guard(authorized)
            if desired==current:return self.snapshot(authorized)
            candidate=self.include.with_name(self.include.name+'.'+str(uuid.uuid4())+'.candidate')
            validation=self.include.with_name(self.include.name+'.'+str(uuid.uuid4())+'.validation')
            record=None;mutated=False
            try:
                new=render(desired,self.directory);atomic_write(candidate,new)
                line='include = '+str(self.include)
                rewritten='\n'.join('include = '+str(candidate) if item.strip()==line else item for item in master.decode('utf-8').splitlines())+'\n'
                atomic_write(validation,rewritten.encode('utf-8'))
                self.tools.validate(validation);self._verify_effective(validation,desired);self.guard(authorized)
                if self._read()[3]!=revision:raise SharingError('Configuration changed during validation.',409)
                record={'version':1,'phase':'prepared','old':base64.b64encode(old).decode('ascii'),
                    'oldHash':hashlib.sha256(old).hexdigest(),'newHash':hashlib.sha256(new).hexdigest(),
                    'masterHash':hashlib.sha256(master).hexdigest(),'candidateName':candidate.name,
                    'validationName':validation.name,'validationHash':hashlib.sha256(rewritten.encode('utf-8')).hexdigest()}
                self._journal(record);self.guard(authorized)
                if self._read()[3]!=revision:raise SharingError('Configuration changed before installation.',409)
                os.replace(candidate,self.include);mutated=True;sync_directory(self.include.parent)
                record['phase']='applied';self._journal(record)
                self.reload();self.guard(authorized);self._verify_effective(self.master,desired)
                if self.verify(desired) is not True:raise SharingError('Independent SMB access verification failed.',503)
                self.guard(authorized);record['phase']='committed';self._journal(record)
                return self.snapshot(authorized)
            except Exception as error:
                if mutated:
                    try:
                        if hashlib.sha256(self.include.read_bytes()).hexdigest()!=record['newHash'] or self.master.read_bytes()!=master:
                            raise SharingError('External configuration changed; automatic rollback refused.',409)
                        atomic_write(self.include,old);self.reload();self._verify_effective(self.master,current)
                        if self.verify(current) is not True:raise SharingError('Rollback access check failed.',503)
                        record['phase']='rolled-back';self._journal(record)
                    except Exception:
                        record['phase']='recovery-required';self._journal(record)
                        raise SharingError('Sharing recovery needs administrator review.',503,'recovery-required') from error
                    raise SharingError(str(error),getattr(error,'status',503),'rolled-back') from error
                if record is not None:
                    record['phase']='rolled-back';self._journal(record)
                raise
            finally:
                candidate.unlink(missing_ok=True);validation.unlink(missing_ok=True)

    def _cleanup_record(self,record):
        for key,suffix,hashkey in [('candidateName','candidate','newHash'),('validationName','validation','validationHash')]:
            name=record.get(key)
            if name is None:continue
            if not isinstance(name,str) or not re.fullmatch(re.escape(self.include.name)+r'\.[a-f0-9-]{36}\.'+suffix,name):
                raise SharingError('Invalid recorded staging identity.',409,'recovery-required')
            file=self.include.parent/name
            if file.is_symlink():raise SharingError('Staging ownership changed.',409,'recovery-required')
            if file.exists():
                if hashlib.sha256(file.read_bytes()).hexdigest()!=record.get(hashkey):raise SharingError('Staging content changed.',409,'recovery-required')
                file.unlink();sync_directory(file.parent)

    def recover(self,authorized):
        self.guard(authorized)
        with self._locked():
            self.guard(authorized)
            if not self.adopted or not callable(self.reload) or not callable(self.verify):raise SharingError('Recovery requires service adoption and verifiers.',501)
            record=json.loads(self.journal.read_text(encoding='utf-8'))
            if record.get('version')!=1 or record.get('phase') not in ('prepared','applied','rolled-back','committed','recovery-required'):
                raise SharingError('Invalid recovery journal.',409)
            if record['phase'] in ('rolled-back','committed'):return self.snapshot(authorized)
            old=base64.b64decode(record['old'],validate=True)
            if len(old)>65536 or hashlib.sha256(old).hexdigest()!=record.get('oldHash'):raise SharingError('Invalid recovery backup.',409)
            current,actual,master,revision=self._read()
            if hashlib.sha256(master).hexdigest()!=record.get('masterHash') or hashlib.sha256(actual).hexdigest() not in (record.get('oldHash'),record.get('newHash')):
                raise SharingError('External changes prevent automatic recovery.',409,'recovery-required')
            previous=parse_owned(old,self.directory);self.guard(authorized)
            atomic_write(self.include,old);self.reload();self._verify_effective(self.master,previous)
            if self.verify(previous) is not True:raise SharingError('Recovery access verification failed.',503,'recovery-required')
            self._cleanup_record(record)
            record['phase']='rolled-back';self._journal(record)
            return self.snapshot(authorized)
