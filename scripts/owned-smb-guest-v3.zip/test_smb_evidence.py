import base64
import copy
import hashlib
import json
import pathlib
import tempfile
import unittest
from test_container_boundary import fixture
from verify_smb_evidence import verify,REQUIRED_EVENTS


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=pathlib.Path(self.temp.name)
        self.sources={'smb_owned_share.py':'a'*64,'smb_lab.py':'b'*64}
        self.events=[{'event':'smb-lab-source','file':name,'sha256':sha} for name,sha in self.sources.items()]
        self.events += [{'event':name,**({'passed':True} if name=='smb-lab-finished' else {})} for name in REQUIRED_EVENTS]
        next(e for e in self.events if e['event']=='smb-guest-share-pass').update(values={'smbEncryption':'default','passwordProtectedSharing':'off'},actualGuestRoundtrip=True,guestMinimumProtocol='SMB3_00')
        next(e for e in self.events if e['event']=='smb-incompatible-guest-policy-rejected-pass').update(activeBytesUnchanged=True,journalUnchanged=True)
        self.full=b'first line\n'+b'x'*17000+b'\nlast line\n'
        for name in ['daemon.stdout','smbd.log']:
            self.events.insert(-1,{'event':'smb-log-file','file':name,'present':True,'bytes':len(self.full),
                'sha256':hashlib.sha256(self.full).hexdigest(),'base64':base64.b64encode(self.full).decode('ascii')})
        self.write_events()
        self.write('attach-exit.txt','0\n');self.write('container-exit.txt','0\n')
        self.write('image-id.txt','sha256:'+'c'*64+'\n');self.write('container-id.txt','d'*64+'\n')
        self.write('actual-source-hashes.txt',''.join(sha+'  /owned/'+name+'\n' for name,sha in self.sources.items()))
        data=fixture();data.update(Id='d'*64,Image='sha256:'+'c'*64)
        self.write('container-before.json',json.dumps([data]));data=copy.deepcopy(data)
        data['State']={'Status':'exited','Running':False,'ExitCode':0,'OOMKilled':False,'Error':''}
        self.write('container-after.json',json.dumps([data]))
    def write(self,name,value):(self.root/name).write_text(value,encoding='utf-8')
    def write_events(self):self.write('smb-lab.log','Docker attach diagnostic\n'+''.join(json.dumps(e)+'\n' for e in self.events))
    def test_complete_evidence_reconstructs_full_logs_beyond_old_tail(self):
        self.assertTrue(verify(self.root)['passed'])
        self.assertEqual((self.root/'full-smbd.log').read_bytes(),self.full)
        self.assertEqual((self.root/'full-daemon.stdout').read_bytes(),self.full)
    def test_nonzero_exit_rejected_but_full_failure_logs_retained(self):
        self.write('attach-exit.txt','124\n')
        with self.assertRaises(ValueError):verify(self.root)
        self.assertEqual((self.root/'full-smbd.log').read_bytes(),self.full)
    def test_missing_crash_case_cannot_pass(self):
        self.events=[e for e in self.events if e['event']!='smb-process-recovery-pass'];self.write_events()
        with self.assertRaises(ValueError):verify(self.root)
    def test_success_event_with_false_finished_is_rejected(self):
        self.events[-1]['passed']=False;self.write_events()
        with self.assertRaises(ValueError):verify(self.root)
    def test_runtime_source_mismatch_is_rejected(self):
        self.events[0]['sha256']='f'*64;self.write_events()
        with self.assertRaises(ValueError):verify(self.root)
    def test_terminal_container_identity_or_state_mismatch_is_rejected(self):
        data=json.loads((self.root/'container-after.json').read_text(encoding='utf-8'))
        data[0]['State']['Running']=True;self.write('container-after.json',json.dumps(data))
        with self.assertRaises(ValueError):verify(self.root)
    def test_log_corruption_is_rejected(self):
        event=next(e for e in self.events if e['event']=='smb-log-file');event['sha256']='0'*64;self.write_events()
        with self.assertRaises(ValueError):verify(self.root)
    def test_log_path_escape_is_rejected(self):
        event=next(e for e in self.events if e['event']=='smb-log-file');event['file']='../escape';self.write_events()
        with self.assertRaises(ValueError):verify(self.root)
        self.assertFalse((self.root.parent/'escape').exists())
    def test_guest_smb2_fallback_cannot_pass(self):
        event=next(e for e in self.events if e['event']=='smb-guest-share-pass');event['guestMinimumProtocol']='SMB2_02';self.write_events()
        with self.assertRaises(ValueError):verify(self.root)


if __name__=='__main__':unittest.main(verbosity=2)
