#!/bin/sh
set -eu
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
image=worker2-owned-smb-lab:20261105
container_id=
cleanup() {
    if [ -n "$container_id" ]; then docker rm --force "$container_id" >/dev/null 2>&1 || true; fi
}
finish() {
    result=$?
    trap - EXIT HUP INT TERM
    printf '%s\n' "$result" > "$script_dir/evidence/runner-exit.txt" || true
    cleanup
    exit "$result"
}
trap finish EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
mkdir -p "$script_dir/evidence"
sha256sum "$script_dir/smb_owned_share.py" "$script_dir/smb_lab.py" "$script_dir/Dockerfile.smb-lab" "$script_dir/run-smb-lab.sh" > "$script_dir/evidence/actual-source-hashes.txt"
docker build --file "$script_dir/Dockerfile.smb-lab" --tag "$image" "$script_dir"
image_id=$(docker image inspect --format '{{.Id}}' "$image")
printf '%s\n' "$image_id" > "$script_dir/evidence/image-id.txt"
controller_sha=$(sha256sum "$script_dir/smb_owned_share.py" | cut -d " " -f 1)
harness_sha=$(sha256sum "$script_dir/smb_lab.py" | cut -d " " -f 1)
container_id=$(docker create --network none --cap-drop ALL --cap-add SETUID --cap-add SETGID \
    --security-opt no-new-privileges --read-only --pids-limit 64 --memory 256m --cpus 1 \
    --tmpfs /run:rw,nosuid,nodev,size=32m --tmpfs /tmp:rw,nosuid,nodev,size=16m \
    --tmpfs /data:rw,nosuid,nodev,size=32m,mode=0755 \
    --env WORKER2_SMB_LAB=loopback-auth-two-identities-v1 \
    --env WORKER2_CONTROLLER_SHA="$controller_sha" --env WORKER2_HARNESS_SHA="$harness_sha" "$image_id")
case "$container_id" in ''|*[!a-f0-9]*) container_id=; exit 2;; esac
if [ "${#container_id}" -ne 64 ]; then container_id=; exit 2; fi
printf '%s\n' "$container_id" > "$script_dir/evidence/container-id.txt"
docker inspect "$container_id" > "$script_dir/evidence/container-before.json"
python3 "$script_dir/verify_smb_container.py" < "$script_dir/evidence/container-before.json"
set +e
timeout 180s docker start --attach "$container_id" > "$script_dir/evidence/smb-lab.log" 2>&1
attach_exit=$?
set -e
printf '%s\n' "$attach_exit" > "$script_dir/evidence/attach-exit.txt"
docker inspect "$container_id" > "$script_dir/evidence/container-after.json"
container_exit=$(docker inspect --format '{{.State.ExitCode}}' "$container_id")
printf '%s\n' "$container_exit" > "$script_dir/evidence/container-exit.txt"
cat "$script_dir/evidence/smb-lab.log"
set +e
python3 "$script_dir/verify_smb_evidence.py" "$script_dir/evidence"
verification_exit=$?
set -e
printf '%s\n' "$verification_exit" > "$script_dir/evidence/verification-exit.txt"
if [ "$attach_exit" -ne 0 ]; then exit "$attach_exit"; fi
if [ "$container_exit" -ne 0 ]; then exit "$container_exit"; fi
exit "$verification_exit"
