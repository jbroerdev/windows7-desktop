"""Root reviews this exact runtime boundary before running the new Samba lab."""
import json
import sys


def verify(item):
    host=item['HostConfig']
    normalize=lambda values:{value.upper().removeprefix('CAP_') for value in (values or [])}
    if host.get('Privileged') or host.get('NetworkMode')!='none':raise ValueError('Nonprivileged network-none required.')
    if normalize(host.get('CapAdd'))!={'SETUID','SETGID'} or normalize(host.get('CapDrop'))!={'ALL'}:
        raise ValueError('Only the two explicitly reviewed identity-switching capabilities are permitted.')
    if host.get('Binds') or host.get('Devices') or host.get('DeviceRequests') or host.get('VolumesFrom'):
        raise ValueError('Host resources/devices forbidden.')
    if any(host.get(key)=='host' for key in ('PidMode','IpcMode','UTSMode')):raise ValueError('Host namespace forbidden.')
    if not host.get('ReadonlyRootfs'):raise ValueError('Read-only root required.')
    options=host.get('SecurityOpt') or []
    if not any(value in ('no-new-privileges','no-new-privileges:true') for value in options):raise ValueError('No-new-privileges required.')
    if any(value.startswith(('seccomp=','apparmor=')) for value in options):raise ValueError('Default security profiles must remain.')
    allowed={'/run','/tmp','/data'}
    if set(host.get('Tmpfs') or {})!=allowed:raise ValueError('Unexpected tmpfs.')
    if any(mount.get('Type')!='tmpfs' or mount.get('Destination') not in allowed for mount in item.get('Mounts',[])):
        raise ValueError('Unexpected mount.')
    if item['Config'].get('Volumes') or host.get('PublishAllPorts') or host.get('PortBindings'):
        raise ValueError('Image volumes or published ports forbidden.')
    return True


if __name__=='__main__':
    values=json.load(sys.stdin)
    if not isinstance(values,list) or len(values)!=1:raise ValueError('Expected our one newly created container.')
    verify(values[0]);print('Samba laboratory metadata allowlist: PASS')
