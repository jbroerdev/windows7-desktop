import copy
import unittest
from verify_smb_container import verify


def fixture():
    return {'Config':{'Volumes':None},'Mounts':[],'HostConfig':{
        'Privileged':False,'NetworkMode':'none','CapAdd':['SETUID','SETGID'],'CapDrop':['ALL'],
        'Binds':None,'Devices':[],'DeviceRequests':None,'VolumesFrom':None,'PidMode':'','IpcMode':'private','UTSMode':'',
        'ReadonlyRootfs':True,'SecurityOpt':['no-new-privileges:true'],
        'Tmpfs':{key:'rw' for key in ['/run','/tmp','/data']},'PublishAllPorts':False,'PortBindings':{}}}


class ContainerBoundary(unittest.TestCase):
    def test_reviewed_identity_capability_set_is_allowed(self):self.assertTrue(verify(fixture()))
    def test_network_caps_or_privileged_mode_are_not_a_fallback(self):
        for key,value in [('Privileged',True),('CapAdd',['SETUID','SETGID','NET_ADMIN']),('CapAdd',['NET_ADMIN','NET_RAW']),('CapDrop',[])]:
            data=fixture();data['HostConfig'][key]=value
            with self.subTest(key=key,value=value),self.assertRaises(ValueError):verify(data)
    def test_host_network_mounts_devices_and_ports_are_denied(self):
        for key,value in [('NetworkMode','host'),('Binds',['/etc:/etc']),('Devices',[{'PathOnHost':'/dev/sda'}]),
                          ('PidMode','host'),('IpcMode','host'),('UTSMode','host'),('PortBindings',{'1445/tcp':[{'HostPort':'1445'}]})]:
            data=fixture();data['HostConfig'][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):verify(data)
    def test_writable_root_or_relaxed_security_is_denied(self):
        for key,value in [('ReadonlyRootfs',False),('SecurityOpt',[]),('SecurityOpt',['no-new-privileges','seccomp=unconfined'])]:
            data=fixture();data['HostConfig'][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):verify(data)
    def test_unexpected_mount_and_image_volume_are_denied(self):
        data=fixture();data['Mounts']=[{'Type':'bind','Destination':'/data'}]
        with self.assertRaises(ValueError):verify(data)
        data=fixture();data['Config']['Volumes']={'/host':{}}
        with self.assertRaises(ValueError):verify(data)


if __name__=='__main__':unittest.main(verbosity=2)
