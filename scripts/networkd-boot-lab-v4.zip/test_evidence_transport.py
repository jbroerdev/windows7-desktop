"""Synthetic protocol/receipt unit fixtures only. No actual boot/manager proof."""
import base64
import copy
import json
import pathlib
import tempfile
import unittest
from unittest import mock
import evidence_transport as transport
from test_lab_guard import guard, guest, valid, mapping_probe, DIR


def boot_files():
    probe = mapping_probe()
    for key in ('networkctlVersion','systemdRunVersion','netplanInfo','netplanVersion','networkctlStatus'):
        probe['commands'][key] = {'exitCode':0,'truncated':False,'output':'synthetic unit fixture'}
    result = {'phase':'availability-only','passed':True,'applyExecuted':False,'rollbackVerified':False,
        'commitVerified':False,'productionAccess':False,'pid1':'systemd','actualGuestPid1':True,
        'actualNetworkd':True,'actualNetplan':True,'actualSelectedConfigObserved':True,
        'probe':probe,'actualSelectedConfigMapping':guest.verify_guest_mapping(probe)}
    boot = {'phase':'availability-only','passed':True,'applyExecuted':False,'rollbackVerified':False,
        'commitVerified':False,'productionAccess':False,'qemuExitCode':0,'guest':result,
        'qemuVersion':'synthetic unit fixture','installedPackages':'synthetic unit fixture',
        'binarySha256':{n:'a'*64 for n in ('qemu-system-x86_64','qemu-img','cloud-localds')},
        'guestImageSha256':json.loads((DIR/'image-sources.json').read_text())['cloudImageSha256']}
    argv = ['qemu-system-x86_64','-accel','tcg,thread=single','-machine','q35','-cpu','max',
        '-smp','1','-m','1024','-nodefaults','-no-reboot','-display','none','-monitor','none','-serial','stdio',
        '-drive','file=/run/lab/guest.qcow2,if=virtio,format=qcow2',
        '-drive','file=/run/lab/seed.img,if=virtio,format=raw,readonly=on',
        '-netdev','user,id=isolated,restrict=on','-device','virtio-net-pci,netdev=isolated,mac=52:54:00:73:33:01']
    return {'result.json':json.dumps(boot).encode(), 'qemu-argv.json':json.dumps(argv).encode(),
        'serial.log':b'full synthetic boot log\nWORKER3_LAB_RESULT '+base64.b64encode(json.dumps(result).encode())+b'\nshutdown\n'}


def framed(files):
    with tempfile.TemporaryDirectory(dir=DIR) as tmp:
        folder=pathlib.Path(tmp)
        for name, data in files.items():(folder/name).write_bytes(data)
        return b''.join(transport.frames(folder))


def receipt_fixture(folder):
    files=boot_files();log=framed(files)
    (folder/'attach.log').write_bytes(log)
    transport.extract(folder/'attach.log',folder/'container')
    before=valid();before['Id']='a'*64
    after=copy.deepcopy(before);after['State']={'ExitCode':0,'Running':False,'OOMKilled':False,'Error':''}
    for name, obj in [('container-before.json',[before]),('container-final.json',[after]),
            ('package-identity.json',{'phase':'availability-only'})]:
        (folder/name).write_text(json.dumps(obj))
    (folder/'image.id').write_text('sha256:expected')
    (folder/'attach-exit-code.txt').write_text('0')


class TransportTests(unittest.TestCase):
    def test_roundtrip_full_binary_serial_and_extract(self):
        files=boot_files();files['serial.log']+=b'\x00\xff'+b'x'*100000
        log=framed(files)
        self.assertEqual(transport.decode(log)[0],files)
        with tempfile.TemporaryDirectory(dir=DIR) as tmp:
            folder=pathlib.Path(tmp);(folder/'attach.log').write_bytes(log)
            manifest=transport.extract(folder/'attach.log',folder/'decoded')
            self.assertEqual(set(manifest['files']),set(files))
            self.assertEqual((folder/'decoded/serial.log').read_bytes(),files['serial.log'])
            with self.assertRaises(FileExistsError):transport.extract(folder/'attach.log',folder/'decoded')

    def test_truncation_duplicate_reorder_or_foreign_line_rejected(self):
        files=boot_files();files['serial.log']+=b'x'*200000
        lines=framed(files).splitlines(keepends=True)
        mutations=[lines[:-1],lines[1:],lines+[lines[-1]],lines[:2]+[lines[1]]+lines[2:],
            lines[:1]+[lines[2],lines[1]]+lines[3:],[b'passed:true\n']+lines,
            [line for i,line in enumerate(lines) if i != 2]]
        for index, altered in enumerate(mutations):
            with self.subTest(index=index):
                with self.assertRaises((ValueError,KeyError)):transport.decode(b''.join(altered))

    def test_digest_corruption_and_duplicate_json_key(self):
        log=framed(boot_files());lines=log.splitlines(keepends=True)
        begin=json.loads(lines[0][len(transport.PREFIX):]);begin['sha256']='0'*64
        lines[0]=transport.PREFIX+json.dumps(begin).encode()+b'\n'
        with self.assertRaises(ValueError):transport.decode(b''.join(lines))
        with self.assertRaises(ValueError):transport.loads('{"version":3,"version":3}')

    def test_bounds_and_allowlist(self):
        with mock.patch.object(transport,'MAX_ATTACH',3):
            with self.assertRaises(ValueError):transport.decode(b'1234')
        files=boot_files()
        with mock.patch.dict(transport.LIMITS,{'serial.log':1}):
            with self.assertRaises(ValueError):framed(files)
        with tempfile.TemporaryDirectory(dir=DIR) as tmp:
            with self.assertRaises(ValueError):list(transport.frames(tmp))

    def test_full_receipt_synthetic_positive_and_failures(self):
        with tempfile.TemporaryDirectory(dir=DIR) as tmp:
            folder=pathlib.Path(tmp);receipt_fixture(folder)
            self.assertTrue(guard.finish(folder,0)['availabilityPassed'])
            self.assertFalse(guard.finish(folder,42)['availabilityPassed'])
            (folder/'attach-exit-code.txt').write_text('124')
            self.assertFalse(guard.finish(folder,0)['availabilityPassed'])
            (folder/'attach-exit-code.txt').write_text('0')
            (folder/'container/serial.log').write_bytes(b'changed')
            self.assertFalse(guard.finish(folder,0)['availabilityPassed'])

    def test_serial_guest_argv_mapping_versions_mismatch_fail(self):
        for change in ('serial','qemuExit','argv','mapping','versions','scope','duplicateGuest'):
            with self.subTest(change=change):
                files=boot_files();boot=json.loads(files['result.json'])
                if change=='serial':files['serial.log']=b'passed:true'
                if change=='duplicateGuest':files['serial.log']*=2
                if change=='qemuExit':boot['qemuExitCode']=124
                if change=='argv':files['qemu-argv.json']=b'["qemu-system-x86_64","-enable-kvm"]'
                if change=='mapping':boot['guest']['actualSelectedConfigMapping']['ifindex']=3
                if change=='versions':boot.pop('binarySha256')
                if change=='scope':boot['applyExecuted']=True
                files['result.json']=json.dumps(boot).encode()
                with self.assertRaises(ValueError):guard.verify_boot_files(files)


if __name__=='__main__':unittest.main(verbosity=2)
