"""Local artifact/metadata recorder; never starts Docker, QEMU or a manager."""
import hashlib
import json
import pathlib
import sys
import zipfile
import base64
import importlib.util
from evidence_transport import decode, extract, loads

_spec = importlib.util.spec_from_file_location('worker3_guest_mapping', pathlib.Path(__file__).with_name('guest-probe.py'))
_guest = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(_guest)


def digest(data):return hashlib.sha256(data).hexdigest()


def verify_package(archive, context):
    context = pathlib.Path(context).resolve()
    manifest = json.loads((context/'source-hashes.json').read_text())
    with zipfile.ZipFile(archive) as package:
        names = package.namelist()
        if len(names) != len(set(names)) or set(names) != set(manifest) | {'source-hashes.json'}:
            raise ValueError('Package entry allowlist/duplicates differ.')
        for name, sha in manifest.items():
            file = context/name
            if not file.resolve().is_relative_to(context) or file.is_symlink():
                raise ValueError('Package path outside context/symlink.')
            data = file.read_bytes()
            if digest(data) != sha or package.read(name) != data:
                raise ValueError('Extracted/package bytes differ: '+name)
        if package.read('source-hashes.json') != (context/'source-hashes.json').read_bytes():
            raise ValueError('Manifest differs from ZIP.')
    return {'archiveSha256':digest(pathlib.Path(archive).read_bytes()),
            'sourceManifestSha256':digest((context/'source-hashes.json').read_bytes()),
            'filesVerified':len(manifest),'phase':'availability-only'}


def verify_container(item, image):
    host = item['HostConfig']
    normalize = lambda a:{s.upper().removeprefix('CAP_') for s in (a or [])}
    if item['Image'] != image or host.get('Privileged') or host.get('NetworkMode') != 'none':
        raise ValueError('Wrong image/isolation.')
    if normalize(host.get('CapDrop')) != {'ALL'} or normalize(host.get('CapAdd')):
        raise ValueError('Capabilities must all be dropped.')
    if host.get('Binds') or host.get('Devices') or host.get('DeviceRequests') or host.get('VolumesFrom'):
        raise ValueError('No host resources/devices allowed.')
    if any(host.get(key) == 'host' for key in ('PidMode','IpcMode','UTSMode')):
        raise ValueError('No shared host namespace.')
    security = host.get('SecurityOpt') or []
    if not any(s in ('no-new-privileges','no-new-privileges:true') for s in security):
        raise ValueError('no-new-privileges missing.')
    if any(s.startswith(('seccomp=','apparmor=')) for s in security):
        raise ValueError('Default seccomp/AppArmor must not be overridden.')
    if not host.get('ReadonlyRootfs') or set(host.get('Tmpfs') or {}) != {'/run/lab','/tmp'}:
        raise ValueError('Read-only root and exact private tmpfs set required.')
    if any(m.get('Type') != 'tmpfs' or m.get('Destination') not in ('/run/lab','/tmp') for m in item.get('Mounts',[])):
        raise ValueError('Unexpected mount.')
    if item['Config'].get('Volumes') or host.get('PortBindings') or host.get('PublishAllPorts'):
        raise ValueError('No volumes or published ports.')
    if host.get('Memory') != 2147483648 or host.get('NanoCpus') != 1000000000 or host.get('PidsLimit') != 128:
        raise ValueError('Exact CPU/RAM/PID bounds required.')
    if item['Config'].get('Entrypoint') != ['python3','/opt/worker3-lab/container-boot.py']:
        raise ValueError('Unexpected entrypoint.')
    if 'WORKER3_QEMU_LAB=boot-availability-v1' not in item['Config'].get('Env',[]):
        raise ValueError('Explicit boot-only lab marker missing.')
    return {'metadataVerified':True,'imageId':image,'network':'none','caps':[],
            'kvmAllowed':False,'bindsAllowed':False,'portsAllowed':False}


def verify_boot_files(files):
    boot = loads(files['result.json'])
    serial = files['serial.log']
    records = [line[len(b'WORKER3_LAB_RESULT '):].strip() for line in serial.splitlines() if line.startswith(b'WORKER3_LAB_RESULT ')]
    if len(records) != 1:raise ValueError('Exactly one full guest result required in transported serial.')
    guest = loads(base64.b64decode(records[0],validate=True))
    if boot.get('guest') != guest or type(boot.get('qemuExitCode')) is not int or boot['qemuExitCode'] != 0:raise ValueError('Guest/result/QEMU mismatch.')
    for item in (boot, guest):
        if item.get('passed') is not True or item.get('phase') != 'availability-only':raise ValueError('Actual availability failed.')
        if any(item.get(key) is not False for key in ('applyExecuted','rollbackVerified','commitVerified','productionAccess')):raise ValueError('Unexpected scope.')
    if guest.get('pid1') != 'systemd' or any(guest.get(k) is not True for k in ('actualGuestPid1','actualNetworkd','actualNetplan','actualSelectedConfigObserved')):
        raise ValueError('Actual manager evidence missing.')
    mapping = _guest.verify_guest_mapping(guest['probe'])
    if mapping != guest.get('actualSelectedConfigMapping'):raise ValueError('Guest mapping differs from original probe.')
    for key in ('networkctlVersion','systemdRunVersion','netplanInfo','netplanVersion','networkctlStatus'):
        command = guest['probe']['commands'][key]
        if command.get('exitCode') != 0 or command.get('truncated'):raise ValueError('Missing/partial required manager command.')
    sources = json.loads(pathlib.Path(__file__).with_name('image-sources.json').read_text())
    if boot.get('guestImageSha256') != sources['cloudImageSha256']:raise ValueError('Guest image SHA mismatch.')
    if not boot.get('qemuVersion') or not boot.get('installedPackages'):raise ValueError('Missing actual QEMU/package versions.')
    binaries = boot.get('binarySha256',{})
    if set(binaries) != {'qemu-system-x86_64','qemu-img','cloud-localds'} or any(not isinstance(s,str) or len(s) != 64 or any(c not in '0123456789abcdef' for c in s) for s in binaries.values()):
        raise ValueError('Missing actual binary hashes.')
    argv = loads(files['qemu-argv.json'])
    expected = ['qemu-system-x86_64','-accel','tcg,thread=single','-machine','q35','-cpu','max',
        '-smp','1','-m','1024','-nodefaults','-no-reboot','-display','none','-monitor','none','-serial','stdio',
        '-drive','file=/run/lab/guest.qcow2,if=virtio,format=qcow2',
        '-drive','file=/run/lab/seed.img,if=virtio,format=raw,readonly=on',
        '-netdev','user,id=isolated,restrict=on','-device','virtio-net-pci,netdev=isolated,mac=52:54:00:73:33:01']
    if argv != expected:raise ValueError('Actual QEMU argv outside exact isolated allowlist.')
    return {'fullSerialGuestMatchesResult':True,'actualMappingRevalidated':mapping,'qemuArgvVerified':True}


def finish(folder, runner_exit):
    folder = pathlib.Path(folder)
    result = {'phase':'availability-only','outerRunnerExitCode':int(runner_exit),
              'applyExecuted':False,'rollbackVerified':False,'commitVerified':False}
    for file, key in [('package-identity.json','package'),('container-final.json','container'),
                      ('container/result.json','bootResult')]:
        path = folder/file
        if path.is_file():
            try:result[key] = json.loads(path.read_text())
            except (ValueError,OSError):result[key] = {'invalidOrUnavailable':True}
    if (folder/'image.id').is_file():result['imageId'] = (folder/'image.id').read_text().strip()
    if (folder/'attach-exit-code.txt').is_file():result['attachExitCode'] = int((folder/'attach-exit-code.txt').read_text())
    metadata = result.get('container')
    if isinstance(metadata,list) and len(metadata) == 1:
        result['containerId'] = metadata[0].get('Id')
        result['containerExitCode'] = metadata[0].get('State',{}).get('ExitCode')
    consistent = False
    try:
        from evidence_transport import MAX_ATTACH
        if (folder/'attach.log').stat().st_size > MAX_ATTACH:raise ValueError('Oversized attach transport.')
        files, transport = decode((folder/'attach.log').read_bytes())
        for name, data in files.items():
            path = folder/'container'/name
            if path.is_symlink() or path.read_bytes() != data:raise ValueError('Decoded disk evidence differs from transport.')
        result['transport'] = transport
        result['bootVerification'] = verify_boot_files(files)
        before = json.loads((folder/'container-before.json').read_text())
        if not isinstance(before,list) or len(before) != 1 or not isinstance(metadata,list) or len(metadata) != 1:raise ValueError('Exact before/after container evidence missing.')
        if before[0]['Id'] != metadata[0]['Id']:raise ValueError('Before/after container identity mismatch.')
        for item in (before[0],metadata[0]):verify_container(item,result['imageId'])
        state = metadata[0]['State']
        if state.get('Running') is not False or state.get('OOMKilled') is not False or state.get('Error') or type(state.get('ExitCode')) is not int:
            raise ValueError('Container did not cleanly exit.')
        if result.get('package',{}).get('phase') != 'availability-only':raise ValueError('Missing verified package identity.')
        consistent = True
    except (ValueError,OSError,KeyError,TypeError) as error:
        result['consistencyError'] = str(error)
    result['availabilityPassed'] = bool(consistent and result['outerRunnerExitCode'] == 0 and result.get('containerExitCode') == 0
        and result.get('attachExitCode') == 0)
    result['evidenceSha256'] = {str(p.relative_to(folder)):digest(p.read_bytes()) for p in folder.rglob('*')
        if p.is_file() and p.name != 'receipt.json' and not p.is_symlink()}
    (folder/'receipt.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    return result


def main():
    action, *args = sys.argv[1:]
    if action == 'package':result=verify_package(*args)
    elif action == 'container':
        data=json.load(sys.stdin)
        if not isinstance(data,list) or len(data) != 1:raise ValueError('Expected own single container.')
        result=verify_container(data[0],args[0])
    elif action == 'finish':
        result=finish(*args)
        if result['outerRunnerExitCode'] == 0 and not result['availabilityPassed']:
            raise ValueError('A zero runner status requires consistent actual guest/container evidence.')
    elif action == 'decode':result=extract(*args)
    else:raise ValueError('Unknown action.')
    print(json.dumps(result,sort_keys=True))


if __name__ == '__main__':main()
