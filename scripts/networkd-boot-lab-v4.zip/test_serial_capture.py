"""Small Python child process tests; never runs QEMU or network commands."""
import importlib.util
import pathlib
import sys
import tempfile
import unittest

DIR=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('container_boot',DIR/'container-boot.py')
boot=importlib.util.module_from_spec(spec);spec.loader.exec_module(boot)


class SerialCaptureTests(unittest.TestCase):
    def test_complete_serial_and_child_exit(self):
        with tempfile.TemporaryDirectory(dir=DIR) as tmp:
            file=pathlib.Path(tmp)/'serial.log'
            rc=boot.run_with_serial([sys.executable,'-c',"import sys;sys.stdout.buffer.write(b'a'*100000);sys.exit(7)"],file,timeout=5,limit=100000)
            self.assertEqual(rc,7);self.assertEqual(file.read_bytes(),b'a'*100000)

    def test_only_serial_is_bounded_not_private_disk(self):
        with tempfile.TemporaryDirectory(dir=DIR) as tmp:
            folder=pathlib.Path(tmp)
            code="import pathlib,sys;pathlib.Path(sys.argv[1]).write_bytes(b'd'*10000);sys.stdout.buffer.write(b'ok')"
            rc=boot.run_with_serial([sys.executable,'-c',code,str(folder/'private-disk')],folder/'serial.log',timeout=5,limit=2)
            self.assertEqual(rc,0);self.assertEqual((folder/'private-disk').stat().st_size,10000)

    def test_overflow_is_failure_and_output_stays_bounded(self):
        with tempfile.TemporaryDirectory(dir=DIR) as tmp:
            file=pathlib.Path(tmp)/'serial.log'
            with self.assertRaisesRegex(ValueError,'exceeded'):
                boot.run_with_serial([sys.executable,'-c',"import sys;sys.stdout.buffer.write(b'x'*100000)"],file,timeout=5,limit=1000)
            self.assertEqual(file.stat().st_size,1000)

    def test_timeout_preserves_partial_serial_without_success(self):
        with tempfile.TemporaryDirectory(dir=DIR) as tmp:
            file=pathlib.Path(tmp)/'serial.log'
            rc=boot.run_with_serial([sys.executable,'-u','-c',"import time;print('before timeout',flush=True);time.sleep(20)"],file,timeout=1,limit=1000)
            self.assertEqual(rc,124);self.assertIn(b'before timeout',file.read_bytes())


if __name__=='__main__':unittest.main(verbosity=2)
