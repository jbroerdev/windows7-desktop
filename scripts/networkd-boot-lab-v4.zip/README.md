# QEMU-TCG-Verfügbarkeit: ausschließlich isolierter Gastboot

Zentraler Auftrag: nur nach Rootreview auf dem vorhandenen GitHub-Ubuntu-CI-Rechner ausführen. Worker3 hat keine Docker-/QEMU-/Managerausführung vorgenommen. Dieses Paket macht keine Apply-/Rollback-/Commitprüfung und ändert keine Produktionskonfiguration.

## Ausführen nach Auswahl

Eigenes ZIP in einen neuen eigenen Verzeichnisbaum extrahieren und ZIP daneben erhalten. Aus dem extrahierten Verzeichnis:

```
sh run-boot-lab.sh /absolute/path/to/boot-lab-v4.zip
```

Kein Setup auf Webserv01, kein privileged/Hostnetz/KVM/Hostbus/Hostbind/Portforward-Fallback. Build lädt ausschließlich offizielle Ubuntu-Pakete und die fest gehashte offizielle Cloudimage-Datei. Der tatsächliche Gastboot läuft danach im Container mit network none, cap-drop ALL, no-new-privileges, Readonlyroot, nur zwei private Tmpfs,2GiB/1CPU/128PIDs. Containerinspect wird vor Start geprüft. QEMU nutzt ausschließlich TCG single-thread,1vCPU/1024MiB,keineGrafik/Monitor/KVM,readonlySeed,privateCowdisk,restrict=on-userspaceNICohneForwards. TCG-Gasttimeout780s,Containerattach840s,Build900s.

Cloudimage: [offizielle Ubuntu26.04-Datumsquelle](https://cloud-images.ubuntu.com/releases/resolute/release-20261016/), Dateiubuntu-26.04-server-cloudimg-amd64.img,SHA2565645d0318ad21f643ebb1ac4567514620e9893380b07b0201fda163baa5b7eb5. SHA256SUMS.ubuntu ist die tatsächlich gelesene offizielle Prüfsummenliste. Dockerbuild prüft den festgelegten Hash; Container prüft ihn vor Boot erneut. Keine GPG-Signaturprüfung behauptet. Offizielle Ubuntu-APT-Signatur-/Paketprüfung erfolgt durch APT; actual Paketversionen/BinarySHA werden im Beleg erfasst. Containerbasistagubuntu:26.04istnichtalsunveränderlicherDigestgepinnt; tatsächlicheImageIDwirdgesichert,keinevollständigeBinaryreproduzierbarkeitbehauptet.

Cloud-init legt nur die eigenen Prüfdateien in den eigenen Gast, eine fest an QEMU-MAC52:54:00:73:33:01gebundene w3boot0-GuestNIC und die private Gast-Probe an. Keine externen Zugangsdaten/Benutzer/SSHForwards. Gastprobe verlangt echten PID1systemdundbereitsaktivesnetworkd,liestVersionen/Mapping/NetplanundDateiinventar,führtkeinenProvider/ApplyausundfährtdeneigenenGastdanachherunter. Die synthetische Guest-DHCP-Verbindung über QEMU ist kein nachgewiesener DHCP-Schreibfall des Providers.

## Nachweise und Erfolg

Runner prüft ZIP/Manifest/ausgepackteDateien vor Build. Eigener evidence.XXXXXXXX-Ordner erhält vollständige Build-/Attach-/Seriallogs, PaketSHA/QuellmanifestSHA, tatsächliche ImageID, ContainerID/Inspect-vor/nach, Container-/Attach-/äußerenRunnerexit,CloudimageSHA,QEMUargv,GuestresultundHashes. Nur der eigene validierte64hex-Container wird gelöscht; eigene CIImages bleiben für Zuordnung erhalten. Gastdisk und Seed verlassen den privaten Container nicht.

V4 behebt den im echten V2-Run nachgewiesenen Tmpfs-Belegverlust: Nach Containerende ist `/run/lab` nicht mehr auslesbar. Daher kein nachträgliches `docker cp`. Der noch lebende Container überträgt vor Ende ausschließlich `result.json` (maximal 2MiB, enthält Versionen/BinarySHA), `serial.log` (vollständig, maximal 8MiB) und `qemu-argv.json` (maximal 16KiB) über stdout. Ein eigener Pipe-Leser begrenzt ausschließlich Serialausgabe; Überlauf beendet QEMU und bleibt Fehler. Kein allgemeines Dateigrößenlimit für Gastdisks. Geordnete 49152-Byte-Chunks, Payload- und Datei-SHA256 sowie genaue Größen verhindern unvollständige Übergaben. Payload höchstens 15MiB, Attach höchstens 21MiB. Decoder akzeptiert genau die drei fest benannten Dateien, keinen Archivpfad und keine zusätzlichen Zeilen. Er schreibt nur in einen neu erstellten eigenen Zielordner. Ausbleibende/trunkierte/duplizierte/veränderte Frames bleiben Fehler. Ein äußerer Attachtimeout kann weiterhin einen Fehler liefern und wird nie als Erfolg gewertet.

Erfolg erfordert äußeren Runnerexit0, Attach0, Container0, QEMU0, vollständigen Transport und genau einen WORKER3_LAB_RESULT-Datensatz im vollständigen Seriallog. Sein JSON muss dem Containerresultat entsprechen und ausschließlich Verfügbarkeit belegen. Der Empfänger prüft Name/MAC/ifindex/ausgewählte Netplan-Datei erneut aus der Originalprobe, die erforderlichen Managerkommandos, tatsächliche Versionen/BinarySHA, gepinnte CloudimageSHA, exakt erlaubte QEMUargv und dieselbe isolierte Containeridentität vor/nach Ende. receipt.json vereinigt diese Bedingungen. Fehlende/inkonsistente Belege bleiben Fehler, kein Textfragment von Bootlogs ist Pass. Keine Mutationsfreigabe aus Verfügbarkeit.

## Nächster Gate

Erst nach bestandenem echten Gastboot: separater eigener Provider-/veth-/Canary-/Netplan-Fall im gleichen ausreichend isolierten echten PID1-Gast. Root allein wählt und führt aus. GlobalesnetworkctlReload/Fremdinterfacewirkung,agentunabhängigerTimer,CommitCrash/RecoveryundunveränderteIPv6-/Fremdquellen sind weiterhin ungeprüft. Kein Hostmanagerwechsel und kein Deployment.

Quellen: [QEMU offizielle Invocation](https://www.qemu.org/docs/master/system/invocation.html), [Ubuntu Cloudimages](https://cloud-images.ubuntu.com/releases/resolute/release-20261016/).
