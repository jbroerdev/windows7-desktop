"""Availability only inside the disposable Ubuntu guest. Never applies network settings."""
import base64
import json
import pathlib
import subprocess
import sys


def verify_guest_mapping(probe):
    data = probe['commands']['links']
    if data.get('exitCode') != 0 or data.get('truncated'):
        raise ValueError('Complete successful kernel link read required.')
    links = json.loads(data['output'])
    targets = [link for link in links if link.get('ifname') == 'w3boot0']
    if len(targets) != 1 or targets[0].get('address') != '52:54:00:73:33:01':
        raise ValueError('Unique expected guest Name/MAC binding missing.')
    target = targets[0]
    index = target.get('ifindex')
    if type(index) is not int or index <= 0:
        raise ValueError('Invalid actual target ifindex.')
    rows = [row for row in probe['linkAssignmentMetadata']['links'] if row.get('ifindexFile') == str(index)]
    if len(rows) != 1:
        raise ValueError('Selected config metadata must belong to exact target ifindex.')
    fields = rows[0].get('fields', {})
    selected = fields.get('NETWORK_FILE')
    if fields.get('ADMIN_STATE') != 'configured' or not isinstance(selected, str):
        raise ValueError('Exact target must be configured and have a selected network file.')
    file = pathlib.PurePosixPath(selected)
    if file.parent != pathlib.PurePosixPath('/run/systemd/network') or not file.name.startswith('10-netplan-') or file.suffix != '.network':
        raise ValueError('Unexpected selected guest Netplan-generated config path.')
    records = [row for row in probe['fileInventory']['files'] if row.get('path') == selected]
    if len(records) != 1 or records[0].get('hashAvailable') is not True or records[0].get('stable') is not True:
        raise ValueError('Exact selected config must have a stable file hash.')
    record = records[0]
    if record.get('symlink') is not False or record.get('uid') != 0 or int(record['mode'],8) & 0o022:
        raise ValueError('Selected config ownership/type/mode unsafe.')
    return {'name':target['ifname'],'mac':target['address'],'ifindex':index,
            'selectedConfig':selected,'selectedConfigSha256':record['sha256'],
            'administrativeState':fields['ADMIN_STATE']}


def main():
    result = {'phase': 'availability-only', 'passed': False, 'applyExecuted': False,
              'rollbackVerified': False, 'commitVerified': False, 'productionAccess': False}
    try:
        result['pid1'] = pathlib.Path('/proc/1/comm').read_text().strip()
        if result['pid1'] != 'systemd':
            raise ValueError('Actual guest PID1 must be systemd.')
        active = subprocess.run(['systemctl','is-active','systemd-networkd.service'],
            capture_output=True, timeout=5, check=False)
        if active.returncode != 0 or active.stdout.strip() != b'active':
            raise ValueError('Guest networkd must already be active; no service-start fallback.')
        run = subprocess.run([sys.executable,'/opt/worker3-lab/read-only-manager-probe.py','--read-only'],
            capture_output=True, timeout=70, check=False)
        if run.returncode:
            raise ValueError('Read-only guest probe failed: '+run.stderr.decode(errors='replace')[:1024])
        probe = json.loads(run.stdout)
        required = ('networkctlVersion','systemdRunVersion','netplanInfo','netplanVersion','networkctlStatus')
        if any(probe['commands'][key].get('exitCode') != 0 for key in required):
            raise ValueError('Required manager/version/mapping read failed.')
        mapping = verify_guest_mapping(probe)
        result.update(passed=True, actualGuestPid1=True, actualNetworkd=True,
                      actualNetplan=True, actualSelectedConfigObserved=True,
                      actualSelectedConfigMapping=mapping, probe=probe)
    except Exception as error:
        result['error'] = str(error)
    folder = pathlib.Path('/run/worker3-lab'); folder.mkdir(mode=0o700, exist_ok=True)
    encoded = json.dumps(result, sort_keys=True).encode()
    (folder/'availability.json').write_bytes(encoded)
    # Only this explicit record is consumed; no boot text is treated as success.
    with open('/dev/ttyS0','wb',buffering=0) as console:
        console.write(b'\nWORKER3_LAB_RESULT '+base64.b64encode(encoded)+b'\n')
    return 0 if result['passed'] else 1


if __name__ == '__main__':raise SystemExit(main())
