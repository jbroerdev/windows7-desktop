"""Bounded read-only manager/config metadata probe. No service/unit/network writes."""
import argparse
import hashlib
import json
import os
import pathlib
import shlex
import shutil
import stat
import subprocess
import time

ROOTS = ('/etc/netplan', '/run/netplan', '/lib/netplan',
         '/etc/systemd/network', '/run/systemd/network', '/usr/lib/systemd/network')


def command(argv, limit=65536):
    executable = shutil.which(argv[0])
    if not executable:
        return {'available': False, 'exitCode': None, 'output': None}
    try:
        result = subprocess.run([executable, *argv[1:]], stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=4, check=False,
            env={**os.environ, 'LC_ALL': 'C', 'SYSTEMD_COLORS': '0', 'SYSTEMD_PAGER': ''})
        return {'available': True, 'exitCode': result.returncode,
                'output': result.stdout[:limit].decode('utf-8', errors='replace').strip(),
                'error': result.stderr[:4096].decode('utf-8', errors='replace').strip(),
                'truncated': len(result.stdout) > limit}
    except (OSError, subprocess.TimeoutExpired) as error:
        return {'available': True, 'exitCode': None, 'output': None, 'error': type(error).__name__}


def file_inventory():
    records, total = [], 0
    for name in ROOTS:
        root = pathlib.Path(name)
        if not root.is_dir():
            records.append({'root': name, 'exists': False})
            continue
        patterns = ('*.yaml', '*.yml') if name.endswith('netplan') else (
            '*.network', '*.link', '*.netdev', '*.network.d/*.conf', '*.link.d/*.conf', '*.netdev.d/*.conf')
        for file in sorted({p for pattern in patterns for p in root.glob(pattern)}):
            if len(records) >= 256:
                return {'files': records, 'complete': False, 'reason': 'file-count-limit'}
            entry = {'path': str(file)}
            try:
                before = file.lstat()
                entry.update(size=before.st_size, mode=oct(stat.S_IMODE(before.st_mode)),
                             uid=before.st_uid, gid=before.st_gid, symlink=stat.S_ISLNK(before.st_mode))
                if entry['symlink'] or not stat.S_ISREG(before.st_mode) or not file.resolve().is_relative_to(root.resolve()):
                    entry['hashAvailable'] = False
                    entry['reason'] = 'symlink/nonregular/outside-root'
                elif before.st_size > 1024 * 1024 or total + before.st_size > 32 * 1024 * 1024:
                    entry['hashAvailable'] = False
                    entry['reason'] = 'byte-limit'
                else:
                    # File data is used only for SHA; no YAML/networkd content is emitted.
                    data = file.read_bytes(); after = file.stat(); total += len(data)
                    entry.update(sha256=hashlib.sha256(data).hexdigest(), hashAvailable=True,
                        stable=(before.st_ino, before.st_size, before.st_mtime_ns) ==
                               (after.st_ino, after.st_size, after.st_mtime_ns))
            except OSError as error:
                entry.update(hashAvailable=False, error=type(error).__name__)
            records.append(entry)
    return {'files': records, 'complete': all(e.get('hashAvailable', True) and e.get('stable', True) for e in records),
            'hashedBytes': total, 'rawConfigContentsIncluded': False}


def link_assignment_metadata():
    root = pathlib.Path('/run/systemd/netif/links')
    fields = {'NETWORK_FILE', 'LINK_FILE', 'IFINDEX', 'ADMIN_STATE', 'OPER_STATE',
              'SETUP_STATE', 'OPERATIONAL_STATE', 'REQUIRED_FOR_ONLINE'}
    output = []
    if not root.is_dir():
        return {'available': False, 'links': []}
    for file in sorted(root.iterdir()):
        if not file.name.isdigit() or file.is_symlink() or not file.is_file():
            continue
        entry = {'ifindexFile': file.name, 'fields': {}}
        try:
            if file.stat().st_size > 65536:
                raise ValueError('metadata-size-limit')
            for line in file.read_text().splitlines():
                key, separator, value = line.partition('=')
                if separator and key in fields:
                    parsed = shlex.split(value)
                    entry['fields'][key] = parsed[0] if len(parsed) == 1 else None
        except (OSError, ValueError) as error:
            entry['error'] = type(error).__name__
        output.append(entry)
    return {'available': True, 'links': output}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--read-only', action='store_true', required=True)
    parser.parse_args()
    started = time.monotonic()
    commands = {
        'networkctlVersion': ['networkctl', '--version'],
        'systemdRunVersion': ['systemd-run', '--version'],
        'networkctlHelp': ['networkctl', '--help'],
        'netplanInfo': ['netplan', 'info'],
        'netplanVersion': ['dpkg-query', '-W', '-f=${Version}', 'netplan.io'],
        'networkdUnit': ['systemctl', 'show', '--no-pager',
            '--property=LoadState,ActiveState,SubState,MainPID,FragmentPath,CanReload', 'systemd-networkd.service'],
        'resolvedUnit': ['systemctl', 'show', '--no-pager',
            '--property=LoadState,ActiveState,SubState', 'systemd-resolved.service'],
        'networkctlStatus': ['networkctl', '--json=short', '--no-pager', 'status', '--all'],
        'links': ['ip', '-j', '-d', 'link', 'show'],
        'addresses': ['ip', '-j', 'address', 'show'],
        'routes4': ['ip', '-j', 'route', 'show'],
        'routes6': ['ip', '-j', '-6', 'route', 'show'],
    }
    result = {'schemaVersion': 1, 'scope': 'networkd-read-only-capability-probe',
        'mutationsPerformed': False, 'unitsCreated': False, 'networkManagerChanged': False,
        'configContentsIncluded': False, 'hostWriteCapabilityProven': False,
        'dockerMarker': pathlib.Path('/.dockerenv').exists(),
        'commands': {name: command(argv) for name, argv in commands.items()},
        'fileInventory': file_inventory(), 'linkAssignmentMetadata': link_assignment_metadata(),
        'binaries': {name: bool(shutil.which(name)) for name in ('networkctl','netplan','systemd-run','resolvectl','python3')}}
    try:
        result['pid1'] = pathlib.Path('/proc/1/comm').read_text().strip()
    except OSError:
        result['pid1'] = None
    result['durationMonotonicSeconds'] = time.monotonic() - started
    result['warning'] = 'Read-only availability/mapping evidence only, not permission or rollback/commit proof.'
    print(json.dumps(result, sort_keys=True), flush=True)


if __name__ == '__main__':main()
